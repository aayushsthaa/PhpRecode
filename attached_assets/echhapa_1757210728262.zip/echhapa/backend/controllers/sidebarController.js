
import SidebarWidget from '../models/SidebarWidget.js';

// @desc    Get all sidebar widgets for public view
// @route   GET /api/sidebar
// @access  Public
export const getPublicSidebarWidgets = async (req, res) => {
    try {
        const widgets = await SidebarWidget.find({})
            .sort({ order: 'asc' })
            .populate('categoryId', 'name')
            .populate('advertisementId');
        res.json(widgets);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};