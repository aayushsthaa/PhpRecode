import HomepageSection from '../models/HomepageSection.js';
import Category from '../models/Category.js';
import Advertisement from '../models/Advertisement.js';
import Article from '../models/Article.js';

// @desc    Get the unified, ordered homepage layout for public view
// @route   GET /api/homepage
// @access  Public
export const getHomepageLayout = async (req, res) => {
    try {
        const categoriesPromise = Category.find({ showOnHomepage: true }).lean();
        
        const sectionsPromise = HomepageSection.find({ isEnabled: true })
            .populate({
                path: 'articles.article',
                match: { status: 'published' },
                populate: { path: 'author', select: 'username' }
            })
            .populate('sourceCategory', 'name')
            .lean();

        const adsPromise = Advertisement.find({ 
            position: 'home_top_banner',
            isEnabled: true
        }).lean();

        const [categories, sections, ads] = await Promise.all([categoriesPromise, sectionsPromise, adsPromise]);

        // Process dynamic sections
        for (let section of sections) {
            if (section.isDynamic && section.sourceCategory && section.itemCount > 0) {
                const dynamicArticles = await Article.find({
                    status: 'published',
                    categories: section.sourceCategory.name,
                })
                .sort({ publishedAt: -1 })
                .limit(section.itemCount)
                .populate('author', 'username')
                .lean();
                
                section.articles = dynamicArticles.map((article, index) => ({
                    article: article,
                    order: index
                }));
            } else {
                // Filter out null articles that might result from the match (e.g., if an article was drafted)
                section.articles = section.articles
                    .filter(item => item.article)
                    .sort((a, b) => a.order - b.order);
            }
        }

        const typedCategories = categories.map(c => ({ ...c, type: 'category' }));
        const typedSections = sections.map(s => ({ ...s, type: 'special_section' }));
        const typedAds = ads.map(a => ({ ...a, type: 'advertisement' }));
        
        const combined = [...typedCategories, ...typedSections, ...typedAds];
        
        combined.sort((a, b) => (a.order ?? a.homepageOrder ?? 99) - (b.order ?? b.homepageOrder ?? 99));

        res.json(combined);
    } catch (error) {
        console.error("Error fetching homepage layout:", error);
        res.status(500).json({ message: 'Server Error' });
    }
};