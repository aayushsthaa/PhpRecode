
import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

// This is a mock email sending function. In a real application, you would
// integrate a service like Nodemailer, SendGrid, or Mailgun.
const sendEmail = async (options) => {
  console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
  console.log('!!!            SIMULATING EMAIL          !!!');
  console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
  console.log(`To: ${options.email}`);
  console.log(`Subject: ${options.subject}`);
  console.log('Body:');
  console.log(options.message);
  console.log('--- End of Email Simulation ---');
  return Promise.resolve();
};

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
export const registerUser = async (req, res) => {
  const { username, email, password } = req.body;

  try {
    const userExists = await User.findOne({ email });

    if (userExists) {
      if (!userExists.isVerified) {
        // Resend verification for an existing, unverified user
        const verificationToken = userExists.getVerificationToken();
        await userExists.save();

        const verificationUrl = `${req.headers.origin}/verify-email?token=${verificationToken}`;
        const message = `We received another registration request for this email. Please click the link below to verify your email address:\n\n${verificationUrl}\n\nThis link will expire in 15 minutes. If you did not make this request, please ignore this email.`;

        try {
          await sendEmail({
            email: userExists.email,
            subject: 'Echhapa Email Verification (New Request)',
            message,
          });
          return res.status(200).json({ 
            success: true, 
            message: 'An unverified account with this email already exists. A new verification link has been generated.',
            verificationUrl: verificationUrl // Return URL for DEV environment
          });
        } catch (emailError) {
          console.error('Email re-sending error:', emailError);
          return res.status(500).json({ message: 'Failed to resend verification email. Please try again later.' });
        }
      }
      return res.status(400).json({ message: 'User with this email already exists and is verified.' });
    }

    // Create a new user
    const user = new User({
      username,
      email,
      password,
    });
    
    const verificationToken = user.getVerificationToken();
    await user.save();

    const verificationUrl = `${req.headers.origin}/verify-email?token=${verificationToken}`;
    const message = `Thank you for registering for Echhapa. Please click the link below to verify your email address:\n\n${verificationUrl}\n\nThis link will expire in 15 minutes.`;

    try {
      await sendEmail({
        email: user.email,
        subject: 'Echhapa Email Verification',
        message,
      });

      res.status(201).json({ 
          success: true, 
          message: 'Registration successful!',
          verificationUrl: verificationUrl // Return URL for DEV environment
      });

    } catch (emailError) {
      console.error('Email sending error:', emailError);
      await User.findByIdAndDelete(user._id);
      return res.status(500).json({ message: 'User registration failed because the verification email could not be sent. Please try again.' });
    }
  } catch (dbError) {
    console.error('Registration Error:', dbError);
    res.status(500).json({ message: 'Server Error during registration.' });
  }
};


// @desc    Auth user & get token
// @route   POST /api/auth/login
// @access  Public
export const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    if (!user.isVerified) {
        // Optionally, you could add logic here to resend the verification email.
        return res.status(401).json({ message: 'Please verify your email address before logging in.' });
    }

    res.json({
      user: {
          _id: user._id,
          username: user.username,
          email: user.email,
          bookmarks: user.bookmarks,
          role: user.role, // Include user role in response
      },
      token: generateToken(user._id),
    });

  } catch (error) {
    console.error('Login Error:', error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Verify user's email
// @route   POST /api/auth/verify-email
// @access  Public
export const verifyEmail = async (req, res) => {
    const { token } = req.body;
    if (!token) {
        return res.status(400).json({ message: 'Verification token is required.' });
    }
    
    const hashedToken = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex');

    try {
        const user = await User.findOne({
            verificationToken: hashedToken,
            verificationTokenExpires: { $gt: Date.now() },
        });

        if (!user) {
            return res.status(400).json({ message: 'Invalid or expired verification token.' });
        }

        user.isVerified = true;
        user.verificationToken = undefined;
        user.verificationTokenExpires = undefined;
        await user.save();
        
        res.status(200).json({ success: true, message: 'Email verified successfully! You can now log in.' });

    } catch (error) {
        console.error('Email verification error:', error);
        res.status(500).json({ message: 'Server error during email verification.' });
    }
};