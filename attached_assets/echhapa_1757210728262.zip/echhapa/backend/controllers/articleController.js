import Article from '../models/Article.js';
import Tag from '../models/Tag.js';

const getTagIds = async (tagNames) => {
    if (!tagNames || tagNames.length === 0) return [];

    const tagIds = [];
    for (const name of tagNames) {
        let tag = await Tag.findOne({ name: name.toLowerCase() });
        if (!tag) {
            tag = await Tag.create({ name });
        }
        tagIds.push(tag._id);
    }
    return tagIds;
};

// @desc    Fetch all PUBLISHED articles
// @route   GET /api/articles
// @access  Public
export const getAllArticles = async (req, res) => {
    try {
        // Automatically publish any scheduled articles whose time has come.
        await Article.updateMany(
            { status: 'scheduled', publishedAt: { $lte: new Date() } },
            { $set: { status: 'published' } }
        );

        const articles = await Article.find({ 
            status: 'published',
            publishedAt: { $lte: new Date() }
        })
        .populate('author', 'username')
        .populate('tags', 'name')
        .sort({ publishedAt: -1 });
        res.json(articles);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Fetch single article
// @route   GET /api/articles/:id
// @access  Public
export const getArticleById = async (req, res) => {
    try {
        const article = await Article.findById(req.params.id)
            .populate('author', 'username')
            .populate('tags', 'name');
            
        // Allow viewing of draft/scheduled articles if you have the direct link
        if (article) {
            res.json(article);
        } else {
            res.status(404).json({ message: 'Article not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};


// @desc    Create a new article
// @route   POST /api/articles
// @access  Private/Author
export const createArticle = async (req, res) => {
    const { title, summary, content, imageUrl, imageCredit, categories, status, tags, publishedAt, seoTitle, metaDescription } = req.body;

    if (!title || !summary || !content || !categories || categories.length === 0) {
        return res.status(400).json({ message: 'Please provide all required fields, including at least one category.' });
    }

    try {
        const tagIds = await getTagIds(tags);
        const publishDate = publishedAt ? new Date(publishedAt) : new Date();

        let articleStatus = status || 'draft';
        if (req.user.role === 'author') {
            articleStatus = 'draft';
        } else if (publishDate > new Date()) {
            articleStatus = 'scheduled';
        }

        const article = new Article({
            title,
            summary,
            content,
            imageUrl: imageUrl || undefined,
            imageCredit,
            categories,
            status: articleStatus,
            author: req.user._id,
            tags: tagIds,
            publishedAt: publishDate,
            seoTitle,
            metaDescription,
        });

        const createdArticle = await article.save();
        const populatedArticle = await Article.findById(createdArticle._id)
            .populate('author', 'username')
            .populate('tags', 'name');
        
        res.status(201).json(populatedArticle);
    } catch (error) {
        console.error("Article creation error:", error);
        res.status(500).json({ message: 'Failed to create article.' });
    }
};

// @desc    Update an article
// @route   PUT /api/articles/:id
// @access  Private/Author
export const updateArticle = async (req, res) => {
    const { title, summary, content, imageUrl, imageCredit, categories, status, tags, publishedAt, seoTitle, metaDescription } = req.body;

    try {
        const article = await Article.findById(req.params.id);

        if (!article) {
            return res.status(404).json({ message: 'Article not found' });
        }

        // Permission check: An author can only edit their own articles.
        if (req.user.role === 'author' && article.author.toString() !== req.user._id.toString()) {
            return res.status(403).json({ message: 'Not authorized to edit this article' });
        }
        
        if (!categories || categories.length === 0) {
            return res.status(400).json({ message: 'Article must have at least one category.' });
        }

        const tagIds = await getTagIds(tags);
        const publishDate = publishedAt ? new Date(publishedAt) : article.publishedAt;
        
        article.title = title || article.title;
        article.summary = summary || article.summary;
        article.content = content || article.content;
        article.imageUrl = imageUrl;
        article.imageCredit = imageCredit;
        article.categories = categories || article.categories;
        article.tags = tagIds;
        article.publishedAt = publishDate;
        article.seoTitle = seoTitle;
        article.metaDescription = metaDescription;

        // Authors cannot publish. Editors/Admins can change status.
        if (req.user.role === 'editor' || req.user.role === 'admin') {
            let newStatus = status || article.status;
            if (newStatus === 'published' && publishDate > new Date()) {
                newStatus = 'scheduled';
            }
            article.status = newStatus;
        } else {
            article.status = 'draft'; // Authors' edits always result in a draft
        }

        const updatedArticle = await article.save();
        const populatedArticle = await Article.findById(updatedArticle._id)
            .populate('author', 'username')
            .populate('tags', 'name');
            
        res.json(populatedArticle);
        
    } catch (error) {
        console.error("Article update error:", error);
        res.status(500).json({ message: 'Failed to update article.' });
    }
};


// @desc    Delete an article
// @route   DELETE /api/articles/:id
// @access  Private/Admin
export const deleteArticle = async (req, res) => {
    try {
        const article = await Article.findById(req.params.id);

        if (article) {
            await article.deleteOne();
            res.json({ message: 'Article removed' });
        } else {
            res.status(404).json({ message: 'Article not found' });
        }
    } catch (error) {
        console.error("Article deletion error:", error);
        res.status(500).json({ message: 'Server Error' });
    }
};