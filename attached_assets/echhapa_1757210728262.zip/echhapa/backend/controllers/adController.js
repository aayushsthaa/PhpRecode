import Advertisement from '../models/Advertisement.js';

// @desc    Fetch all ads
// @route   GET /api/ads
// @access  Public
export const getAllAds = async (req, res) => {
    try {
        const now = new Date();
        // Correctly structured query to fetch active and enabled ads
        const ads = await Advertisement.find({
            isEnabled: true,
            $and: [
                {
                    $or: [
                        { startDate: { $exists: false } },
                        { startDate: { $eq: null } },
                        { startDate: { $lte: now } }
                    ]
                },
                {
                    $or: [
                        { endDate: { $exists: false } },
                        { endDate: { $eq: null } },
                        { endDate: { $gte: now } }
                    ]
                }
            ]
        }).sort({ createdAt: -1 })
          .populate('articleId', 'title')
          .populate('categoryId', 'name')
          .populate('categoryTargeting', 'name');
        res.json(ads);
    } catch (error) {
        console.error("Ad Fetch Error:", error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get a single ad by ID
// @route   GET /api/ads/:id
// @access  Private/Admin
export const getAdById = async (req, res) => {
    try {
        const ad = await Advertisement.findById(req.params.id);
        if (ad) {
            res.json(ad);
        } else {
            res.status(404).json({ message: 'Advertisement not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};


// @desc    Create an ad
// @route   POST /api/ads
// @access  Private/Admin
export const createAd = async (req, res) => {
    const { name, imageUrl, redirectUrl, position, articleId, categoryId, categoryTargeting, startDate, endDate, isEnabled } = req.body;

    if (!name || !imageUrl || !position) {
        return res.status(400).json({ message: 'Name, Image URL, and Position are required fields for the advertisement.' });
    }

    try {
        const ad = new Advertisement({
            name,
            imageUrl,
            redirectUrl: redirectUrl || undefined,
            position,
            startDate: startDate || undefined,
            endDate: endDate || undefined,
            isEnabled,
            ...(articleId && { articleId }), // Conditionally add articleId
            ...(categoryId && { categoryId }), // Conditionally add categoryId
            categoryTargeting: categoryTargeting && categoryTargeting.length > 0 ? categoryTargeting : undefined,
        });

        const createdAd = await ad.save();
        res.status(201).json(createdAd);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Update an ad
// @route   PUT /api/ads/:id
// @access  Private/Admin
export const updateAd = async (req, res) => {
    const { name, redirectUrl, position, articleId, categoryId, categoryTargeting, startDate, endDate, isEnabled } = req.body;
    try {
        const ad = await Advertisement.findById(req.params.id);
        if (ad) {
            ad.name = name || ad.name;
            ad.redirectUrl = redirectUrl;
            ad.position = position;
            ad.articleId = articleId || null;
            ad.categoryId = categoryId || null;
            ad.categoryTargeting = categoryTargeting || [];
            ad.startDate = startDate || null;
            ad.endDate = endDate || null;
            ad.isEnabled = isEnabled;

            const updatedAd = await ad.save();
            res.json(updatedAd);
        } else {
            res.status(404).json({ message: 'Advertisement not found' });
        }
    } catch (error) {
        console.error("Ad update error:", error)
        res.status(500).json({ message: 'Server Error' });
    }
};


// @desc    Delete an ad
// @route   DELETE /api/ads/:id
// @access  Private/Admin
export const deleteAd = async (req, res) => {
    try {
        const ad = await Advertisement.findById(req.params.id);
        if (ad) {
            await ad.deleteOne();
            res.json({ message: 'Advertisement removed' });
        } else {
            res.status(404).json({ message: 'Advertisement not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};