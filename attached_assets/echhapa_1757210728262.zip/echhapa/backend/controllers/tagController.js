
import Tag from '../models/Tag.js';
import Article from '../models/Article.js';

// @desc    Get all tags
// @route   GET /api/tags
// @access  Public
export const getAllTags = async (req, res) => {
    try {
        const tags = await Tag.find({}).sort({ name: 1 });
        res.json(tags);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create a tag
// @route   POST /api/tags
// @access  Private/Editor
export const createTag = async (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ message: 'Tag name is required' });
    }

    const tagName = name.trim().toLowerCase();
    const tagExists = await Tag.findOne({ name: tagName });
    if (tagExists) {
        return res.status(400).json({ message: 'Tag already exists' });
    }

    const tag = new Tag({ name: tagName });

    try {
        const createdTag = await tag.save();
        res.status(201).json(createdTag);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Update a tag
// @route   PUT /api/tags/:id
// @access  Private/Editor
export const updateTag = async (req, res) => {
    const { name } = req.body;
    const tagName = name.trim().toLowerCase();
    
    try {
        const tag = await Tag.findById(req.params.id);

        if (tag) {
            const existingTag = await Tag.findOne({ name: tagName });
            if (existingTag && existingTag._id.toString() !== req.params.id) {
                return res.status(400).json({ message: 'A tag with this name already exists.' });
            }

            tag.name = tagName;
            const updatedTag = await tag.save();
            res.json(updatedTag);
        } else {
            res.status(404).json({ message: 'Tag not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Delete a tag
// @route   DELETE /api/tags/:id
// @access  Private/Editor
export const deleteTag = async (req, res) => {
    try {
        const tag = await Tag.findById(req.params.id);

        if (tag) {
            // Remove the tag from all articles that reference it
            await Article.updateMany(
                { tags: tag._id },
                { $pull: { tags: tag._id } }
            );

            await tag.deleteOne();
            res.json({ message: 'Tag removed' });
        } else {
            res.status(404).json({ message: 'Tag not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};
