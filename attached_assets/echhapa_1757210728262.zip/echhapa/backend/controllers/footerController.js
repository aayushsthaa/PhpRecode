import FooterSettings from '../models/FooterSettings.js';

// @desc    Get the public footer settings
// @route   GET /api/footer
// @access  Public
export const getPublicFooterSettings = async (req, res) => {
    try {
        const settings = await FooterSettings.findOne();
        if (!settings) {
            // Return a default structure if nothing is configured yet
            return res.json({
                description: 'Welcome to our news portal.',
                socialLinks: [],
                linkColumns: [],
                copyrightText: `© ${new Date().getFullYear()} Echhapa. All rights reserved.`
            });
        }
        res.json(settings);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};
