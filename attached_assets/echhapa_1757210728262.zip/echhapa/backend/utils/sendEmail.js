
import nodemailer from 'nodemailer';

const sendEmail = async (options) => {
  let transporter;

  // If no real SMTP creds are in .env, use Ethereal for development
  if (!process.env.EMAIL_HOST) {
    // Generate test SMTP service account from ethereal.email
    // Only needed if you don't have a real mail account for testing
    let testAccount = await nodemailer.createTestAccount();

    // Log the Ethereal details to the console
    console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
    console.log('!!!      DEVELOPMENT EMAIL CREDENTIALS (ETHEREAL)    !!!');
    console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
    console.log(`User: ${testAccount.user}`);
    console.log(`Pass: ${testAccount.pass}`);
    console.log('--------------------------------------------------------');

    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: testAccount.user, // generated ethereal user
        pass: testAccount.pass, // generated ethereal password
      },
    });
  } else {
    // Use production/configured transporter
    transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });
  }

  // Define the email options
  const mailOptions = {
    from: `Echhapa News <${process.env.EMAIL_FROM || 'noreply@echhapa.com'}>`,
    to: options.email,
    subject: options.subject,
    html: options.html,
  };

  // Send the email
  const info = await transporter.sendMail(mailOptions);

  // If using Ethereal, log the preview URL
  if (!process.env.EMAIL_HOST) {
    console.log('--------------------------------------------------------');
    console.log(`Message sent: ${info.messageId}`);
    console.log(`Preview URL: ${nodemailer.getTestMessageUrl(info)}`);
    console.log('--------------------------------------------------------');
    console.log('NOTE: Click the link above to view the verification email.');
    console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
  }
};

export default sendEmail;
