
import express from 'express';
import { getAllArticles, getArticleById, createArticle, updateArticle, deleteArticle } from '../controllers/articleController.js';
import { protect, admin, author } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
    .get(getAllArticles)
    .post(protect, author, createArticle);
    
router.route('/:id')
    .get(getArticleById)
    .put(protect, author, updateArticle)
    .delete(protect, admin, deleteArticle);

export default router;