import express from 'express';
import { getPublicFooterSettings } from '../controllers/footerController.js';

const router = express.Router();

router.get('/', getPublicFooterSettings);

export default router;
