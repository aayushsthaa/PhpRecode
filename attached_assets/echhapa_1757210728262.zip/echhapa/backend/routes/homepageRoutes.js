
import express from 'express';
import { getHomepageLayout } from '../controllers/homepageController.js';

const router = express.Router();

// @route GET /api/homepage - Get the unified layout for the public homepage
router.get('/', getHomepageLayout);

export default router;
