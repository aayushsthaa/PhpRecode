
import express from 'express';
import { getAllTags, createTag, updateTag, deleteTag } from '../controllers/tagController.js';
import { protect, editor } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
    .get(getAllTags)
    .post(protect, editor, createTag);

router.route('/:id')
    .put(protect, editor, updateTag)
    .delete(protect, editor, deleteTag);

export default router;
