

import express from 'express';
import { toggleBookmark, updateUserProfile } from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// @route PUT /api/account/profile - Update user profile
router.put('/profile', protect, updateUserProfile);

// @route POST /api/account/bookmarks - Toggle bookmark for the logged-in user
router.post('/bookmarks', protect, toggleBookmark);

export default router;