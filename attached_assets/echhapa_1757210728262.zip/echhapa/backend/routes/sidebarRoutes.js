
import express from 'express';
import { getPublicSidebarWidgets } from '../controllers/sidebarController.js';
const router = express.Router();

router.get('/', getPublicSidebarWidgets);

export default router;
