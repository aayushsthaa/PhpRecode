import express from 'express';
import { getAllAds, createAd, deleteAd, getAdById, updateAd } from '../controllers/adController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
  .get(getAllAds)
  .post(protect, admin, createAd);

router.route('/:id')
    .get(protect, admin, getAdById)
    .put(protect, admin, updateAd)
    .delete(protect, admin, deleteAd);

export default router;