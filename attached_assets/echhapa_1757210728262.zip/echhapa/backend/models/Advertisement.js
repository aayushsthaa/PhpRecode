import mongoose from 'mongoose';

const advertisementSchema = new mongoose.Schema({
  name: { type: String, required: true },
  imageUrl: { type: String, required: true },
  redirectUrl: { type: String, required: false },
  position: {
    type: String,
    enum: ['home_top_banner', 'home_sidebar', 'home_section_ad', 'article_top', 'article_bottom', 'article_sidebar', 'popup_modal', 'sticky_footer_banner', 'inline_article'],
    required: true,
  },
  articleId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Article',
    required: false,
  },
  categoryId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: false,
  },
  categoryTargeting: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
  }],
  startDate: { type: Date },
  endDate: { type: Date },
  clicks: { type: Number, default: 0 },
  impressions: { type: Number, default: 0 },
  order: {
    type: Number,
    default: 99,
  },
  isEnabled: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

const Advertisement = mongoose.model('Advertisement', advertisementSchema);

export default Advertisement;