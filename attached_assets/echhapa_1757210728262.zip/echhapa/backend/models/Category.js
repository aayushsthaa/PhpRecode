

import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true,
        trim: true,
    },
    parent: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null,
    },
    showOnHomepage: {
        type: Boolean,
        default: false,
    },
    homepageLayout: {
        type: String,
        enum: ['carousel', 'grid_2_col', 'grid_3_col', 'grid_4_col', 'featured_post', 'list_view', 'split_70_30', 'hero_1_4', 'list_with_thumbnails', 'photo_feature', 'main_and_sub_list', 'video_gallery'],
        default: 'grid_3_col',
    },
    homepageOrder: {
        type: Number,
        default: 99,
    },
    order: { // For general purpose ordering, used in navbar
        type: Number,
        default: 99
    },
    showInNav: { // To control visibility in the main navbar
        type: Boolean,
        default: false,
    },
    seoTitle: { type: String },
    metaDescription: { type: String },
}, {
    timestamps: true,
});

const Category = mongoose.model('Category', categorySchema);

export default Category;