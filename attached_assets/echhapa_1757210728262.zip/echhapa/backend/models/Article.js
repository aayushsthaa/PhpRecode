import mongoose from 'mongoose';

const contentBlockSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['paragraph', 'image', 'video'],
    required: true,
  },
  content: { // This will store text for paragraphs, base64 for images, or embed URLs for video
    type: String,
    required: true,
  },
});

const articleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  summary: { type: String, required: true },
  content: { type: [contentBlockSchema], required: true },
  imageUrl: { type: String, required: false }, // Main feature image is now optional
  imageCredit: { type: String, required: false }, // Optional field for credit/caption
  categories: [{ type: String, required: true, index: true }],
  tags: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Tag' }],
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  status: {
    type: String,
    enum: ['published', 'draft', 'scheduled'],
    default: 'draft',
    index: true,
  },
  publishedAt: { type: Date, default: Date.now },
  seoTitle: { type: String },
  metaDescription: { type: String },
}, {
  timestamps: true
});

const Article = mongoose.model('Article', articleSchema);

export default Article;