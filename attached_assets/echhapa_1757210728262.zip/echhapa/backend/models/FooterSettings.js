import mongoose from 'mongoose';

const socialLinkSchema = new mongoose.Schema({
    platform: { type: String, enum: ['x', 'facebook', 'instagram', 'linkedin', 'youtube', 'tiktok'], required: true },
    url: { type: String, required: true },
});

const footerLinkSchema = new mongoose.Schema({
    label: { type: String, required: true },
    url: { type: String, required: true },
});

const footerLinkColumnSchema = new mongoose.Schema({
    title: { type: String, required: true },
    links: [footerLinkSchema],
});

const footerSettingsSchema = new mongoose.Schema({
    description: { type: String, default: '' },
    socialLinks: [socialLinkSchema],
    linkColumns: [footerLinkColumnSchema],
    copyrightText: { type: String, default: '' },
}, {
    timestamps: true
});

const FooterSettings = mongoose.model('FooterSettings', footerSettingsSchema);

export default FooterSettings;
