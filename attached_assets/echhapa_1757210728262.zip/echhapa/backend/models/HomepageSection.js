import mongoose from 'mongoose';

const homepageSectionSchema = new mongoose.Schema({
    title: { type: String, required: true },
    key: { type: String, required: true, unique: true }, 
    layout: {
        type: String,
        enum: ['carousel', 'grid_2_col', 'grid_3_col', 'grid_4_col', 'featured_post', 'list_view', 'split_70_30', 'hero_1_4', 'list_with_thumbnails', 'photo_feature', 'main_and_sub_list', 'video_gallery'],
        default: 'grid_3_col',
    },
    order: { type: Number, default: 99 },
    isEnabled: { type: Boolean, default: false },
    articles: [{
        article: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Article'
        },
        order: {
            type: Number,
            default: 0
        }
    }],
    // Fields for dynamic content
    isDynamic: {
        type: Boolean,
        default: false,
    },
    sourceCategory: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        required: false,
    },
    itemCount: {
        type: Number,
        default: 5,
        min: 1,
        max: 10,
    }
}, { timestamps: true });

const HomepageSection = mongoose.model('HomepageSection', homepageSectionSchema);
export default HomepageSection;