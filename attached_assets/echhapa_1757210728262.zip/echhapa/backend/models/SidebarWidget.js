import mongoose from 'mongoose';

const sidebarWidgetSchema = new mongoose.Schema({
    type: {
        type: String,
        enum: ['latest_articles', 'category_articles', 'advertisement'],
        required: true,
    },
    title: {
        type: String,
        required: true,
    },
    categoryId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        required: false,
    },
    advertisementId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Advertisement',
        required: false,
    },
    itemCount: {
        type: Number,
        default: 5,
        min: 1,
        max: 10,
    },
    order: {
        type: Number,
        required: true,
        default: 0,
    },
    layout: {
        type: String,
        enum: ['list_with_thumbnails', 'simple_list', 'featured_list'],
        default: 'list_with_thumbnails',
    },
}, {
    timestamps: true,
});

const SidebarWidget = mongoose.model('SidebarWidget', sidebarWidgetSchema);
export default SidebarWidget;