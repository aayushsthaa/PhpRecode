

import express from 'express';
import { 
    getStats, 
    getAllUsers, 
    createUserByAdmin,
    updateUserByAdmin,
    deleteUserByAdmin,
    getAllArticlesForAdmin,
    setArticleStatus,
    getAllAdsForAdmin,
    getSidebarWidgets,
    createSidebarWidget,
    updateSidebarWidgets,
    deleteSidebarWidget,
    getHomepageLayout,
    updateHomepageLayout,
    updateSectionArticles,
} from '../controllers/adminController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/stats', protect, admin, getStats);

// User Management
router.route('/manage-users')
    .get(protect, admin, getAllUsers)
    .post(protect, admin, createUserByAdmin);

router.route('/manage-users/:id')
    .put(protect, admin, updateUserByAdmin)
    .delete(protect, admin, deleteUserByAdmin);

// Article Management (Admin specific)
router.get('/admin-articles', protect, admin, getAllArticlesForAdmin);
router.put('/admin-articles/:id/status', protect, admin, setArticleStatus);

// Ad Management (Admin specific)
router.get('/ads', protect, admin, getAllAdsForAdmin);

// Sidebar Management
router.route('/sidebar-widgets')
    .get(protect, admin, getSidebarWidgets)
    .post(protect, admin, createSidebarWidget)
    .put(protect, admin, updateSidebarWidgets);

router.route('/sidebar-widgets/:id')
    .delete(protect, admin, deleteSidebarWidget);

// Homepage Layout Management
router.route('/homepage-layout')
    .get(protect, admin, getHomepageLayout)
    .put(protect, admin, updateHomepageLayout);

router.put('/homepage-sections/:id/articles', protect, admin, updateSectionArticles);


export default router;
