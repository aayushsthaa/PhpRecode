import User from '../models/User.js';
import Article from '../models/Article.js';
import Advertisement from '../models/Advertisement.js';
import SidebarWidget from '../models/SidebarWidget.js';
import HomepageSection from '../models/HomepageSection.js';
import Category from '../models/Category.js';

// @desc    Get dashboard stats
// @route   GET /api/management-panel/stats
// @access  Private/Admin
export const getStats = async (req, res) => {
    try {
        const usersCount = await User.countDocuments();
        const articlesCount = await Article.countDocuments();
        const adsCount = await Advertisement.countDocuments();
        const draftsCount = await Article.countDocuments({ status: 'draft' });
        const publishedCount = await Article.countDocuments({ status: 'published' });

        res.json({
            users: usersCount,
            articles: articlesCount,
            ads: adsCount,
            drafts: draftsCount,
            published: publishedCount,
        });
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get all users for admin
// @route   GET /api/management-panel/manage-users
// @access  Private/Admin
export const getAllUsers = async (req, res) => {
    try {
        const users = await User.find({}).select('-password');
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create user by admin
// @route   POST /api/management-panel/manage-users
// @access  Private/Admin
export const createUserByAdmin = async (req, res) => {
    const { username, email, password, role } = req.body;
    try {
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User with this email already exists' });
        }
        // Admin-created users are automatically verified
        const user = await User.create({ username, email, password, role, isVerified: true });
        res.status(201).json({ _id: user._id, username: user.username, email: user.email, role: user.role });
    } catch (error) {
        res.status(400).json({ message: 'Invalid user data' });
    }
};


// @desc    Update user by admin
// @route   PUT /api/management-panel/manage-users/:id
// @access  Private/Admin
export const updateUserByAdmin = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);

        if (user) {
            user.username = req.body.username || user.username;
            user.email = req.body.email || user.email;
            user.role = req.body.role || user.role;
            if (req.body.password) {
                user.password = req.body.password;
            }
            const updatedUser = await user.save();
            res.json({
                _id: updatedUser._id,
                username: updatedUser.username,
                email: updatedUser.email,
                role: updatedUser.role,
            });
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Delete user by admin
// @route   DELETE /api/management-panel/manage-users/:id
// @access  Private/Admin
export const deleteUserByAdmin = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);

        if (user) {
            if (user.role === 'admin' && req.user._id.toString() === user._id.toString()) {
                return res.status(400).json({ message: 'Cannot delete your own admin account.' });
            }
            await user.deleteOne();
            res.json({ message: 'User removed' });
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get all articles for admin view (published, drafts, and scheduled)
// @route   GET /api/management-panel/admin-articles
// @access  Private/Admin
export const getAllArticlesForAdmin = async (req, res) => {
    try {
        const articles = await Article.find({}).populate('author', 'username').populate('tags', 'name').sort({ createdAt: -1 });
        res.json(articles);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Set article status (published/draft/scheduled)
// @route   PUT /api/management-panel/admin-articles/:id/status
// @access  Private/Admin
export const setArticleStatus = async (req, res) => {
    let { status } = req.body;
    if (!['published', 'draft', 'scheduled'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status provided.' });
    }
    try {
        const article = await Article.findById(req.params.id);
        if (article) {
            // Smart status assignment: if set to 'published' but date is in the future, set to 'scheduled' instead.
            if (status === 'published' && article.publishedAt > new Date()) {
                status = 'scheduled';
            }
            
            article.status = status;
            const updatedArticle = await article.save();
            const populatedArticle = await Article.findById(updatedArticle._id).populate('author', 'username');
            res.json(populatedArticle);
        } else {
            res.status(404).json({ message: 'Article not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get all ads for admin view
// @route   GET /api/management-panel/ads
// @access  Private/Admin
export const getAllAdsForAdmin = async (req, res) => {
    try {
        const ads = await Advertisement.find({})
            .sort({ createdAt: -1 })
            .populate('articleId', 'title')
            .populate('categoryId', 'name');
        res.json(ads);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};


// --- Sidebar Widget Management ---

// @desc    Get all sidebar widgets for admin
// @route   GET /api/management-panel/sidebar-widgets
// @access  Private/Admin
export const getSidebarWidgets = async (req, res) => {
    try {
        const widgets = await SidebarWidget.find({})
            .sort({ order: 'asc' })
            .populate('categoryId', 'name')
            .populate('advertisementId');
        res.json(widgets);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create a sidebar widget
// @route   POST /api/management-panel/sidebar-widgets
// @access  Private/Admin
export const createSidebarWidget = async (req, res) => {
    const { type, title, categoryId, itemCount, layout, advertisementId } = req.body;

    try {
        const highestOrderWidget = await SidebarWidget.findOne().sort({ order: -1 });
        const newOrder = highestOrderWidget ? highestOrderWidget.order + 1 : 0;

        const widget = new SidebarWidget({
            type,
            title,
            categoryId: type === 'category_articles' ? categoryId : undefined,
            advertisementId: type === 'advertisement' ? advertisementId : undefined,
            itemCount,
            layout,
            order: newOrder,
        });
        const createdWidget = await widget.save();
        const populatedWidget = await SidebarWidget.findById(createdWidget._id).populate('categoryId', 'name').populate('advertisementId');

        res.status(201).json(populatedWidget);
    } catch (error) {
        res.status(400).json({ message: 'Invalid widget data' });
    }
};

// @desc    Update sidebar widgets (for reordering and content changes)
// @route   PUT /api/management-panel/sidebar-widgets
// @access  Private/Admin
export const updateSidebarWidgets = async (req, res) => {
    const { widgets } = req.body;
    if (!Array.isArray(widgets)) {
        return res.status(400).json({ message: 'Invalid data format.' });
    }

    try {
        const bulkOps = widgets.map(widget => ({
            updateOne: {
                filter: { _id: widget._id },
                update: { 
                    $set: { 
                        order: widget.order, 
                        title: widget.title, 
                        itemCount: widget.itemCount, 
                        categoryId: widget.type === 'category_articles' ? widget.categoryId : undefined,
                        advertisementId: widget.type === 'advertisement' ? widget.advertisementId : undefined,
                        layout: widget.layout,
                    } 
                },
            },
        }));
        
        if (bulkOps.length > 0) {
            await SidebarWidget.bulkWrite(bulkOps);
        }
        res.json({ message: 'Sidebar widgets updated' });

    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Delete a sidebar widget
// @route   DELETE /api/management-panel/sidebar-widgets/:id
// @access  Private/Admin
export const deleteSidebarWidget = async (req, res) => {
    try {
        const widget = await SidebarWidget.findById(req.params.id);
        if (widget) {
            await widget.deleteOne();
            res.json({ message: 'Widget removed' });
        } else {
            res.status(404).json({ message: 'Widget not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// --- Homepage Layout Management ---
export const getHomepageLayout = async (req, res) => {
    try {
        const categories = Category.find({}).lean();
        const specialSections = HomepageSection.find({})
            .populate({ path: 'articles.article', select: 'title' })
            .populate('sourceCategory', 'name')
            .lean();
        const ads = Advertisement.find({ position: 'home_top_banner' }).lean();

        const [catRes, secRes, adRes] = await Promise.all([categories, specialSections, ads]);

        const typedCategories = catRes.map(c => ({ ...c, type: 'category' }));
        const typedSections = secRes.map(s => ({ ...s, type: 'special_section' }));
        const typedAds = adRes.map(a => ({ ...a, type: 'advertisement' }));

        const combined = [...typedCategories, ...typedSections, ...typedAds];
        combined.sort((a, b) => (a.order ?? a.homepageOrder ?? 99) - (b.order ?? b.homepageOrder ?? 99));

        res.json(combined);
    } catch (error) {
        console.error("Error fetching homepage layout:", error);
        res.status(500).json({ message: 'Server Error fetching layout' });
    }
};

export const updateHomepageLayout = async (req, res) => {
    const { layout } = req.body;
    if (!Array.isArray(layout)) {
        return res.status(400).json({ message: 'Invalid data format.' });
    }

    try {
        const catOps = [];
        const secOps = [];
        const adOps = [];

        layout.forEach((item, index) => {
            switch (item.type) {
                case 'category':
                    catOps.push({
                        updateOne: {
                            filter: { _id: item._id },
                            update: { $set: { 
                                showOnHomepage: item.showOnHomepage,
                                homepageLayout: item.homepageLayout,
                                homepageOrder: index
                            }}
                        }
                    });
                    break;
                case 'special_section':
                    secOps.push({
                        updateOne: {
                            filter: { _id: item._id },
                            update: { $set: { 
                                title: item.title,
                                layout: item.layout,
                                isEnabled: item.isEnabled,
                                order: index,
                                isDynamic: item.isDynamic,
                                sourceCategory: item.isDynamic ? item.sourceCategory : null,
                                itemCount: item.isDynamic ? item.itemCount : 5
                            }}
                        }
                    });
                    break;
                case 'advertisement':
                    adOps.push({
                        updateOne: {
                            filter: { _id: item._id },
                            update: { $set: { 
                                isEnabled: item.isEnabled,
                                order: index
                            }}
                        }
                    });
                    break;
            }
        });

        const promises = [];
        if (catOps.length > 0) promises.push(Category.bulkWrite(catOps));
        if (secOps.length > 0) promises.push(HomepageSection.bulkWrite(secOps));
        if (adOps.length > 0) promises.push(Advertisement.bulkWrite(adOps));

        await Promise.all(promises);
        
        res.json({ message: 'Homepage layout updated successfully.' });

    } catch (error) {
        console.error("Error updating homepage layout:", error);
        res.status(500).json({ message: 'Server Error updating layout' });
    }
};

export const updateSectionArticles = async (req, res) => {
    const { articles } = req.body;
    if (!Array.isArray(articles)) {
        return res.status(400).json({ message: 'Invalid data format. Expects an array of articles.' });
    }
    
    try {
        const section = await HomepageSection.findById(req.params.id);
        if (!section) {
            return res.status(404).json({ message: 'Section not found' });
        }
        section.articles = articles;
        await section.save();
        res.json({ message: 'Section articles updated successfully.' });
    } catch (error) {
        console.error("Error updating section articles:", error);
        res.status(500).json({ message: 'Server Error' });
    }
};