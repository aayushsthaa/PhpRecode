import Category from '../models/Category.js';
import Article from '../models/Article.js';

// @desc    Get all categories
// @route   GET /api/categories
// @access  Public
export const getCategories = async (req, res) => {
    try {
        const categories = await Category.find({}).sort({ name: 1 }).populate('parent', '_id name');
        res.json(categories);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create a category
// @route   POST /api/categories
// @access  Private/Admin
export const createCategory = async (req, res) => {
    const { name, parent } = req.body;
    if (!name) {
        return res.status(400).json({ message: 'Category name is required' });
    }

    const categoryExists = await Category.findOne({ name });
    if (categoryExists) {
        return res.status(400).json({ message: 'Category already exists' });
    }
    
    // Find the highest current order to place the new category at the end
    const lastCategory = await Category.findOne().sort({ homepageOrder: -1 });
    const newOrder = lastCategory ? lastCategory.homepageOrder + 1 : 0;

    const category = new Category({ 
        name,
        parent: parent || null,
        homepageOrder: newOrder
    });

    try {
        const createdCategory = await category.save();
        res.status(201).json(createdCategory);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Update a category
// @route   PUT /api/categories/:id
// @access  Private/Admin
export const updateCategory = async (req, res) => {
    const { name, seoTitle, metaDescription, parent } = req.body;
    try {
        if (req.params.id === parent) {
            return res.status(400).json({ message: 'A category cannot be its own parent.' });
        }

        const category = await Category.findById(req.params.id);

        if (category) {
            // Check if another category with the new name already exists
            const existingCategory = await Category.findOne({ name });
            if (existingCategory && existingCategory._id.toString() !== req.params.id) {
                return res.status(400).json({ message: 'A category with this name already exists.' });
            }

            const oldName = category.name;
            category.name = name || category.name;
            category.seoTitle = seoTitle;
            category.metaDescription = metaDescription;
            category.parent = parent || null;

            const updatedCategory = await category.save();

            // If the name changed, update all articles using this category
            if (oldName !== updatedCategory.name) {
                await Article.updateMany({ categories: oldName }, { $set: { "categories.$": updatedCategory.name } });
            }
            
            res.json(updatedCategory);
        } else {
            res.status(404).json({ message: 'Category not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};


// @desc    Delete a category
// @route   DELETE /api/categories/:id
// @access  Private/Admin
export const deleteCategory = async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);

        if (category) {
            // Prevent deletion if it's a parent to other categories
            const children = await Category.find({ parent: category._id });
            if (children.length > 0) {
                return res.status(400).json({ message: 'Cannot delete category. It has subcategories. Please reassign or delete them first.' });
            }

            // Pull the category from any article that has it.
            await Article.updateMany({ categories: category.name }, { $pull: { categories: category.name } });

            // If any article is left with no categories, add 'Uncategorized' to it.
            await Article.updateMany({ categories: { $size: 0 } }, { $push: { categories: 'Uncategorized' } });

            await category.deleteOne();
            res.json({ message: 'Category removed and articles updated.' });
        } else {
            res.status(404).json({ message: 'Category not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Update homepage settings for all categories
// @route   PUT /api/categories/homepage
// @access  Private/Admin
export const updateHomepageSettings = async (req, res) => {
    const { categories } = req.body;
    if (!Array.isArray(categories)) {
        return res.status(400).json({ message: 'Invalid data format. Expects an array of categories.' });
    }

    try {
        const bulkOps = categories.map(cat => ({
            updateOne: {
                filter: { _id: cat._id },
                update: {
                    $set: {
                        showOnHomepage: cat.showOnHomepage,
                        homepageLayout: cat.homepageLayout,
                        homepageOrder: cat.homepageOrder,
                    }
                }
            }
        }));

        if (bulkOps.length > 0) {
            await Category.bulkWrite(bulkOps);
        }

        res.json({ message: 'Homepage settings updated successfully.' });

    } catch (error) {
        console.error("Homepage settings update error:", error);
        res.status(500).json({ message: 'Failed to update homepage settings.' });
    }
};