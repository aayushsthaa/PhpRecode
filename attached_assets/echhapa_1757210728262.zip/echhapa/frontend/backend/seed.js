import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.js';
import Category from './models/Category.js';
import Article from './models/Article.js';
import Advertisement from './models/Advertisement.js';
import SidebarWidget from './models/SidebarWidget.js';
import HomepageSection from './models/HomepageSection.js';
import Tag from './models/Tag.js';

dotenv.config();

const connectDB = async () => {
    try {
        if (!process.env.MONGO_URI) {
            throw new Error('MONGO_URI is not defined in the .env file.');
        }
        await mongoose.connect(process.env.MONGO_URI);
        console.log('MongoDB Connected for seeding...');
    } catch (error) {
        console.error(`Error connecting to DB for seeding: ${error.message}`);
        process.exit(1);
    }
};

const importData = async () => {
    try {
        // Clear existing data first
        await Advertisement.deleteMany();
        await Article.deleteMany();
        await Category.deleteMany();
        await User.deleteMany();
        await SidebarWidget.deleteMany();
        await HomepageSection.deleteMany();
        await Tag.deleteMany();


        // 1. Seed Users with different roles (pre-verified)
        const users = await User.create([
            {
                username: 'Admin',
                email: 'admin@example.com',
                password: '12345',
                role: 'admin',
                isVerified: true,
            },
            {
                username: 'Editor',
                email: 'editor@example.com',
                password: '12345',
                role: 'editor',
                isVerified: true,
            },
            {
                username: 'Author',
                email: 'author@example.com',
                password: '12345',
                role: 'author',
                isVerified: true,
            },
        ]);
        const adminUser = users[0];
        const editorUser = users[1];
        const authorUser = users[2];
        console.log('Users seeded.');

        // 2. Seed Tags
        const tags = await Tag.insertMany([
            { name: 'politics' }, { name: 'election' }, { name: 'economy' },
            { name: 'sports' }, { name: 'cricket' }, { name: 'technology' },
            { name: 'health' }, { name: 'environment' }, { name: 'entertainment' },
            { name: 'social-issue' }, { name: 'international' }, { name: 'infrastructure' },
            { name: 'agriculture' }, { name: 'tourism' }, { name: 'stock-market' }
        ]);
        console.log('Tags seeded.');
        const getTag = (name) => tags.find(t => t.name === name);

        // 3. Seed Categories with Hierarchy
        const parentCategories = await Category.insertMany([
            { name: 'समाचार', showOnHomepage: true, homepageLayout: 'main_and_sub_list', homepageOrder: 1, seoTitle: 'ताजा समाचार | इच्छापा', metaDescription: 'नेपाल र विश्वभरका ताजा समाचार र घटनाहरूको विस्तृत कभरेज।' },
            { name: 'खेलकुद', showOnHomepage: true, homepageLayout: 'grid_3_col', homepageOrder: 4 },
            { name: 'अर्थ–वाणिज्य', showOnHomepage: true, homepageLayout: 'photo_feature', homepageOrder: 3, seoTitle: 'अर्थ–वाणिज्य समाचार | इच्छापा', metaDescription: 'नेपाली अर्थतन्त्र, व्यापार, र वाणिज्य क्षेत्रका नवीनतम समाचारहरू।' },
        ]);
        const samachar = parentCategories.find(c => c.name === 'समाचार');
        const khelkud = parentCategories.find(c => c.name === 'खेलकुद');

        const allCategories = await Category.insertMany([
            { name: 'भिडियो', showOnHomepage: true, homepageLayout: 'video_gallery', homepageOrder: 2, seoTitle: 'भिडियो समाचार | इच्छापा', metaDescription: 'भिडियोमा ताजा समाचार र रिपोर्टहरू हेर्नुहोस्।' },
            { name: 'कला र शैली', showOnHomepage: true, homepageLayout: 'list_with_thumbnails', homepageOrder: 5 },
            { name: 'फोटोफिचर', showOnHomepage: false, homepageLayout: 'grid_3_col', homepageOrder: 6 },
            { name: 'दृष्टिकोण', showOnHomepage: false, homepageOrder: 8 },
            { name: 'शिक्षा', showOnHomepage: true, homepageLayout: 'grid_2_col', homepageOrder: 7 },
            { name: 'अन्तर्राष्ट्रिय', showOnHomepage: true, homepageLayout: 'split_70_30', homepageOrder: 9 },
            // Subcategories
            { name: 'राजनीति', parent: samachar._id, showOnHomepage: false },
            { name: 'समाज', parent: samachar._id, showOnHomepage: false },
            { name: 'क्रिकेट', parent: khelkud._id, showOnHomepage: false },
            { name: 'फुटबल', parent: khelkud._id, showOnHomepage: false },
        ]);
        const seededCategories = [...parentCategories, ...allCategories];
        console.log('Categories with hierarchy seeded.');
        const getCat = (name) => seededCategories.find(c => c.name === name);
        
        // Date for scheduled post (1 day from now)
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);

        // 4. Seed Articles with new category structure
        const sampleArticles = [
            {
                title: 'सरकारले नयाँ बजेट सार्वजनिक गर्‍यो, शिक्षा र स्वास्थ्यमा प्राथमिकता',
                summary: 'आगामी आर्थिक वर्षका लागि सरकारले १७ खर्बको बजेट प्रस्तुत गरेको छ, जसमा शिक्षा, स्वास्थ्य र कृषि क्षेत्रलाई विशेष प्राथमिकता दिइएको छ।',
                imageUrl: 'https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                imageCredit: 'Pexels',
                categories: ['अर्थ–वाणिज्य', 'राजनीति'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('politics')._id, getTag('economy')._id],
                seoTitle: 'नेपाल बजेट: शिक्षा र स्वास्थ्यमा विशेष जोड',
                metaDescription: 'सरकारद्वारा प्रस्तुत नयाँ बजेटले शिक्षा र स्वास्थ्य क्षेत्रमा उल्लेख्य लगानी गर्ने लक्ष्य राखेको छ।',
                content: [
                    { type: 'paragraph', content: 'अर्थमन्त्रीले संघीय संसदमा आगामी आर्थिक वर्ष २०८१/८२ को बजेट प्रस्तुत गरेका हुन्। बजेटमा पूर्वाधार विकास, रोजगारी सिर्जना र सामाजिक सुरक्षा जस्ता विषयलाई पनि समेटिएको छ। यो बजेटले देशको आर्थिक विकासमा नयाँ गति दिने अपेक्षा गरिएको छ।' },
                    { type: 'image', content: 'https://images.pexels.com/photos/7788009/pexels-photo-7788009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'},
                    { type: 'paragraph', content: 'बजेटले आर्थिक वृद्धिको लक्ष्य ६.५ प्रतिशत राखेको छ भने मूल्यवृद्धि ५.५ प्रतिशतमा सीमित गर्ने लक्ष्य लिएको छ। विपक्षी दलहरूले भने बजेटलाई महत्वाकांक्षी र कार्यान्वयनमा चुनौतीपूर्ण भनेका छन्।' },
                    { type: 'video', content: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { type: 'paragraph', content: 'कृषि क्षेत्रको आधुनिकीकरणका लागि अनुदान र सहुलियतपूर्ण ऋणको व्यवस्था गरिएको छ भने युवाहरूलाई स्वदेशमै रोजगारी सिर्जना गर्न विशेष कार्यक्रम ल्याइने भएको छ।'}
                ]
            },
            {
                title: 'नेपाली राष्ट्रिय क्रिकेट टोलीले ऐतिहासिक जित हासिल गर्‍यो',
                summary: 'अन्तर्राष्ट्रिय त्रिकोणात्मक श्रृंखलाको फाइनलमा नेपालले आयोजक राष्ट्रलाई ५ विकेटले पराजित गर्दै ऐतिहासिक उपाधि जितेको छ।',
                imageUrl: 'https://images.pexels.com/photos/248547/pexels-photo-248547.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['खेलकुद', 'क्रिकेट'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('sports')._id, getTag('cricket')._id],
                content: [
                    { type: 'paragraph', content: 'कप्तानको उत्कृष्ट प्रदर्शन र बलरहरूको अनुशासित बलिङको मद्दतले नेपालले यो ऐतिहासिक सफलता प्राप्त गरेको हो। यो जितसँगै नेपाली टोलीको विश्व वरीयतामा पनि सुधार हुनेछ। फाइनल खेलमा नेपालले उत्कृष्ट फिल्डिङको नमुना प्रस्तुत गरेको थियो।' },
                     { type: 'paragraph', content: 'खेलको अन्तिम ओभरमा नेपाललाई जितका लागि ८ रन आवश्यक थियो, र अन्तिम ब्याट्सम्यानले छक्का प्रहार गर्दै टोलीलाई अविस्मरणीय जित दिलाए।' },
                    { type: 'paragraph', content: 'खेलपछि कप्तानले यो जित सम्पूर्ण नेपाली समर्थकप्रति समर्पित रहेको बताए। प्रधानमन्त्रीले पनि टोलीलाई बधाई दिएका छन्।'}
                ]
            },
            {
                title: 'मनसुन सक्रिय, देशभर भारी वर्षाको सम्भावना (SCHEDULED)',
                summary: 'जल तथा मौसम विज्ञान विभागले देशभर मनसुन सक्रिय भएको र आगामी तीन दिन भारी वर्षाको सम्भावना रहेको जनाएको छ।',
                imageUrl: 'https://images.pexels.com/photos/256369/pexels-photo-256369.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार'],
                author: editorUser._id,
                status: 'scheduled',
                publishedAt: tomorrow,
                tags: [getTag('environment')._id, getTag('health')._id],
                content: [
                    { type: 'paragraph', content: 'यो लेख भोलि प्रकाशित हुनेछ। विभागले नदी तटीय क्षेत्रका बासिन्दालाई उच्च सतर्कता अपनाउन आग्रह गरेको छ। पहाडी क्षेत्रमा पहिरोको जोखिम रहेकोले यात्रा गर्दा सावधानी अपनाउन पनि सुझाइएको छ।' }
                ]
            },
            {
                title: 'डिजिटल भुक्तानीमा नेपालको फड्को (Author\'s Draft)',
                summary: 'साना पसलदेखि ठूला व्यापारिक प्रतिष्ठानसम्म क्यूआर कोडमार्फत हुने डिजिटल भुक्तानीको प्रयोग व्यापक बन्दै गएको छ।',
                imageUrl: 'https://images.pexels.com/photos/5098661/pexels-photo-5098661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अर्थ–वाणिज्य'],
                author: authorUser._id,
                status: 'draft',
                tags: [getTag('technology')._id, getTag('economy')._id],
                content: [
                    { type: 'paragraph', content: 'यो लेख लेखकद्वारा ड्राफ्टको रूपमा बचत गरिएको छ र सम्पादकले अनुमोदन नगरेसम्म सार्वजनिक हुने छैन। नेपाल राष्ट्र बैंकको पछिल्लो तथ्यांक अनुसार क्यूआर कोडमा आधारित कारोबारको संख्यामा गत वर्षको तुलनामा २०० प्रतिशतले वृद्धि भएको छ। यसले नगदरहित अर्थतन्त्र निर्माणमा सहयोग पुगेको छ।' }
                ]
            },
            {
                title: 'स्थानीय तहको निर्वाचन मिति घोषणा, तयारी तीव्र',
                summary: 'निर्वाचन आयोगले आगामी स्थानीय तहको निर्वाचनको मिति घोषणा गरेको छ। दलहरूले आन्तरिक तयारी सुरु गरेका छन्।',
                imageUrl: 'https://images.pexels.com/photos/1550348/pexels-photo-1550348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार', 'राजनीति'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('politics')._id, getTag('election')._id],
                content: [
                    { type: 'paragraph', content: 'निर्वाचन आयोगले आज एक पत्रकार सम्मेलन आयोजना गरी आगामी मंसिर ४ गतेका लागि स्थानीय तहको निर्वाचनको मिति तय गरेको जानकारी दिएको छ। निर्वाचनको घोषणासँगै प्रमुख राजनीतिक दलहरूले उम्मेदवार छनोट र चुनावी रणनीतिका लागि आन्तरिक छलफल तीव्र पारेका छन्।' },
                    { type: 'paragraph', content: 'आयोगका अनुसार, निर्वाचनमा करिब १ करोड ८० लाख मतदाताले भाग लिनेछन्। यसका लागि देशभर १० हजारभन्दा बढी मतदान केन्द्र तोकिनेछ।' }
                ]
            },
            {
                title: 'नेपालको पर्यटन क्षेत्रमा पुनरुत्थानको संकेत',
                summary: 'महामारीपछिको सुस्ततालाई चिर्दै नेपालको पर्यटन क्षेत्रमा विदेशी पर्यटकको आगमन बढ्न थालेको छ। व्यवसायीहरू उत्साहित छन्।',
                imageUrl: 'https://images.pexels.com/photos/1131458/pexels-photo-1131458.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अर्थ–वाणिज्य', 'भिडियो'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('economy')._id, getTag('tourism')._id],
                content: [
                    { type: 'paragraph', content: 'कोभिड-१९ महामारीका कारण लगभग शून्यमा झरेको नेपालको पर्यटन व्यवसायले गति लिन थालेको छ। पर्यटन बोर्डको तथ्यांकअनुसार, पछिल्लो तीन महिनामा विदेशी पर्यटकको आगमन दरमा ६० प्रतिशतले वृद्धि भएको छ।' },
                     { type: 'video', content: 'https://www.youtube.com/embed/o-YBDTqX_ZU' },
                     { type: 'paragraph', content: 'विशेषगरी युरोप, अमेरिका र छिमेकी राष्ट्र भारतबाट पर्यटकहरूको आगमन बढेको छ। पदयात्रा र पर्वतारोहणका लागि नेपाल आउने पर्यटकको संख्या उल्लेख्य छ।' }
                ]
            },
             {
                title: 'कलाकारको आँखामा काठमाडौं: चित्रकला प्रदर्शनी सुरु',
                summary: 'बबरमहलस्थित आर्ट ग्यालरीमा विभिन्न कलाकारहरूले काठमाडौं उपत्यकाको संस्कृति र जीवनशैलीलाई क्यानभासमा उतारेको चित्रकला प्रदर्शनी सुरु भएको छ।',
                imageUrl: 'https://images.pexels.com/photos/103566/pexels-photo-103566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['कला र शैली'],
                author: authorUser._id,
                status: 'draft',
                tags: [getTag('entertainment')._id],
                content: [
                    { type: 'paragraph', content: 'प्रदर्शनीमा नयाँ र पुराना पुस्ताका गरी ३० जना कलाकारका ५० भन्दा बढी चित्रहरू राखिएका छन्। प्रदर्शनी एक हप्तासम्म चल्नेछ।' },
                    { type: 'paragraph', content: 'कलाकारहरूले काठमाडौंका पुराना गल्ली, मन्दिर, चाडपर्व र दैनिक जीवनका दृश्यहरूलाई आफ्नो सिर्जनाको विषय बनाएका छन्।' }
                ]
            },
             {
                title: 'नेपाल र चीनबीचको तातोपानी नाका पुनः सञ्चालन',
                summary: 'भूकम्प र कोभिड-१९ महामारीका कारण लामो समयदेखि बन्द रहेको तातोपानी नाका पूर्ण रूपमा सञ्चालनमा आएको छ, जसले व्यापार सहजीकरणमा मद्दत पुग्नेछ।',
                imageUrl: 'https://images.pexels.com/photos/1078884/pexels-photo-1078884.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार', 'अर्थ–वाणिज्य'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('politics')._id, getTag('economy')._id],
                content: [
                    { type: 'paragraph', content: 'नाका सञ्चालनमा आएसँगै चिनियाँ सामानको आयात सहज भएको छ भने नेपाली वस्तुको निर्यातको बाटो पनि खुलेको छ। व्यवसायीहरूले यस कदमको स्वागत गरेका छन्।' },
                     { type: 'paragraph', content: 'यो नाका सिन्धुपाल्चोक जिल्लामा अवस्थित छ र नेपालको उत्तरी छिमेकीसँगको व्यापारका लागि एक महत्वपूर्ण स्थल हो।' }
                ]
            },
             {
                title: 'सामुदायिक विद्यालयको शैक्षिक गुणस्तर सुधार अभियान',
                summary: 'शिक्षा मन्त्रालयले देशभरका सामुदायिक विद्यालयहरूको शैक्षिक गुणस्तर सुधार गर्न "हाम्रो विद्यालय, राम्रो विद्यालय" अभियान सुरु गरेको छ।',
                imageUrl: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['शिक्षा'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('social-issue')._id],
                content: [
                    { type: 'paragraph', content: 'अभियान अन्तर्गत शिक्षक तालिम, भौतिक पूर्वाधार सुधार र प्रविधिमैत्री शिक्षणमा जोड दिइनेछ। यसका लागि सरकारले विशेष बजेट विनियोजन गरेको छ।' },
                    { type: 'paragraph', content: 'शिक्षाविद्हरूले यो अभियानको स्वागत गरेका छन्, तर यसको सफल कार्यान्वयनका लागि स्थानीय तह र अभिभावकको सहभागिता अनिवार्य रहेको बताएका छन्।' }
                ]
            },
            {
                title: 'सूचना प्रविधि पार्कको अवधारणा: सम्भावना र चुनौती',
                summary: 'सरकारले देशका विभिन्न स्थानमा सूचना प्रविधि (आईटी) पार्क निर्माण गर्ने योजना अघि सारेको छ। यसले देशको डिजिटल अर्थतन्त्रमा क्रान्ति ल्याउन सक्ने विज्ञहरू बताउँछन्।',
                imageUrl: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अर्थ–वाणिज्य', 'शिक्षा'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('technology')._id, getTag('economy')._id],
                content: [
                    { type: 'paragraph', content: 'सूचना प्रविधिको बढ्दो महत्वलाई आत्मसात गर्दै सरकारले काठमाडौं, पोखरा, र बुटवल जस्ता प्रमुख शहरहरूमा अत्याधुनिक आईटी पार्क स्थापना गर्ने घोषणा गरेको छ।' },
                    { type: 'image', content: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
                    { type: 'paragraph', content: 'यद्यपि, यसको सफल कार्यान्वयनका लागि नियमित विद्युत आपूर्ति, उच्च गतिको इन्टरनेट, र दक्ष जनशक्ति जस्ता पूर्वाधारहरू अनिवार्य छन्।' }
                ]
            },
            {
                title: 'सगरमाथाको आधार शिविरबाट प्रत्यक्ष: आरोहीहरूको कथा',
                summary: 'विश्वको सर्वोच्च शिखर सगरमाथाको आधार शिविरमा पुगेर हामीले यस वर्षको आरोहणको तयारी गरिरहेका आरोहीहरूसँग कुराकानी गरेका छौं। हेर्नुहोस् यो विशेष भिडियो रिपोर्ट।',
                imageUrl: 'https://images.pexels.com/photos/1964467/pexels-photo-1964467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['भिडियो', 'समाचार'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('tourism')._id],
                content: [
                    { type: 'paragraph', content: 'सगरमाथा आरोहण एक साहसिक यात्रा मात्र होइन, यो धैर्य, संकल्प, र प्रकृतिको सम्मानको कथा पनि हो। आधार शिविरमा विभिन्न देशका आरोहीहरू मौसम अनुकूल हुनका लागि अभ्यास गरिरहेका छन्।' },
                    { type: 'video', content: 'https://www.youtube.com/embed/9bZkp7q19f0' },
                    { type: 'paragraph', content: 'उनीहरूका सपना, चुनौती, र तयारीबारे हामीले तयार पारेको यो विस्तृत भिडियो रिपोर्टले सगरमाथाको चुचुरोमा पुग्नुको अर्थलाई नजिकबाट देखाउँछ।' }
                ]
            },
            {
                title: 'जलवायु परिवर्तनको असर: हिमालयमा हिउँ पग्लने क्रम तीव्र',
                summary: 'एक नयाँ अध्ययनले हिमालय क्षेत्रमा तापक्रम वृद्धिका कारण हिउँ पग्लने दर विगतको तुलनामा दोब्बर भएको देखाएको छ। यसले तल्लो तटीय क्षेत्रमा बाढीको जोखिम बढाएको छ।',
                imageUrl: 'https://images.pexels.com/photos/41949/earth-earth-at-night-night-lights-41949.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार', 'अन्तर्राष्ट्रिय'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('environment')._id],
                content: [
                    { type: 'paragraph', content: 'वैज्ञानिकहरूले स्याटेलाइट तस्बिरहरूको विश्लेषण गरी यो निष्कर्ष निकालेका हुन्। उनीहरूका अनुसार, यसले करोडौं मानिसहरूको खानेपानीको स्रोतमा समेत असर पार्न सक्छ।' },
                    { type: 'paragraph', content: 'अध्ययनले विश्वव्यापी रूपमा कार्बन उत्सर्जन कटौती गर्न तत्काल कदम चाल्नुपर्ने आवश्यकतालाई जोड दिएको छ। नेपाल जस्ता हिमाली देशहरू यसको प्रत्यक्ष मारमा परेका छन्।' }
                ]
            },
            {
                title: 'नेपाल स्टक एक्सचेन्ज (नेप्से) मा उछाल, लगानीकर्ता उत्साहित',
                summary: 'लामो समयको सुस्ततापछि नेप्से परिसूचकमा १०० अंकभन्दा बढीको वृद्धि देखिएको छ। नियामक निकायको सकारात्मक नीतिका कारण बजार बढेको विश्लेषकहरू बताउँछन्।',
                imageUrl: 'https://images.pexels.com/photos/7788657/pexels-photo-7788657.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अर्थ–वाणिज्य'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('economy')._id, getTag('stock-market')._id],
                content: [
                    { type: 'paragraph', content: 'विशेषगरी जलविद्युत र बैंकिङ समूहको सेयर मूल्यमा उल्लेख्य वृद्धि भएको छ। कारोबार रकमले पनि नयाँ रेकर्ड कायम गरेको छ।' },
                    { type: 'paragraph', content: 'लगानीकर्ताहरूले बजारको यो वृद्धिलाई सकारात्मक रूपमा लिएका छन्, तर लगानी गर्नुअघि कम्पनीको वित्तीय अवस्थाबारे राम्रोसँग अध्ययन गर्न विज्ञहरूले सुझाएका छन्।' }
                ]
            },
            {
                title: 'काठमाडौं-तराई द्रुतमार्ग निर्माण कार्यले गति लियो',
                summary: 'राष्ट्रिय गौरवको आयोजनाको रूपमा रहेको काठमाडौं-तराई/मधेश द्रुतमार्गको निर्माण कार्यले तीव्रता पाएको छ। नेपाली सेनाले निर्माणको जिम्मा लिएको छ।',
                imageUrl: 'https://images.pexels.com/photos/162024/scenery-road-highway-sky-162024.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('infrastructure')._id],
                content: [
                    { type: 'paragraph', content: 'आयोजना अन्तर्गत सुरुङ र पुलहरूको निर्माण कार्य तीव्र गतिमा अघि बढेको छ। यो द्रुतमार्ग बनेपछि काठमाडौंदेखि निजगढसम्मको यात्रा अवधि एक घण्टामा छोटिनेछ।' },
                    { type: 'paragraph', content: 'सेनाले तोकिएको समयमै आयोजना सम्पन्न गर्ने प्रतिबद्धता जनाएको छ। यसले देशको आर्थिक विकासमा महत्वपूर्ण योगदान पुर्याउने अपेक्षा गरिएको छ।' }
                ]
            },
            {
                title: 'नेपाली चलचित्र ‘ऐना’ अन्तर्राष्ट्रिय महोत्सवमा छनोट',
                summary: 'युवा निर्देशकले बनाएको नेपाली चलचित्र ‘ऐना’ प्रतिष्ठित बर्लिन अन्तर्राष्ट्रिय चलचित्र महोत्सवको प्रतिस्पर्धात्मक विधामा छनोट भएको छ।',
                imageUrl: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['कला र शैली'],
                author: authorUser._id,
                status: 'draft',
                tags: [getTag('entertainment')._id],
                content: [
                    { type: 'paragraph', content: 'सामाजिक विषयवस्तुमा आधारित यो चलचित्रले नेपाली समाजको यथार्थलाई चित्रण गरेको छ। यो नेपाली चलचित्र क्षेत्रका लागि एक ठूलो उपलब्धि हो।' },
                    { type: 'paragraph', content: 'निर्देशकले आफ्नो टोलीको कडा मिहिनेतले यो सफलता मिलेको बताएका छन्। महोत्सव अर्को महिना जर्मनीमा आयोजना हुँदैछ।' }
                ]
            },
             {
                title: 'जैविक खेतीमा युवाहरूको आकर्षण बढ्दो',
                summary: 'पछिल्लो समय वैदेशिक रोजगारीबाट फर्केका युवाहरू व्यावसायिक जैविक खेतीमा आकर्षित हुन थालेका छन्। यसले स्थानीय अर्थतन्त्रलाई बलियो बनाएको छ।',
                imageUrl: 'https://images.pexels.com/photos/235734/pexels-photo-235734.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अर्थ–वाणिज्य'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('agriculture')._id, getTag('economy')._id],
                content: [
                    { type: 'paragraph', content: 'काभ्रे, सिन्धुपाल्चोक जस्ता जिल्लाहरूमा युवाहरूले समूह बनाएर तरकारी तथा फलफूलको जैविक खेती गरिरहेका छन्। उनीहरूले उत्पादन गरेका वस्तुहरू सिधै काठमाडौंका बजारमा पुग्ने गरेको छ।' },
                    { type: 'paragraph', content: 'सरकारले पनि जैविक खेतीलाई प्रवर्द्धन गर्न विभिन्न अनुदानका कार्यक्रमहरू ल्याएको छ। यसले स्वस्थकर खाद्य उत्पादनमा पनि मद्दत पुगेको छ।' }
                ]
            },
             {
                title: 'मध्यपूर्वमा तनाव बढ्दो, तेलको मूल्य आकासियो',
                summary: 'मध्यपूर्वमा दुई देशबीचको तनावका कारण अन्तर्राष्ट्रिय बजारमा कच्चा तेलको मूल्य बढेको छ। यसको असर नेपालमा पनि पर्ने देखिएको छ।',
                imageUrl: 'https://images.pexels.com/photos/15239/fire-fighters-fire-man-fire-department.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['अन्तर्राष्ट्रिय'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('international')._id, getTag('economy')._id],
                content: [
                    { type: 'paragraph', content: 'अन्तर्राष्ट्रिय समाचार एजेन्सीहरूका अनुसार, प्रमुख तेल उत्पादक देशहरूबीचको वाकयुद्धले आपूर्ति श्रृंखलामा असर पर्ने आशंकाले मूल्य बढेको हो।' },
                    { type: 'paragraph', content: 'नेपाल आयल निगमले भने तत्काल मूल्य समायोजन गर्नेबारे कुनै निर्णय नभएको तर अवस्थाको विश्लेषण गरिरहेको जनाएको छ।' }
                ]
            },
            {
                title: 'महिला स्वास्थ्य स्वयंसेविकाहरूको भूमिकाको प्रशंसा',
                summary: 'विश्व स्वास्थ्य संगठन (WHO) ले नेपालको ग्रामीण स्वास्थ्य सेवामा महिला स्वास्थ्य स्वयंसेविकाहरूले खेलेको भूमिकाको उच्च प्रशंसा गरेको छ।',
                imageUrl: 'https://images.pexels.com/photos/5408817/pexels-photo-5408817.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाज'],
                author: editorUser._id,
                status: 'published',
                tags: [getTag('health')._id, getTag('social-issue')._id],
                content: [
                    { type: 'paragraph', content: 'एक प्रतिवेदन सार्वजनिक गर्दै WHO ले खोप कार्यक्रम, परिवार नियोजन, र मातृ तथा शिशु स्वास्थ्यमा स्वयंसेविकाहरूको योगदान अतुलनीय रहेको बताएको छ।' },
                    { type: 'paragraph', content: 'उनीहरूको निस्वार्थ सेवाले नेपालले स्वास्थ्य क्षेत्रका विभिन्न सूचकहरूमा उल्लेखनीय प्रगति हासिल गरेको प्रतिवेदनमा उल्लेख छ।' }
                ]
            },
            {
                title: 'आगामी जाडोमा बिजुली अभाव नहुने प्राधिकरणको दाबी',
                summary: 'नेपाल विद्युत प्राधिकरणले आन्तरिक उत्पादन बढेको र भारतबाट आवश्यक परेमा आयात गर्न सकिने भएकाले आगामी सुख्खायाममा लोडसेडिङ नहुने दाबी गरेको छ।',
                imageUrl: 'https://images.pexels.com/photos/414841/pexels-photo-414841.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['समाचार'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('infrastructure')._id],
                content: [
                    { type: 'paragraph', content: 'विगतका वर्षहरूमा जाडोयाममा नदीमा पानीको बहाव घट्दा बिजुली उत्पादन कम भई लोडसेडिङ हुने गरेको थियो। तर, पछिल्ला वर्षहरूमा नयाँ जलविद्युत आयोजनाहरू सञ्चालनमा आएका छन्।' },
                    { type: 'paragraph', content: 'प्राधिकरणले उपभोक्ताहरूलाई बिजुलीको खपतमा मितव्ययिता अपनाउन भने आग्रह गरेको छ। उद्योगहरूलाई रात्रिकालीन समयमा सञ्चालन गर्न पनि प्रोत्साहन गरिनेछ।' }
                ]
            },
            {
                title: 'राष्ट्रिय टोलीको बन्द प्रशिक्षण सुरु',
                summary: 'आगामी साफ च्याम्पियनशिपका लागि नेपाली राष्ट्रिय फुटबल टोलीले आजदेखि बन्द प्रशिक्षण सुरु गरेको छ।',
                imageUrl: 'https://images.pexels.com/photos/47730/the-ball-stadion-football-the-pitch-47730.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                categories: ['खेलकुद', 'फुटबल'],
                author: adminUser._id,
                status: 'published',
                tags: [getTag('sports')._id],
                content: [
                    { type: 'paragraph', content: 'मुख्य प्रशिक्षकले ३० खेलाडीलाई प्रारम्भिक चरणमा बोलाएका छन्। प्रशिक्षण एक महिनासम्म चल्नेछ र अन्तिममा २३ सदस्यीय टोलीको घोषणा गरिनेछ।' }
                ]
            },
        ];
        
        await Article.insertMany(sampleArticles);
        console.log('Sample Nepali articles seeded successfully.');
        
        // Fetch some articles to populate special sections
        const articlesForSections = await Article.find({ status: 'published' }).limit(10);
        if (articlesForSections.length < 10) {
            console.warn("Warning: Not enough published articles to fully seed special sections. Found only", articlesForSections.length);
        }

        // 5. Seed Homepage Special Sections (now populated and enabled)
        const specialSections = [
            { 
                title: 'विशेष कथाहरू', 
                key: 'featured', 
                layout: 'hero_1_4', 
                order: 0, 
                isEnabled: true,
                isDynamic: true, // This section will be dynamic
                sourceCategory: getCat('समाचार')._id,
                itemCount: 5,
                articles: [] // Manual articles are empty
            },
            { 
                title: 'सम्पादकको रोजाइ', 
                key: 'top_stories', 
                layout: 'split_70_30', 
                order: 2,
                isEnabled: true,
                isDynamic: false, // This section is manually curated
                articles: articlesForSections.slice(5, 10).map((article, index) => ({ article: article._id, order: index }))
            },
        ];
        await HomepageSection.insertMany(specialSections);
        console.log('Populated homepage sections seeded.');

        // 6. Seed Advertisements
        const adCategory = getCat('अर्थ–वाणिज्य');
        const sportsCategory = getCat('खेलकुद');
        if (adCategory && sportsCategory) {
            const sampleAds = [
                {
                    name: 'Homepage Top Banner - Main',
                    imageUrl: 'https://images.pexels.com/photos/3184433/pexels-photo-3184433.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com',
                    position: 'home_top_banner',
                    order: 0,
                    isEnabled: true
                },
                {
                    name: 'Sidebar Ad - Primary',
                    imageUrl: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com',
                    position: 'home_sidebar',
                    order: 10,
                    isEnabled: true
                },
                 {
                    name: 'Sidebar Ad - Secondary',
                    imageUrl: 'https://images.pexels.com/photos/593158/pexels-photo-593158.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com/sidebar2',
                    position: 'home_sidebar',
                    order: 11,
                    isEnabled: true
                },
                {
                    name: 'Homepage Section Ad (Economy)',
                    imageUrl: 'https://images.pexels.com/photos/1181345/pexels-photo-1181345.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com',
                    position: 'home_section_ad',
                    categoryId: adCategory._id,
                    order: 12,
                    isEnabled: true
                },
                {
                    name: 'Popup Modal Ad',
                    imageUrl: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    position: 'popup_modal',
                    order: 99,
                    isEnabled: true
                },
                {
                    name: 'Inline Ad (Sports)',
                    imageUrl: 'https://images.pexels.com/photos/262524/pexels-photo-262524.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com/sports',
                    position: 'inline_article',
                    categoryTargeting: [sportsCategory._id], // Targeted to Sports
                    isEnabled: true
                },
                {
                    name: 'Inline Ad (Economy)',
                    imageUrl: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com/finance',
                    position: 'inline_article',
                    categoryTargeting: [adCategory._id], // Targeted to Economy
                    isEnabled: true
                },
                {
                    name: 'Inline Ad (Generic)',
                    imageUrl: 'https://images.pexels.com/photos/163064/play-stone-network-networked-163064.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                    redirectUrl: 'https://example.com/generic',
                    position: 'inline_article',
                    categoryTargeting: [], // Not targeted to any category
                    isEnabled: true
                }
            ];
            const createdAds = await Advertisement.insertMany(sampleAds);
            console.log('Sample advertisements seeded.');
            
            // 7. Seed Sidebar Widgets
            const drishtikoneCat = getCat('दृष्टिकोण');
            const sidebarAds = createdAds.filter(ad => ad.position === 'home_sidebar');

            if (drishtikoneCat && sidebarAds.length > 0) {
                const defaultWidgets = [
                    { type: 'latest_articles', title: 'ताजा समाचार', itemCount: 5, order: 0, layout: 'list_with_thumbnails' },
                    { type: 'advertisement', title: 'Advertisement', itemCount: 1, order: 1, advertisementId: sidebarAds[0]._id },
                    { type: 'category_articles', title: 'दृष्टिकोण', categoryId: drishtikoneCat._id, itemCount: 4, order: 2, layout: 'simple_list' },
                ];
                await SidebarWidget.insertMany(defaultWidgets);
                console.log('Default sidebar widgets seeded.');
            } else {
                console.warn("Could not find 'दृष्टिकोण' category or sidebar ads for widget seeding. Skipping widget seeding.");
            }

        } else {
            console.warn("Could not find categories for ad seeding. Skipping some ads.");
        }
        
        console.log('Data Imported!');
        process.exit();

    } catch (error) {
        console.error(`Error importing data: ${error}`);
        process.exit(1);
    }
};

const destroyData = async () => {
    try {
        await Advertisement.deleteMany();
        await Article.deleteMany();
        await Category.deleteMany();
        await User.deleteMany();
        await SidebarWidget.deleteMany();
        await HomepageSection.deleteMany();
        await Tag.deleteMany();

        console.log('Data Destroyed!');
        process.exit();
    } catch (error) {
        console.error(`Error destroying data: ${error}`);
        process.exit(1);
    }
};

const run = async () => {
    await connectDB();
    if (process.argv[2] === '-d') {
        await destroyData();
    } else {
        await importData();
    }
};

run();