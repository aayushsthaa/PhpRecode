

import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';

import authRoutes from './routes/authRoutes.js';
import articleRoutes from './routes/articleRoutes.js';
import adRoutes from './routes/adRoutes.js';
import userRoutes from './routes/userRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import categoryRoutes from './routes/categoryRoutes.js';
import sidebarRoutes from './routes/sidebarRoutes.js';
import homepageRoutes from './routes/homepageRoutes.js';
import tagRoutes from './routes/tagRoutes.js';

dotenv.config();

if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET not set in .env file. Using a default, insecure secret.');
  process.env.JWT_SECRET = 'default-jwt-secret-for-development-only';
}

if (!process.env.MONGO_URI) {
  console.warn('WARNING: MONGO_URI not set in .env file. Using a default local MongoDB instance at mongodb://localhost:27017/echhapa-news.');
  process.env.MONGO_URI = 'mongodb://localhost:27017/echhapa-news';
}


const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB Connected...');

  } catch (error) {
    console.error(`
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!      DATABASE CONNECTION FAILED         !!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Error: ${error.message}
Please ensure your MONGO_URI in the .env file is correct or that a local MongoDB instance is running.`);
    process.exit(1);
  }
};

connectDB();

// Standard API routes
app.use('/api/auth', authRoutes);
app.use('/api/articles', articleRoutes);
app.use('/api/ads', adRoutes);
app.use('/api/account', userRoutes);
app.use('/api/management-panel', adminRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/sidebar', sidebarRoutes);
app.use('/api/homepage', homepageRoutes);
app.use('/api/tags', tagRoutes);


// Catch-all for 404 errors - this should be after all other routes
app.use((req, res, next) => {
    res.status(404).json({ message: `Not Found - ${req.originalUrl}` });
});

const PORT = process.env.PORT || 5001;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));