

import React, { useState, createContext, useContext, useEffect, useCallback, lazy, Suspense } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { Article, Category, Advertisement, User, SidebarWidget, FooterSettings } from './types';
import api from './services/api';

import Header from './components/Header';
import Footer from './components/Footer';
import Spinner from './components/Spinner';
import { FeedbackProvider, useFeedback } from './components/feedback/FeedbackProvider';
import NotificationContainer from './components/feedback/NotificationContainer';
import ConfirmationModal from './components/feedback/ConfirmationModal';
import PopupAdModal from './components/PopupAdModal';
import StickyFooterAd from './components/StickyFooterAd';

const { BrowserRouter, Routes, Route, Navigate, useLocation, useSearchParams, useNavigate, Link: RouterLink } = ReactRouterDOM;

// Lazy load page components
const HomePage = lazy(() => import('./pages/HomePage'));
const ArticlePage = lazy(() => import('./pages/ArticlePage'));
const SearchPage = lazy(() => import('./pages/SearchPage'));
const BookmarksPage = lazy(() => import('./pages/BookmarksPage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));
const RegisterPage = lazy(() => import('./pages/RegisterPage'));
const AdminPage = lazy(() => import('./pages/AdminPage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const TagPage = lazy(() => import('./pages/TagPage'));


interface AppContextType {
  articles: Article[];
  setArticles: React.Dispatch<React.SetStateAction<Article[]>>;
  addArticle: (article: Article) => void;
  updateArticle: (article: Article) => void;
  deleteArticle: (articleId: string) => void;
  categories: Category[];
  setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  advertisements: Advertisement[];
  setAdvertisements: React.Dispatch<React.SetStateAction<Advertisement[]>>;
  sidebarWidgets: SidebarWidget[];
  setSidebarWidgets: React.Dispatch<React.SetStateAction<SidebarWidget[]>>;
  homepageLayout: any[]; // Changed from homepageSections
  setHomepageLayout: React.Dispatch<React.SetStateAction<any[]>>; // Changed from setHomepageSections
  footerSettings: FooterSettings | null;
  setFooterSettings: React.Dispatch<React.SetStateAction<FooterSettings | null>>;
  
  user: User | null;
  token: string | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  login: (userData: User, token: string) => void;
  logout: () => void;
  updateUser: (userData: User) => void;
  toggleBookmark: (articleId: string) => Promise<void>;
  fetchPublicData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

const VerifyEmailPage: React.FC = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const token = searchParams.get('token');
    const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
    const [message, setMessage] = useState('Verifying your email...');

    useEffect(() => {
        if (!token) {
            setStatus('error');
            setMessage('No verification token found. Please check your link.');
            return;
        }

        const verify = async () => {
            try {
                const { data } = await api.post('/api/auth/verify-email', { token });
                setStatus('success');
                setMessage(data.message);
                setTimeout(() => navigate('/login'), 5000);
            } catch (err: any) {
                setStatus('error');
                setMessage(err.response?.data?.message || 'Verification failed. The token may be invalid or expired.');
            }
        };

        verify();
    }, [token, navigate]);
    
    return (
        <div className="max-w-md mx-auto mt-10 text-center">
            <div className="bg-white p-8 shadow-lg border">
                 <h2 className="text-2xl font-bold mb-4">Email Verification</h2>
                 {status === 'verifying' && <Spinner text={message} />}
                 {status === 'success' && <p className="text-green-600">{message} Redirecting to login page in 5 seconds...</p>}
                 {status === 'error' && <p className="text-red-600">{message}</p>}
                 {status !== 'verifying' && <RouterLink to="/login" className="mt-4 inline-block text-blue-600 hover:underline">Go to Login</RouterLink>}
            </div>
        </div>
    );
};

const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [advertisements, setAdvertisements] = useState<Advertisement[]>([]);
  const [sidebarWidgets, setSidebarWidgets] = useState<SidebarWidget[]>([]);
  const [homepageLayout, setHomepageLayout] = useState<any[]>([]); // Changed from homepageSections
  const [footerSettings, setFooterSettings] = useState<FooterSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Auth state
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const feedback = useFeedback();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser && token) {
      setUser(JSON.parse(storedUser));
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
  }, [token]);

  const login = (userData: User, token: string) => {
    localStorage.setItem('user', JSON.stringify(userData));
    localStorage.setItem('token', token);
    setUser(userData);
    setToken(token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  };

  const logout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setUser(null);
    setToken(null);
    delete api.defaults.headers.common['Authorization'];
  };
  
  const updateUser = (userData: User) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };
  
  const addArticle = (article: Article) => {
    setArticles(prevArticles => [article, ...prevArticles]);
  };
  
  const updateArticle = (updatedArticle: Article) => {
    setArticles(prevArticles => prevArticles.map(a => a._id === updatedArticle._id ? updatedArticle : a));
  };
  
  const deleteArticle = (articleId: string) => {
    setArticles(prevArticles => prevArticles.filter(a => a._id !== articleId));
  };

  const toggleBookmark = useCallback(async (articleId: string) => {
    if (!user) return;
    try {
      const response = await api.post('/api/account/bookmarks', { articleId });
      const updatedUser = response.data;
      updateUser(updatedUser);
       const isBookmarked = updatedUser.bookmarks.includes(articleId);
       feedback.showNotification(isBookmarked ? 'Article bookmarked!' : 'Bookmark removed.', 'success');
    } catch (error) {
      console.error('Failed to toggle bookmark', error);
      feedback.showNotification('Failed to update bookmarks. Please try again.', 'error');
    }
  }, [user, feedback]);
  
  const fetchPublicData = useCallback(async () => {
      try {
        const endpoints = [
            '/api/articles', 
            '/api/ads', 
            '/api/categories', 
            '/api/sidebar', 
            '/api/homepage',
            '/api/footer'
        ];
        
        const [
            articlesRes, 
            adsRes, 
            categoriesRes, 
            sidebarRes, 
            homepageRes,
            footerRes
        ] = await Promise.all(endpoints.map(url => api.get(url)));

        // Sanitize articles data to ensure arrays are present, as this is the most complex type
        const sanitizedArticles = Array.isArray(articlesRes.data)
          ? articlesRes.data.map((article: any) => ({
              ...article,
              categories: Array.isArray(article.categories) ? article.categories : [],
              tags: Array.isArray(article.tags) ? article.tags : [],
              content: Array.isArray(article.content) ? article.content : [],
          }))
          : [];
        
        setArticles(sanitizedArticles);
        setAdvertisements(Array.isArray(adsRes.data) ? adsRes.data : []);
        setCategories(Array.isArray(categoriesRes.data) ? categoriesRes.data : []);
        setSidebarWidgets(Array.isArray(sidebarRes.data) ? sidebarRes.data : []);
        setHomepageLayout(Array.isArray(homepageRes.data) ? homepageRes.data : []);
        setFooterSettings(footerRes.data);

      } catch (error) {
        console.error("A network error occurred while fetching public data. This could be a CORS issue or the server may be down.", error);
        setArticles([]);
        setAdvertisements([]);
        setCategories([]);
        setSidebarWidgets([]);
        setHomepageLayout([]);
        setFooterSettings(null);
      }
  }, []);

  useEffect(() => {
    const initialFetch = async () => {
        setIsLoading(true);
        await fetchPublicData();
        setIsLoading(false);
    }
    initialFetch();
  }, [fetchPublicData]);

  const value = {
    articles,
    setArticles,
    addArticle,
    updateArticle,
    deleteArticle,
    categories,
    setCategories,
    advertisements,
    setAdvertisements,
    sidebarWidgets,
    setSidebarWidgets,
    homepageLayout,
    setHomepageLayout,
    footerSettings,
    setFooterSettings,
    user,
    token,
    isLoggedIn: !!user,
    isLoading,
    login,
    logout,
    updateUser,
    toggleBookmark,
    fetchPublicData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

// This component determines the overall layout based on the current route
const AppLayout: React.FC = () => {
  const { isLoading, isLoggedIn, user } = useAppContext();
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');
  const isArticleRoute = location.pathname.startsWith('/article/');


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spinner text="Loading..." />
      </div>
    );
  }

  const PageWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (isAdminRoute) {
      return <>{children}</>;
    }
    // ArticlePage controls its own width now, so we don't wrap it.
    if (isArticleRoute) {
      return <>{children}</>;
    }
    return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">{children}</div>;
  };

  const hasDashboardAccess = isLoggedIn && user?.role && ['admin', 'editor', 'author'].includes(user.role);

  return (
    <div className="flex flex-col min-h-screen font-sans bg-white">
      {!isAdminRoute && <Header />}
      
      <main className="flex-grow">
        <PageWrapper>
          <Suspense fallback={
            <div className="flex justify-center items-center py-20">
                <Spinner text="Loading page..." />
            </div>
          }>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/category/:categoryName" element={<HomePage />} />
              <Route path="/tag/:tagName" element={<TagPage />} />
              <Route path="/article/:id" element={<ArticlePage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/profile" element={isLoggedIn ? <ProfilePage /> : <Navigate to="/login" />} />
              <Route path="/bookmarks" element={isLoggedIn ? <BookmarksPage /> : <Navigate to="/login" />} />
              <Route path="/admin/*" element={hasDashboardAccess ? <AdminPage /> : <Navigate to="/" />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/verify-email" element={<VerifyEmailPage />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </Suspense>
        </PageWrapper>
      </main>
      {!isAdminRoute && <PopupAdModal />}
      {!isAdminRoute && <StickyFooterAd />}
      {!isAdminRoute && <Footer />}
    </div>
  );
}

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <FeedbackProvider>
        <AppProvider>
            <AppLayout />
            <NotificationContainer />
            <ConfirmationModal />
        </AppProvider>
      </FeedbackProvider>
    </BrowserRouter>
  );
};

export default App;