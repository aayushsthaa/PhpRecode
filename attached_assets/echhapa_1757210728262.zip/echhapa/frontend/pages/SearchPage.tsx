

import React, { useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import NewsCard from '../components/NewsCard';
import { SearchIcon } from '../components/icons';

const { useLocation, Link } = ReactRouterDOM;

function useQuery() {
    const { search } = useLocation();
    return useMemo(() => new URLSearchParams(search), [search]);
}

const SearchPage: React.FC = () => {
    const { articles } = useAppContext();
    const query = useQuery().get('q');
    
    const searchResults = useMemo(() => {
        if (!query) return [];
        const lowercasedQuery = query.toLowerCase().trim();
        if (!lowercasedQuery) return [];
        return articles.filter(article => 
            article.title.toLowerCase().includes(lowercasedQuery) ||
            article.summary.toLowerCase().includes(lowercasedQuery) ||
            article.author.username.toLowerCase().includes(lowercasedQuery) ||
            article.content.some(block => block.type === 'paragraph' && block.content.toLowerCase().includes(lowercasedQuery))
        );
    }, [articles, query]);
    
    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">खोज परिणामहरू</h1>
            {query ? (
                <>
                    <p className="text-gray-600 mb-8 border-b pb-4">
                        <span className="font-semibold text-gray-800">"{query}"</span> को लागि {searchResults.length} {searchResults.length === 1 ? 'परिणाम' : 'परिणामहरू'} फेला पर्यो
                    </p>
                    {searchResults.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                            {searchResults.map(article => (
                                <NewsCard key={article._id} article={article} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 bg-white shadow-sm border">
                            <SearchIcon className="h-12 w-12 mx-auto text-gray-300" />
                            <h2 className="mt-4 text-2xl font-bold text-gray-800">कुनै परिणाम फेला परेन</h2>
                            <p className="text-gray-600 mt-2">तपाईंको खोजसँग मिल्ने कुनै लेख फेला परेन।</p>
                             <Link to="/" className="mt-6 inline-block px-6 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors">
                                गृहपृष्ठमा फर्कनुहोस्
                            </Link>
                        </div>
                    )}
                </>
            ) : (
                <div className="text-center py-16 bg-white shadow-sm border">
                    <h2 className="text-2xl font-bold text-gray-800">कृपया खोज शब्द प्रविष्ट गर्नुहोस्</h2>
                    <p className="text-gray-600 mt-2">लेखहरू फेला पार्न हेडरमा भएको खोज बाकस प्रयोग गर्नुहोस्।</p>
                </div>
            )}
        </div>
    );
};

export default SearchPage;