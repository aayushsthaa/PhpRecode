

import React, { useState } from 'react';
import { useAppContext } from '../App';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useFeedback } from '../components/feedback/FeedbackProvider';

const ProfilePage: React.FC = () => {
    const { user, updateUser, logout } = useAppContext();
    const { showNotification } = useFeedback();
    
    const [username, setUsername] = useState(user?.username || '');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (password && password !== confirmPassword) {
            showNotification('Passwords do not match.', 'error');
            return;
        }

        setIsLoading(true);
        try {
            const payload: { username: string; password?: string } = { username };
            if (password) {
                payload.password = password;
            }

            const response = await api.put('/api/account/profile', payload);
            updateUser(response.data);
            showNotification('Profile updated successfully!', 'success');
            setPassword('');
            setConfirmPassword('');

            if(payload.password) {
                showNotification('Password changed. Please log in again.', 'info');
                setTimeout(() => {
                    logout();
                }, 3000)
            }

        } catch (err: any) {
            showNotification(err.response?.data?.message || 'Failed to update profile.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto">
            <div className="bg-white p-8 shadow-lg border">
                <h1 className="text-3xl font-bold text-gray-800 mb-6 border-b pb-4">My Profile</h1>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                            Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            value={user?.email || ''}
                            className="w-full px-3 py-2 border border-gray-300 bg-gray-100 text-gray-500"
                            disabled
                        />
                    </div>
                    <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
                            Username
                        </label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                            required
                        />
                    </div>
                    <div className="border-t pt-6">
                      <p className="text-sm text-gray-500 mb-2">Leave passwords blank to keep current password.</p>
                       <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                                New Password
                            </label>
                            <input
                                type="password"
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                                minLength={5}
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="confirmPassword">
                            Confirm New Password
                        </label>
                        <input
                            type="password"
                            id="confirmPassword"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                        />
                    </div>
                    <div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors"
                        >
                            {isLoading ? <Spinner size="sm" /> : 'Update Profile'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ProfilePage;