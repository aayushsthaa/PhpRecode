

import React, { useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import { Article } from '../types';

const { useParams, Link } = ReactRouterDOM;

const HorizontalListItemCard: React.FC<{ article: Article }> = ({ article }) => (
    <Link to={`/article/${article._id}`} className="block group py-6 border-b last:border-b-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-2">
              <h3 className="text-2xl font-bold leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h3>
              <p className="text-md text-gray-600 mt-2">{article.summary}</p>
              <p className="text-sm text-gray-500 mt-2 font-sans">{article.author.username} &bull; {new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
          </div>
          {article.imageUrl && (
            <div className="md:col-span-1 h-48 overflow-hidden">
              <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
            </div>
          )}
        </div>
    </Link>
);

const TagPage: React.FC = () => {
    const { articles } = useAppContext();
    const { tagName } = useParams<{ tagName?: string }>();

    const filteredArticles = useMemo(() => {
        if (!tagName) return [];
        return articles.filter(article =>
            article.tags && article.tags.some(tag => tag.name.toLowerCase() === tagName.toLowerCase())
        );
    }, [articles, tagName]);

    return (
        <div className="max-w-5xl mx-auto py-8">
            <h1 className="text-4xl font-bold font-serif border-b pb-4 mb-8">
                Tag: <span className="text-blue-600"># {tagName}</span>
            </h1>

            {filteredArticles.length > 0 ? (
                <div className="flex flex-col">
                    {filteredArticles.map(article => <HorizontalListItemCard key={article._id} article={article} />)}
                </div>
            ) : (
                <p className="text-center py-16 text-gray-500">No articles found for this tag.</p>
            )}
        </div>
    );
};

export default TagPage;