

import React, { useState, useEffect, useCallback } from 'react';
import { SidebarWidget, AdPosition, Advertisement } from '../types';
import { useAppContext } from '../App';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useFeedback } from '../components/feedback/FeedbackProvider';

const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-100" />
);

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900" />
);

const Button = ({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: React.ReactNode }) => (
    <button {...props} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors">
        {children}
    </button>
);

const ManageSidebar: React.FC = () => {
    const { categories, advertisements, setSidebarWidgets } = useAppContext();
    const { showNotification, showConfirmation } = useFeedback();
    const [widgets, setWidgets] = useState<SidebarWidget[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const [newWidget, setNewWidget] = useState({
        type: 'latest_articles' as SidebarWidget['type'],
        title: '',
        categoryId: '',
        itemCount: 5,
        layout: 'list_with_thumbnails' as SidebarWidget['layout'],
        advertisementId: ''
    });

    const sidebarAds = advertisements.filter(ad => ad.position === AdPosition.HOME_SIDEBAR);

    const fetchWidgets = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/management-panel/sidebar-widgets');
            setWidgets(data);
        } catch (error) {
            showNotification('Failed to fetch sidebar widgets.', 'error');
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => {
        fetchWidgets();
    }, [fetchWidgets]);

    const handleAddNewWidget = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newWidget.type !== 'advertisement' && !newWidget.title) {
            showNotification('Widget title is required.', 'error');
            return;
        }
         if (newWidget.type === 'advertisement' && !newWidget.advertisementId) {
            showNotification('Please select an ad for the widget.', 'error');
            return;
        }

        const payload = {
            ...newWidget,
            title: newWidget.type === 'advertisement' ? 'Advertisement' : newWidget.title,
        };

        try {
            const { data } = await api.post('/api/management-panel/sidebar-widgets', payload);
            setWidgets(prev => [...prev, data]);
            setNewWidget({ type: 'latest_articles', title: '', categoryId: '', itemCount: 5, layout: 'list_with_thumbnails', advertisementId: '' });
            showNotification('Widget added successfully.', 'success');
        } catch (error) {
            showNotification('Failed to add widget.', 'error');
        }
    };

    const handleDeleteWidget = (id: string) => {
        showConfirmation('Delete Widget?', 'Are you sure you want to delete this widget?', async () => {
            try {
                await api.delete(`/api/management-panel/sidebar-widgets/${id}`);
                setWidgets(prev => prev.filter(w => w._id !== id));
                showNotification('Widget deleted.', 'success');
            } catch (error) {
                showNotification('Failed to delete widget.', 'error');
            }
        });
    };
    
    const handleMove = (index: number, direction: 'up' | 'down') => {
        const newWidgets = [...widgets];
        const item = newWidgets[index];
        const swapIndex = direction === 'up' ? index - 1 : index + 1;

        if (swapIndex < 0 || swapIndex >= newWidgets.length) return;
        
        [newWidgets[index], newWidgets[swapIndex]] = [newWidgets[swapIndex], newWidgets[index]];
        
        setWidgets(newWidgets.map((w, idx) => ({ ...w, order: idx })));
    };
    
    const handleSaveChanges = async () => {
        setIsSaving(true);
        try {
            const payload = widgets.map(w => ({ 
                ...w, 
                categoryId: (w.categoryId as any)?._id || w.categoryId,
                advertisementId: (w.advertisementId as any)?._id || w.advertisementId,
            }));

            await api.put('/api/management-panel/sidebar-widgets', { widgets: payload });
            
            // Refetch public sidebar data and update context to reflect changes immediately
            const { data } = await api.get('/api/sidebar');
            setSidebarWidgets(data);

            showNotification('Sidebar layout saved successfully!', 'success');
        } catch(error) {
            showNotification('Failed to save sidebar layout.', 'error');
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleWidgetChange = (id: string, field: keyof SidebarWidget, value: any) => {
        setWidgets(prev => prev.map(w => w._id === id ? { ...w, [field]: value } : w));
    }

    if (isLoading) return <Spinner />;

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 shadow-lg border">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold">Manage Homepage Sidebar</h3>
                    <Button onClick={handleSaveChanges} disabled={isSaving}>
                        {isSaving ? <Spinner size="sm" /> : 'Save Changes'}
                    </Button>
                </div>
                <div className="space-y-3">
                    {widgets.map((widget, index) => (
                        <div key={widget._id} className="p-4 border bg-gray-50 flex items-start gap-4">
                            <div className="flex-grow grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
                                {widget.type !== 'advertisement' ? (
                                    <>
                                        <Input 
                                            value={widget.title}
                                            onChange={(e) => handleWidgetChange(widget._id, 'title', e.target.value)}
                                            placeholder="Widget Title"
                                            className="lg:col-span-2"
                                        />
                                        <Select
                                            value={widget.layout || 'list_with_thumbnails'}
                                            onChange={(e) => handleWidgetChange(widget._id, 'layout', e.target.value as SidebarWidget['layout'])}
                                        >
                                            <option value="list_with_thumbnails">List with Thumbnails</option>
                                            <option value="simple_list">Simple List</option>
                                            <option value="featured_list">Featured List</option>
                                        </Select>
                                        <Input 
                                            type="number"
                                            value={widget.itemCount}
                                            onChange={(e) => handleWidgetChange(widget._id, 'itemCount', parseInt(e.target.value, 10))}
                                            min="1" max="10"
                                        />
                                    </>
                                ) : (
                                    <div className="lg:col-span-4">
                                        <Select
                                            value={(widget.advertisementId as Advertisement)?._id || (widget.advertisementId as string) || ''}
                                            onChange={(e) => handleWidgetChange(widget._id, 'advertisementId', e.target.value)}
                                        >
                                            <option value="">-- No Ad Selected --</option>
                                            {sidebarAds.map(ad => (
                                                <option key={ad._id} value={ad._id}>{ad.name}</option>
                                            ))}
                                        </Select>
                                    </div>
                                )}
                                {widget.type === 'category_articles' && (
                                     <Select
                                        value={typeof widget.categoryId === 'object' ? widget.categoryId._id : widget.categoryId}
                                        onChange={(e) => handleWidgetChange(widget._id, 'categoryId', e.target.value)}
                                        className="lg:col-span-4"
                                     >
                                         <option value="">Select Category</option>
                                        {categories.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
                                     </Select>
                                )}
                                <div className="lg:col-span-4">
                                    <p className="text-xs text-gray-500 font-mono uppercase">TYPE: {widget.type.replace(/_/g, ' ')}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                                <button onClick={() => handleMove(index, 'up')} disabled={index === 0} className="p-1 disabled:opacity-30 text-xl">&#x25B2;</button>
                                <button onClick={() => handleMove(index, 'down')} disabled={index === widgets.length - 1} className="p-1 disabled:opacity-30 text-xl">&#x25BC;</button>
                                <button onClick={() => handleDeleteWidget(widget._id)} className="text-sm bg-red-500 text-white px-2 py-1 hover:bg-red-600 ml-2">Delete</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-white p-6 shadow-lg border">
                <h3 className="text-xl font-bold mb-4">Add New Widget</h3>
                <form onSubmit={handleAddNewWidget} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div className="md:col-span-2">
                        <label className="block text-sm font-bold text-gray-700 mb-1">Widget Title</label>
                        <Input value={newWidget.title} onChange={e => setNewWidget(p => ({ ...p, title: e.target.value }))} placeholder="e.g. Latest News" disabled={newWidget.type === 'advertisement'}/>
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1">Widget Type</label>
                        <Select value={newWidget.type} onChange={e => setNewWidget(p => ({ ...p, type: e.target.value as any, categoryId: '', title: e.target.value === 'advertisement' ? 'Advertisement' : '' }))}>
                            <option value="latest_articles">Latest Articles</option>
                            <option value="category_articles">Category Articles</option>
                            <option value="advertisement">Advertisement</option>
                        </Select>
                    </div>
                    <div>
                         <Button type="submit" className="w-full">Add Widget</Button>
                    </div>

                    {newWidget.type === 'advertisement' && (
                        <div className="md:col-span-4">
                            <label className="block text-sm font-bold text-gray-700 mb-1">Select Ad</label>
                            <Select value={newWidget.advertisementId} onChange={e => setNewWidget(p => ({ ...p, advertisementId: e.target.value }))} required>
                                <option value="">-- Choose an advertisement --</option>
                                {sidebarAds.map(ad => (
                                    <option key={ad._id} value={ad._id}>{ad.name}</option>
                                ))}
                            </Select>
                        </div>
                     )}

                    {newWidget.type !== 'advertisement' && (
                        <>
                           {newWidget.type === 'category_articles' && (
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                                    <Select value={newWidget.categoryId} onChange={e => setNewWidget(p => ({ ...p, categoryId: e.target.value }))} required>
                                        <option value="">Select a category</option>
                                        {categories.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
                                    </Select>
                                </div>
                           )}
                            <div>
                                <label className="block text-sm font-bold text-gray-700 mb-1">Layout</label>
                                <Select value={newWidget.layout} onChange={e => setNewWidget(p => ({...p, layout: e.target.value as any}))}>
                                    <option value="list_with_thumbnails">List with Thumbnails</option>
                                    <option value="simple_list">Simple List</option>
                                    <option value="featured_list">Featured List</option>
                                </Select>
                            </div>
                             <div>
                                <label className="block text-sm font-bold text-gray-700 mb-1">Number of Articles</label>
                                <Input type="number" value={newWidget.itemCount} onChange={e => setNewWidget(p => ({ ...p, itemCount: parseInt(e.target.value, 10) || 1 }))} min="1" max="10" />
                            </div>
                        </>
                    )}
                </form>
            </div>
        </div>
    );
};

export default ManageSidebar;