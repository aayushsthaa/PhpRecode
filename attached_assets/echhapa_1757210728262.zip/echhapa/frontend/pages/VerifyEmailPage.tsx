import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { CheckCircleIcon, XCircleIcon } from '../components/icons';

const VerifyEmailPage: React.FC = () => {
    const { token } = useParams<{ token: string }>();
    const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
    const [message, setMessage] = useState('Verifying your email address...');

    useEffect(() => {
        if (!token) {
            setStatus('error');
            setMessage('No verification token provided. The link may be broken.');
            return;
        }

        const verifyToken = async () => {
            try {
                const response = await api.post(`/api/auth/verify/${token}`);
                setStatus('success');
                setMessage(response.data.message || 'Email verified successfully! You can now log in.');
            } catch (err: any) {
                setStatus('error');
                setMessage(err.response?.data?.message || 'Verification failed. The token may be invalid or expired.');
            }
        };

        verifyToken();
    }, [token]);

    return (
        <div className="max-w-lg mx-auto mt-10">
            <div className="bg-white p-8 shadow-lg border text-center">
                {status === 'verifying' && (
                    <>
                        <Spinner text={message} />
                    </>
                )}
                {status === 'success' && (
                    <>
                        <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto" />
                        <h2 className="text-2xl font-bold text-gray-800 mt-4">Verification Complete!</h2>
                        <p className="text-gray-600 mt-2">{message}</p>
                        <Link
                            to="/login"
                            className="mt-6 inline-block w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 focus:outline-none focus:shadow-outline transition-colors text-center"
                        >
                            Proceed to Login
                        </Link>
                    </>
                )}
                {status === 'error' && (
                    <>
                        <XCircleIcon className="h-16 w-16 text-red-500 mx-auto" />
                        <h2 className="text-2xl font-bold text-gray-800 mt-4">Verification Failed</h2>
                        <p className="text-gray-600 mt-2">{message}</p>
                         <Link
                            to="/register"
                            className="mt-6 inline-block w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 focus:outline-none focus:shadow-outline transition-colors text-center"
                        >
                            Try Registering Again
                        </Link>
                    </>
                )}
            </div>
        </div>
    );
};

export default VerifyEmailPage;
