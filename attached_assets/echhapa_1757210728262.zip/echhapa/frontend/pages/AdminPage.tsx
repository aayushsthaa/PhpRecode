


import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Advertisement, User, Article, Category, Tag } from '../types';
import { AdPosition } from '../types';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useAppContext } from '../App';
import * as ReactRouterDOM from 'react-router-dom';
import CreateArticlePage from './CreateArticlePage';
import EditArticlePage from './EditArticlePage';
import ManageSidebar from './ManageSidebar';
import ManageHomepage from './ManageHomepage';
import ManageFooter from './ManageFooter';
import { MenuIcon, XIcon, UserIcon, PencilIcon, TrashIcon, NewspaperIcon, GripVerticalIcon } from '../components/icons';
import { useFeedback } from '../components/feedback/FeedbackProvider';

const { Link, NavLink, Routes, Route, useNavigate } = ReactRouterDOM;

// --- Reusable UI Elements ---
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-100" />
);

const Textarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
    <textarea {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-100" />
);

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-200" />
);

const Button = ({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: React.ReactNode }) => (
    <button {...props} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors">
        {children}
    </button>
);

const ToggleSwitch: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; disabled?: boolean }> = ({ checked, onChange, disabled }) => (
    <label className={`relative inline-flex items-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" disabled={disabled} />
        <div className={`w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all ${disabled ? 'opacity-50' : ''} peer-checked:bg-blue-600`}></div>
    </label>
);


const formatDateForDateTimeLocal = (dateString?: string): string => {
    if (!dateString) return '';
    try {
        const d = new Date(dateString);
        if (isNaN(d.getTime())) return '';
        const pad = (num: number) => String(num).padStart(2, '0');
        const year = d.getFullYear();
        const month = pad(d.getMonth() + 1);
        const day = pad(d.getDate());
        const hours = pad(d.getHours());
        const minutes = pad(d.getMinutes());
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    } catch (e) {
        return '';
    }
};

const AccessDenied: React.FC = () => (
    <div className="bg-white p-8 shadow-lg border text-center">
        <h2 className="text-2xl font-bold text-red-600">Access Denied</h2>
        <p className="mt-2 text-gray-600">You do not have the necessary permissions to view this page.</p>
    </div>
);


// --- Sub-Pages / Components for Admin Panel ---

const AdminDashboard: React.FC = () => {
    const { user } = useAppContext();
    const [stats, setStats] = useState<any | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    // Redirect authors and editors to their main task page, as they don't need a general dashboard.
    if (user?.role === 'author' || user?.role === 'editor') {
        return <ReactRouterDOM.Navigate to="/admin/articles" replace />;
    }
    
    useEffect(() => {
        // This effect now only runs for admins.
        setIsLoading(true);
        api.get('/api/management-panel/stats')
           .then(res => setStats(res.data))
           .catch(err => console.error("Failed to fetch stats", err))
           .finally(() => setIsLoading(false));
    }, []);

    if (isLoading) return <div className="flex justify-center p-8"><Spinner /></div>;
    
    // Admin Dashboard
    if (!stats) return <p className="text-red-500">Failed to load dashboard stats.</p>
    
    const statItems = [
        { label: 'Total Users', value: stats.users, color: 'bg-indigo-500' },
        { label: 'Total Articles', value: stats.articles, color: 'bg-green-500' },
        { label: 'Draft Articles', value: stats.drafts, color: 'bg-yellow-500' },
        { label: 'Published Articles', value: stats.published, color: 'bg-blue-500' },
        { label: 'Total Ads', value: stats.ads, color: 'bg-purple-500' },
    ];

    return (
        <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${statItems.length} gap-6`}>
            {statItems.map(item => (
                <div key={item.label} className={`p-6 text-white shadow-lg ${item.color}`}>
                    <p className="text-lg font-medium">{item.label}</p>
                    <p className="text-4xl font-bold">{item.value}</p>
                </div>
            ))}
        </div>
    );
};

const ManageUsers: React.FC = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [formData, setFormData] = useState({ username: '', email: '', password: '', role: 'user' as User['role'] });
    const { showNotification, showConfirmation } = useFeedback();

    const fetchUsers = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/management-panel/manage-users');
            setUsers(data);
        } catch (error) { 
            showNotification("Failed to fetch users", "error");
            console.error("Failed to fetch users", error); 
        } finally { 
            setIsLoading(false); 
        }
    }, [showNotification]);

    useEffect(() => { fetchUsers(); }, [fetchUsers]);

    const openModal = (user: User | null = null) => {
        setEditingUser(user);
        setFormData(user ? { username: user.username, email: user.email, password: '', role: user.role || 'user' } : { username: '', email: '', password: '', role: 'user' });
        setIsModalOpen(true);
    };

    const closeModal = () => setIsModalOpen(false);

    const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const apiCall = editingUser ? api.put(`/api/management-panel/manage-users/${editingUser._id}`, formData) : api.post('/api/management-panel/manage-users', formData);
        try {
            await apiCall;
            showNotification(`User ${editingUser ? 'updated' : 'created'}.`, 'success');
            fetchUsers();
            closeModal();
        } catch (error) { 
            showNotification("Failed to save user.", "error");
            console.error("Failed to save user", error); 
        }
    };

    const handleDelete = (userId: string) => {
        showConfirmation(
            'Delete User?',
            'Are you sure you want to delete this user? This action cannot be undone.',
            async () => {
                try {
                    await api.delete(`/api/management-panel/manage-users/${userId}`);
                    showNotification("User deleted successfully.", 'success');
                    fetchUsers();
                } catch (error) {
                    showNotification('Failed to delete user.', 'error');
                    console.error("Failed to delete user", error);
                }
            }
        );
    };

    if (isLoading) return <Spinner />;

    return (
        <div className="bg-white p-6 shadow-lg border">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Manage Users</h3>
                <Button onClick={() => openModal()}>Add User</Button>
            </div>
            {/* User Table */}
            <div className="overflow-x-auto">
                <table className="w-full text-left admin-table">
                    <thead><tr className="bg-gray-100"><th className="p-3">Username</th><th className="p-3">Email</th><th className="p-3">Role</th><th className="p-3">Actions</th></tr></thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user._id} className="border-b">
                                <td className="p-3">{user.username}</td><td className="p-3">{user.email}</td><td className="p-3 uppercase text-xs font-bold">{user.role}</td>
                                <td className="p-3">
                                    <div className="flex items-center gap-4">
                                        <button onClick={() => openModal(user)} className="text-gray-500 hover:text-blue-600" title="Edit User"><PencilIcon className="h-5 w-5"/></button>
                                        <button onClick={() => handleDelete(user._id)} className="text-gray-500 hover:text-red-600" title="Delete User"><TrashIcon className="h-5 w-5"/></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Add/Edit Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-40 flex justify-center items-center p-4">
                    <div className="bg-white p-6 shadow-xl w-full max-w-md border">
                        <h4 className="text-lg font-bold mb-4">{editingUser ? 'Edit User' : 'Add New User'}</h4>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <Input name="username" value={formData.username} onChange={handleFormChange} placeholder="Username" required />
                            <Input name="email" type="email" value={formData.email} onChange={handleFormChange} placeholder="Email" required />
                            <Input name="password" type="password" value={formData.password} onChange={handleFormChange} placeholder={editingUser ? "New Password (optional)" : "Password"} required={!editingUser} />
                            <Select name="role" value={formData.role} onChange={handleFormChange}>
                                <option value="user">User</option>
                                <option value="author">Author</option>
                                <option value="editor">Editor</option>
                                <option value="admin">Admin</option>
                            </Select>
                            <div className="flex justify-end gap-2"><button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200">Cancel</button><Button type="submit">Save</Button></div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

const AdStatusBadge: React.FC<{ ad: Advertisement }> = ({ ad }) => {
    const now = new Date();
    const startDate = ad.startDate ? new Date(ad.startDate) : null;
    const endDate = ad.endDate ? new Date(ad.endDate) : null;

    let status: 'Active' | 'Scheduled' | 'Expired' | 'Disabled' = 'Active';
    let colorClasses = 'bg-green-100 text-green-800';

    if (!ad.isEnabled) {
        status = 'Disabled';
        colorClasses = 'bg-gray-100 text-gray-800';
    } else if (startDate && now < startDate) {
        status = 'Scheduled';
        colorClasses = 'bg-blue-100 text-blue-800';
    } else if (endDate && now > endDate) {
        status = 'Expired';
        colorClasses = 'bg-yellow-100 text-yellow-800';
    }
    
    return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${colorClasses}`}>{status}</span>;
};


const ManageAds: React.FC = () => {
    const { categories } = useAppContext();
    const [articles, setArticles] = useState<Article[]>([]);
    const [ads, setAds] = useState<Advertisement[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const { showNotification, showConfirmation } = useFeedback();
    
    // State for Create Form
    const initialCreateForm = { name: '', imageUrl: '', redirectUrl: '', position: AdPosition.HOME_SIDEBAR, articleId: '', categoryId: '', categoryTargeting: [] as string[], startDate: '', endDate: '', isEnabled: true };
    const [createFormData, setCreateFormData] = useState(initialCreateForm);

    // State for Edit Modal
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingAd, setEditingAd] = useState<Advertisement | null>(null);

    const fetchAdsAndArticles = useCallback(async () => {
        setIsLoading(true);
        try {
            const [adsRes, articlesRes] = await Promise.all([
                api.get('/api/management-panel/ads'),
                api.get('/api/management-panel/admin-articles')
            ]);
            setAds(adsRes.data);
            setArticles(articlesRes.data);
        } catch (error) { 
            showNotification("Failed to load ad data.", "error");
        } finally { 
            setIsLoading(false); 
        }
    }, [showNotification]);

    useEffect(() => { fetchAdsAndArticles(); }, [fetchAdsAndArticles]);

    // --- Edit Modal Logic ---
    const openEditModal = (ad: Advertisement) => {
        setEditingAd({
            ...ad,
            startDate: formatDateForDateTimeLocal(ad.startDate),
            endDate: formatDateForDateTimeLocal(ad.endDate),
            articleId: typeof ad.articleId === 'object' ? ad.articleId?._id : ad.articleId || '',
            categoryId: typeof ad.categoryId === 'object' ? ad.categoryId?._id : ad.categoryId || '',
            categoryTargeting: (ad.categoryTargeting || []).map(ct => typeof ct === 'object' ? ct._id : ct),
        });
        setIsEditModalOpen(true);
    };

    const closeEditModal = () => {
        setIsEditModalOpen(false);
        setEditingAd(null);
    };

    const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        if (!editingAd) return;
        const { name, value, type } = e.target;
        const isCheckbox = type === 'checkbox';
        const checked = (e.target as HTMLInputElement).checked;

        setEditingAd(prev => {
            if (!prev) return null;
            const newState = { ...prev, [name]: isCheckbox ? checked : value };
            if (name === 'position') {
                newState.articleId = '';
                newState.categoryId = '';
                newState.categoryTargeting = [];
            }
            return newState;
        });
    };
    
    const handleEditCategoryTargetingChange = (categoryId: string) => {
        if (!editingAd) return;
        setEditingAd(prev => {
            if (!prev) return null;
            const currentTargeting = prev.categoryTargeting || [];
            const newTargeting = currentTargeting.includes(categoryId)
                ? currentTargeting.filter(id => id !== categoryId)
                : [...currentTargeting, categoryId];
            return { ...prev, categoryTargeting: newTargeting };
        });
    };

    const handleUpdateAd = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingAd) return;
        try {
            const payload: any = { ...editingAd };
            if (!payload.articleId) delete payload.articleId;
            if (!payload.categoryId) delete payload.categoryId;
            if (!payload.redirectUrl) delete payload.redirectUrl;
            if (!payload.startDate) delete payload.startDate;
            if (!payload.endDate) delete payload.endDate;
            if (!payload.categoryTargeting || payload.categoryTargeting.length === 0) delete payload.categoryTargeting;


            await api.put(`/api/ads/${editingAd._id}`, payload);
            showNotification("Ad updated successfully.", "success");
            fetchAdsAndArticles();
            closeEditModal();
        } catch (error) {
            showNotification("Failed to update ad.", "error");
        }
    };
    
    // --- Create Form Logic ---
    const handleCreateFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const base64 = await fileToBase64(e.target.files[0]);
            setCreateFormData({ ...createFormData, imageUrl: base64 });
        }
    };
    
    const handleCreateFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setCreateFormData(prev => {
            const newState = { ...prev, [name]: value };
            if (name === 'position') {
                newState.articleId = '';
                newState.categoryId = '';
                newState.categoryTargeting = [];
            }
            return newState;
        });
    };
    
     const handleCreateCategoryTargetingChange = (categoryId: string) => {
        setCreateFormData(prev => {
            const currentTargeting = prev.categoryTargeting || [];
            const newTargeting = currentTargeting.includes(categoryId)
                ? currentTargeting.filter(id => id !== categoryId)
                : [...currentTargeting, categoryId];
            return { ...prev, categoryTargeting: newTargeting };
        });
    };

    const handleCreateSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const payload: any = { ...createFormData };
            if (!payload.articleId) delete payload.articleId;
            if (!payload.categoryId) delete payload.categoryId;
            if (!payload.redirectUrl) delete payload.redirectUrl;
            if (!payload.startDate) delete payload.startDate;
            if (!payload.endDate) delete payload.endDate;
            if (!payload.categoryTargeting || payload.categoryTargeting.length === 0) delete payload.categoryTargeting;

            await api.post('/api/ads', payload);
            showNotification("Ad created successfully.", "success");
            fetchAdsAndArticles();
            setCreateFormData(initialCreateForm);
        } catch (error) { 
            showNotification("Failed to create ad.", "error");
        }
    };
    
    // --- Delete Logic ---
    const handleDelete = async (adId: string) => {
       showConfirmation('Delete Ad?', 'Are you sure you want to delete this ad?', async () => {
         try {
            await api.delete(`/api/ads/${adId}`);
            showNotification("Ad deleted.", "success");
            fetchAdsAndArticles();
        } catch (error) { 
            showNotification("Failed to delete ad.", "error");
        }
       });
    };
    
    return (
        <div className="space-y-6">
            {/* --- Create Ad Form --- */}
            <div className="bg-white p-6 shadow-lg border">
                <h3 className="text-xl font-bold mb-4">Create New Ad</h3>
                <form onSubmit={handleCreateSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input name="name" value={createFormData.name} onChange={handleCreateFormChange} placeholder="Ad Name / Identifier" required />
                        <Input name="redirectUrl" value={createFormData.redirectUrl} onChange={handleCreateFormChange} placeholder="Redirect URL (optional)" />
                        <Select name="position" value={createFormData.position} onChange={handleCreateFormChange}>
                            {Object.values(AdPosition).map(pos => <option key={pos} value={pos}>{pos.replace(/_/g, ' ').toUpperCase()}</option>)}
                        </Select>
                        
                        {(createFormData.position === AdPosition.ARTICLE_TOP || createFormData.position === AdPosition.ARTICLE_BOTTOM || createFormData.position === AdPosition.ARTICLE_SIDEBAR) && (
                           <Select name="articleId" value={createFormData.articleId} onChange={handleCreateFormChange}>
                                <option value="">Target: All Articles</option>
                                {articles.map(article => <option key={article._id} value={article._id}>{article.title}</option>)}
                           </Select>
                        )}
                        {createFormData.position === AdPosition.HOME_SECTION_AD && (
                            <Select name="categoryId" value={createFormData.categoryId} onChange={handleCreateFormChange} required>
                                <option value="">Target Homepage Section</option>
                                {categories.filter(c => c.showOnHomepage).map(cat => <option key={cat._id} value={cat._id}>{cat.name}</option>)}
                            </Select>
                        )}
                    
                        <div className="md:col-span-1">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date (optional)</label>
                            <Input type="datetime-local" name="startDate" value={createFormData.startDate} onChange={handleCreateFormChange} />
                        </div>
                         <div className="md:col-span-1">
                            <label className="block text-sm font-medium text-gray-700 mb-1">End Date (optional)</label>
                            <Input type="datetime-local" name="endDate" value={createFormData.endDate} onChange={handleCreateFormChange} />
                        </div>
                        
                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Ad Image</label>
                            <Input type="file" onChange={handleCreateFileChange} required />
                        </div>
                    </div>
                    
                    {createFormData.position === AdPosition.INLINE_ARTICLE && (
                        <div className="space-y-2 border p-3 bg-gray-50">
                            <label className="font-bold text-sm">Category Targeting (for Inline Article Ads)</label>
                            <p className="text-xs text-gray-500">Show this ad only in articles from the selected categories. Leave all unchecked to show in all articles.</p>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-32 overflow-y-auto">
                                {categories.map(cat => (
                                    <label key={cat._id} className="flex items-center gap-2 text-sm">
                                        <input 
                                            type="checkbox" 
                                            checked={(createFormData.categoryTargeting || []).includes(cat._id)}
                                            onChange={() => handleCreateCategoryTargetingChange(cat._id)}
                                        />
                                        {cat.name}
                                    </label>
                                ))}
                            </div>
                        </div>
                    )}


                    <Button type="submit" className="w-full">Create Ad</Button>
                </form>
            </div>
            
            {/* --- Existing Ads Table --- */}
             <div className="bg-white p-6 shadow-lg border">
                <h3 className="text-xl font-bold mb-4">Existing Ads</h3>
                {isLoading ? <Spinner /> : (
                    <div className="overflow-x-auto">
                    <table className="w-full text-left admin-table">
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="p-3">Image</th><th className="p-3">Name</th><th className="p-3">Position & Target</th><th className="p-3">Schedule</th><th className="p-3">Status</th><th className="p-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        {ads.map(ad => (
                            <tr key={ad._id} className="border-b">
                                <td className="p-3"><img src={ad.imageUrl} alt="Ad" className="h-12 w-24 object-contain bg-gray-100" /></td>
                                <td className="p-3 font-semibold">{ad.name}</td>
                                <td className="p-3 text-sm">
                                    <span className="font-semibold block capitalize">{ad.position.replace(/_/g, ' ')}</span>
                                    {ad.position === AdPosition.HOME_SECTION_AD && ad.categoryId && (<span className="text-xs text-gray-500">Category: {(ad.categoryId as { name: string }).name}</span>)}
                                    {(ad.position === AdPosition.ARTICLE_TOP || ad.position === AdPosition.ARTICLE_BOTTOM || ad.position === AdPosition.ARTICLE_SIDEBAR) && ad.articleId && (<span className="text-xs text-gray-500 truncate block max-w-[200px]">Article: {(ad.articleId as { title: string }).title}</span>)}
                                    {ad.position === AdPosition.INLINE_ARTICLE && ad.categoryTargeting && ad.categoryTargeting.length > 0 && (<span className="text-xs text-gray-500 truncate block max-w-[200px]">Categories: {(ad.categoryTargeting as {name: string}[]).map(c=>c.name).join(', ')}</span>)}
                                </td>
                                <td className="p-3 text-xs text-gray-600">
                                    <div>Start: {ad.startDate ? new Date(ad.startDate).toLocaleDateString() : 'N/A'}</div>
                                    <div>End: {ad.endDate ? new Date(ad.endDate).toLocaleDateString() : 'N/A'}</div>
                                </td>
                                <td className="p-3"><AdStatusBadge ad={ad} /></td>
                                <td className="p-3">
                                    <div className="flex items-center gap-4">
                                        <button onClick={() => openEditModal(ad)} className="text-gray-500 hover:text-blue-600" title="Edit Ad"><PencilIcon className="h-5 w-5"/></button>
                                        <button onClick={() => handleDelete(ad._id)} className="text-gray-500 hover:text-red-600" title="Delete Ad"><TrashIcon className="h-5 w-5"/></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                    </div>
                )}
            </div>

            {/* --- Edit Ad Modal --- */}
            {isEditModalOpen && editingAd && (
                 <div className="fixed inset-0 bg-black/50 z-40 flex justify-center items-center p-4">
                    <form onSubmit={handleUpdateAd} className="bg-white p-6 shadow-xl w-full max-w-lg border space-y-4 max-h-[90vh] overflow-y-auto">
                        <h4 className="text-lg font-bold mb-2">Edit Ad</h4>
                         <Input name="name" value={editingAd.name} onChange={handleEditFormChange} placeholder="Ad Name / Identifier" required />
                        <Select name="position" value={editingAd.position} onChange={handleEditFormChange}>
                             {Object.values(AdPosition).map(pos => <option key={pos} value={pos}>{pos.replace(/_/g, ' ').toUpperCase()}</option>)}
                        </Select>

                        {(editingAd.position === AdPosition.ARTICLE_TOP || editingAd.position === AdPosition.ARTICLE_BOTTOM || editingAd.position === AdPosition.ARTICLE_SIDEBAR) && (
                           <Select name="articleId" value={editingAd.articleId ? (typeof editingAd.articleId === 'object' ? (editingAd.articleId as { _id: string })._id : editingAd.articleId as string) : ''} onChange={handleEditFormChange}>
                                <option value="">Target: All Articles in position</option>
                                {articles.map(article => <option key={article._id} value={article._id}>{article.title}</option>)}
                           </Select>
                        )}
                        {editingAd.position === AdPosition.HOME_SECTION_AD && (
                            <Select name="categoryId" value={editingAd.categoryId ? (typeof editingAd.categoryId === 'object' ? (editingAd.categoryId as { _id: string })._id : editingAd.categoryId as string) : ''} onChange={handleEditFormChange}>
                                <option value="">Select Target Homepage Section</option>
                                {categories.filter(c => c.showOnHomepage).map(cat => <option key={cat._id} value={cat._id}>{cat.name}</option>)}
                            </Select>
                        )}

                        <Input name="redirectUrl" value={editingAd.redirectUrl || ''} onChange={handleEditFormChange} placeholder="Redirect URL" />
                         <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date (optional)</label>
                            <Input type="datetime-local" name="startDate" value={editingAd.startDate || ''} onChange={handleEditFormChange} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">End Date (optional)</label>
                            <Input type="datetime-local" name="endDate" value={editingAd.endDate || ''} onChange={handleEditFormChange} />
                        </div>
                        {editingAd.position === AdPosition.INLINE_ARTICLE && (
                            <div className="space-y-2 border p-3 bg-gray-50">
                                <label className="font-bold text-sm">Category Targeting</label>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto">
                                    {categories.map(cat => (
                                        <label key={cat._id} className="flex items-center gap-2 text-sm">
                                            <input 
                                                type="checkbox" 
                                                checked={(editingAd.categoryTargeting || []).includes(cat._id)}
                                                onChange={() => handleEditCategoryTargetingChange(cat._id)}
                                            />
                                            {cat.name}
                                        </label>
                                    ))}
                                </div>
                            </div>
                        )}
                         <div className="flex items-center gap-2">
                             <input type="checkbox" id="isEnabled" name="isEnabled" checked={editingAd.isEnabled} onChange={handleEditFormChange} className="h-4 w-4" />
                             <label htmlFor="isEnabled" className="text-sm font-medium text-gray-700">Ad Enabled</label>
                         </div>
                        <div className="flex justify-end gap-2"><button type="button" onClick={closeEditModal} className="px-4 py-2 bg-gray-200">Cancel</button><Button type="submit">Save Changes</Button></div>
                    </form>
                </div>
            )}
        </div>
    );
};


const ManageArticles: React.FC = () => {
    const { user, updateArticle, deleteArticle } = useAppContext();
    const { showConfirmation, showNotification } = useFeedback();
    const [adminArticles, setAdminArticles] = useState<Article[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
    const [dateFilter, setDateFilter] = useState('any');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const ARTICLES_PER_PAGE = 10;

    const fetchAdminArticles = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/management-panel/admin-articles');
            setAdminArticles(data);
        } catch(error) {
            showNotification("Failed to load articles.", "error");
            console.error("Failed to fetch admin articles", error);
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => {
        fetchAdminArticles();
    }, [fetchAdminArticles]);
    
    useEffect(() => {
        if (dateFilter === 'custom') return;

        const now = new Date();
        const today = now.toISOString().split('T')[0];

        if (dateFilter === 'any') {
            setStartDate('');
            setEndDate('');
        } else if (dateFilter === 'today') {
            setStartDate(today);
            setEndDate(today);
        } else if (dateFilter === 'week') {
            const weekStart = new Date(now);
            weekStart.setDate(now.getDate() - now.getDay()); // Week starts on Sunday
            setStartDate(weekStart.toISOString().split('T')[0]);
            setEndDate(today);
        } else if (dateFilter === 'month') {
            const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
            setStartDate(monthStart.toISOString().split('T')[0]);
            setEndDate(today);
        }
    }, [dateFilter]);

    const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setStartDate(e.target.value);
        setDateFilter('custom');
    };
    const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setEndDate(e.target.value);
        setDateFilter('custom');
    };


    const handleDeleteArticle = async (articleId: string) => {
        showConfirmation("Delete Article?", "Are you sure you want to delete this article?", async () => {
             try {
                await api.delete(`/api/articles/${articleId}`);
                deleteArticle(articleId); 
                fetchAdminArticles();
                showNotification("Article deleted.", "success");
            } catch (error) { 
                showNotification("Failed to delete article.", "error");
                console.error("Failed to delete", error); 
            }
        });
    };
    
    const handleSetStatus = async (articleId: string, status: Article['status']) => {
        try {
            const { data } = await api.put(`/api/management-panel/admin-articles/${articleId}/status`, { status });
            setAdminArticles(prev => prev.map(a => a._id === articleId ? data : a));
            updateArticle(data);
            showNotification(`Article status updated to ${status}.`, "success");
        } catch(error) {
            showNotification("Failed to update status.", "error");
            console.error("Failed to set status", error);
        }
    };

    const processedArticles = useMemo(() => {
        let articlesToProcess = adminArticles;

        // For authors, only show their own articles
        if (user?.role === 'author') {
            articlesToProcess = adminArticles.filter(article => article.author._id === user._id);
        }

        let filtered = articlesToProcess.filter(article =>
            article.title.toLowerCase().includes(searchQuery.toLowerCase())
        );

        if (startDate) {
            const start = new Date(startDate);
            start.setHours(0, 0, 0, 0);
            filtered = filtered.filter(article => new Date(article.createdAt) >= start);
        }
        if (endDate) {
            const end = new Date(endDate);
            end.setHours(23, 59, 59, 999);
            filtered = filtered.filter(article => new Date(article.createdAt) <= end);
        }

        const sorted = [...filtered].sort((a, b) => {
            const dateA = new Date(a.createdAt).getTime();
            const dateB = new Date(b.createdAt).getTime();
            return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
        });

        return sorted;
    }, [adminArticles, searchQuery, sortOrder, startDate, endDate, user]);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, sortOrder, startDate, endDate]);

    const totalPages = Math.ceil(processedArticles.length / ARTICLES_PER_PAGE);
    const currentArticles = processedArticles.slice(
        (currentPage - 1) * ARTICLES_PER_PAGE,
        currentPage * ARTICLES_PER_PAGE
    );

    const paginate = (pageNumber: number) => {
        if (pageNumber > 0 && pageNumber <= totalPages) {
            setCurrentPage(pageNumber);
        }
    };

    const statusConfig = {
        published: 'bg-green-100 text-green-800',
        draft: 'bg-yellow-100 text-yellow-800',
        scheduled: 'bg-purple-100 text-purple-800',
    };
    
    if (isLoading) return <Spinner />;

    return (
        <div className="bg-white p-6 shadow-lg border">
            <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
               <h3 className="text-xl font-bold">Article Management</h3>
               <Link to="/admin/create-article" className="bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Create New</Link>
            </div>
             {/* Filters Section */}
            <div className="flex flex-wrap items-end gap-4 bg-gray-50 p-4 mb-4 border">
                <div className="flex-grow min-w-[200px]">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Search by Title</label>
                    <Input 
                        type="text"
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
                    <Select
                        value={sortOrder}
                        onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
                    >
                        <option value="newest">Newest First</option>
                        <option value="oldest">Oldest First</option>
                    </Select>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Date Filter</label>
                    <Select
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value)}
                    >
                        <option value="any">Any Time</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month">This Month</option>
                        <option value="custom">Custom Range</option>
                    </Select>
                </div>
                 <div className="flex items-end gap-2">
                    <Input 
                        type="date"
                        value={startDate}
                        onChange={handleStartDateChange}
                        disabled={dateFilter !== 'custom'}
                        aria-label="Start Date"
                    />
                    <span className="text-gray-500 pb-2">to</span>
                    <Input 
                        type="date"
                        value={endDate}
                        onChange={handleEndDateChange}
                        disabled={dateFilter !== 'custom'}
                        aria-label="End Date"
                    />
                </div>
            </div>

             <div className="overflow-x-auto">
                <table className="w-full text-left admin-table">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="p-4">Title</th>
                            {user?.role !== 'author' && <th className="p-4">Author</th>}
                            <th className="p-4">Categories</th>
                            <th className="p-4">Created Date</th>
                            <th className="p-4">Status</th>
                            <th className="p-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentArticles.map(article => (
                            <tr key={article._id}>
                                <td className="p-4 font-semibold">{article.title}</td>
                                {user?.role !== 'author' && <td className="p-4 text-sm text-gray-600">{article.author.username}</td>}
                                <td className="p-4 text-sm">{article.categories.join(', ')}</td>
                                <td className="p-4 text-sm text-gray-600">{new Date(article.createdAt).toLocaleDateString('ne-NP-u-nu-deva', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                                <td className="p-4">
                                    <Select 
                                        value={article.status}
                                        onChange={(e) => handleSetStatus(article._id, e.target.value as Article['status'])}
                                        disabled={user?.role === 'author'}
                                        className={`font-semibold text-xs py-1 px-2 border-0 rounded-full appearance-none focus:ring-2 focus:ring-blue-400 ${statusConfig[article.status]}`}
                                    >
                                        <option value="published">Published</option>
                                        <option value="draft">Draft</option>
                                        <option value="scheduled">Scheduled</option>
                                    </Select>
                                </td>
                                <td className="p-4">
                                    <div className="flex items-center gap-4">
                                        <Link to={`/admin/edit-article/${article._id}`} className="text-gray-500 hover:text-blue-600" title="Edit Article">
                                            <PencilIcon className="h-5 w-5" />
                                        </Link>
                                        {(user?.role === 'admin' || user?.role === 'editor' || (user?.role === 'author' && article.status === 'draft')) && (
                                            <button onClick={() => handleDeleteArticle(article._id)} className="text-gray-500 hover:text-red-600" title="Delete Article">
                                                <TrashIcon className="h-5 w-5" />
                                            </button>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
             {processedArticles.length === 0 && (
                <p className="text-center py-8 text-gray-500">No articles found matching your criteria.</p>
            )}

            {totalPages > 1 && (
                <div className="mt-6 flex justify-between items-center text-sm">
                    <button 
                        onClick={() => paginate(currentPage - 1)} 
                        disabled={currentPage === 1}
                        className="px-4 py-2 border disabled:opacity-50"
                    >
                        Previous
                    </button>
                    <span>Page {currentPage} of {totalPages}</span>
                    <button 
                        onClick={() => paginate(currentPage + 1)} 
                        disabled={currentPage === totalPages}
                        className="px-4 py-2 border disabled:opacity-50"
                    >
                        Next
                    </button>
                </div>
            )}
        </div>
    );
};

const ManageCategories: React.FC = () => {
    const { setCategories: setPublicCategories } = useAppContext();
    const { showNotification, showConfirmation } = useFeedback();
    
    const [categories, setCategories] = useState<Category[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    
    const [newCategoryName, setNewCategoryName] = useState('');
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingCategory, setEditingCategory] = useState<Category | null>(null);

    const [draggedItemId, setDraggedItemId] = useState<string | null>(null);

    const categoryTree = useMemo(() => {
        const itemMap = new Map(categories.map(item => [item._id, { ...item, children: [] as Category[] }]));
        const roots: Category[] = [];

        categories.forEach(item => {
            const currentItem = itemMap.get(item._id)!;
            const parentId = typeof item.parent === 'object' ? item.parent?._id : item.parent;
            if (parentId && itemMap.has(parentId)) {
                itemMap.get(parentId)!.children.push(currentItem);
            } else {
                roots.push(itemMap.get(item._id)!);
            }
        });

        itemMap.forEach(item => item.children.sort((a, b) => a.order - b.order));
        roots.sort((a, b) => a.order - b.order);

        return roots;
    }, [categories]);

    const fetchCategories = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/categories');
            setCategories(data);
        } catch (error) { 
            showNotification("Failed to load categories.", "error");
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => { fetchCategories(); }, [fetchCategories]);

    const handleAddCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newCategoryName) return;
        try {
            await api.post('/api/categories', { name: newCategoryName, parent: null });
            setNewCategoryName('');
            fetchCategories();
            showNotification("Category added.", "success");
        } catch (err: any) { 
            showNotification(err.response?.data?.message || "Failed to add category.", "error");
        }
    };
    
    const handleOpenEditModal = (category: Category) => {
        setEditingCategory(category);
        setIsEditModalOpen(true);
    };

    const handleUpdateCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingCategory) return;
        try {
            const payload = { name: editingCategory.name, seoTitle: editingCategory.seoTitle, metaDescription: editingCategory.metaDescription };
            await api.put(`/api/categories/${editingCategory._id}`, payload);
            fetchCategories();
            setIsEditModalOpen(false);
            setEditingCategory(null);
            showNotification("Category updated.", "success");
        } catch (err: any) {
            showNotification(err.response?.data?.message || "Failed to update category.", "error");
        }
    };

    const handleDeleteCategory = async (categoryId: string) => {
        showConfirmation("Delete Category?", "Are you sure? This will remove sub-categories and un-categorize articles.", async () => {
            try {
                await api.delete(`/api/categories/${categoryId}`);
                fetchCategories();
                showNotification("Category deleted.", "success");
            } catch (err: any) { 
                showNotification(err.response?.data?.message || "Failed to delete category.", "error");
            }
        });
    };

    const handleSaveSettings = async () => {
        setIsSaving(true);
        try {
            const payload: { _id: string; order: number; parent: string | null | undefined; showInNav: boolean; }[] = categories.map(({ _id, order, parent, showInNav }) => ({
                _id,
                order,
                parent: typeof (parent as any) === 'object' && (parent as any) ? (parent as any)._id : (parent as any),
                showInNav
            }));
            await api.put('/api/management-panel/categories/settings', { categories: payload });
            const { data } = await api.get('/api/categories');
            setPublicCategories(data);
            showNotification("Category settings saved!", "success");
        } catch(e) {
            showNotification("Failed to save settings.", "error");
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleDrop = (targetItemId: string | null, dropPosition: 'before' | 'after' | 'on') => {
        if (!draggedItemId) return;

        let newItems = [...categories];
        const draggedItemIndex = newItems.findIndex(i => i._id === draggedItemId)!;
        const draggedItem = newItems[draggedItemIndex];

        const targetItem = newItems.find(i => i._id === targetItemId);

        let newParentId: string | null | undefined = null;
        if (dropPosition === 'on' && targetItem) {
            newParentId = targetItem._id;
        } else {
            const parentOfTarget = targetItem ? targetItem.parent : null;
            newParentId = typeof (parentOfTarget as any) === 'object' && (parentOfTarget as any) ? (parentOfTarget as any)._id : (parentOfTarget as any);
        }
        (draggedItem as any).parent = newParentId;

        const siblings = newItems.filter(i => {
            const itemParent = (i as any).parent;
            const itemParentId = (typeof itemParent === 'object' && itemParent) ? itemParent._id : itemParent;
            return itemParentId === newParentId;
        });
        
        // Re-calculate order for all siblings
        siblings.forEach((item, index) => { item.order = index; });
        
        setCategories(newItems);
        setDraggedItemId(null);
    };

    const handleCategorySettingChange = (id: string, field: keyof Category, value: any) => {
        setCategories(prev => prev.map(cat => cat._id === id ? { ...cat, [field]: value } : cat));
    };

    const CategoryListItem: React.FC<{ category: Category, level: number }> = ({ category, level }) => {
       const [isOver, setIsOver] = useState(false);
       const [dropTarget, setDropTarget] = useState<'top' | 'bottom' | 'middle' | null>(null);

       const handleDragOver = (e: React.DragEvent) => {
            e.preventDefault();
            if (draggedItemId === category._id) return;
            const rect = e.currentTarget.getBoundingClientRect();
            const y = e.clientY - rect.top;
            if (y < rect.height * 0.25) setDropTarget('top');
            else if (y > rect.height * 0.75) setDropTarget('bottom');
            else setDropTarget('middle');
        };
        
        return (
            <div>
                 <div
                    draggable
                    onDragStart={() => setDraggedItemId(category._id)}
                    onDragEnd={() => { setDraggedItemId(null); setIsOver(false); setDropTarget(null); }}
                    onDragOver={handleDragOver}
                    onDragEnter={() => setIsOver(true)}
                    onDragLeave={() => { setIsOver(false); setDropTarget(null); }}
                    onDrop={() => {
                        if (dropTarget === 'top') handleDrop(category._id, 'before');
                        else if (dropTarget === 'bottom') handleDrop(category._id, 'after');
                        else handleDrop(category._id, 'on');
                        setIsOver(false);
                        setDropTarget(null);
                    }}
                    className="flex items-center p-2 border bg-white relative transition-all duration-200"
                    style={{ marginLeft: `${level * 30}px`, opacity: draggedItemId === category._id ? 0.5 : 1 }}
                >
                    {isOver && dropTarget === 'top' && <div className="absolute top-0 left-0 right-0 h-1 bg-blue-500 z-10"></div>}
                    {isOver && dropTarget === 'bottom' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500 z-10"></div>}
                    {isOver && dropTarget === 'middle' && <div className="absolute inset-0 border-2 border-blue-500 pointer-events-none z-10"></div>}

                    <GripVerticalIcon className="h-5 w-5 text-gray-400 cursor-move mr-2 flex-shrink-0" />
                    <span className="font-semibold flex-grow">{category.name}</span>
                    <div className="flex items-center gap-4 flex-shrink-0">
                        <label className="flex items-center gap-2 text-sm">
                            Show in Nav:
                            <ToggleSwitch checked={category.showInNav} onChange={(checked) => handleCategorySettingChange(category._id, 'showInNav', checked)} />
                        </label>
                        <button onClick={() => handleOpenEditModal(category)} className="text-gray-500 hover:text-blue-600"><PencilIcon className="h-5 w-5"/></button>
                        <button onClick={() => handleDeleteCategory(category._id)} className="text-gray-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                    </div>
                </div>
                {category.children && (category.children as Category[]).map(child => <CategoryListItem key={child._id} category={child} level={level + 1} />)}
            </div>
        );
    };

    return (
        <div className="bg-white p-6 shadow-lg border">
            <div className="flex justify-between items-center mb-4 pb-4 border-b">
                <div>
                    <h3 className="text-xl font-bold">Category & Navigation Management</h3>
                    <p className="text-sm text-gray-500">Drag and drop to reorder and create sub-categories. This structure controls the main website navigation.</p>
                </div>
                <Button onClick={handleSaveSettings} disabled={isSaving}>{isSaving ? <Spinner size="sm" /> : 'Save Settings'}</Button>
            </div>
            <form onSubmit={handleAddCategory} className="flex gap-4 mb-6">
                <Input type="text" value={newCategoryName} onChange={e => setNewCategoryName(e.target.value)} placeholder="Add new top-level category..." required/>
                <Button type="submit">Add Category</Button>
            </form>
            
            {isLoading ? <Spinner /> : (
                <div className="space-y-1">
                    {categoryTree.map(cat => <CategoryListItem key={cat._id} category={cat} level={0} />)}
                </div>
            )}

            {isEditModalOpen && editingCategory && (
                <div className="fixed inset-0 bg-black/50 z-40 flex justify-center items-center p-4">
                    <form onSubmit={handleUpdateCategory} className="bg-white p-6 shadow-xl w-full max-w-lg border space-y-4">
                        <h4 className="text-lg font-bold">Edit Category: {editingCategory.name}</h4>
                        <Input value={editingCategory.name} onChange={e => setEditingCategory(p => ({...p!, name: e.target.value}))} required />
                        <Textarea value={editingCategory.seoTitle || ''} onChange={e => setEditingCategory(p => ({...p!, seoTitle: e.target.value}))} placeholder="SEO Title" />
                        <Textarea value={editingCategory.metaDescription || ''} onChange={e => setEditingCategory(p => ({...p!, metaDescription: e.target.value}))} placeholder="Meta Description" />
                        <div className="flex justify-end gap-2">
                            <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 bg-gray-200">Cancel</button>
                            <Button type="submit">Save</Button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
};

const ManageTags: React.FC = () => {
    const [tags, setTags] = useState<Tag[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingTag, setEditingTag] = useState<Tag | null>(null);
    const [tagName, setTagName] = useState('');
    const { showNotification, showConfirmation } = useFeedback();

    const fetchTags = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/tags');
            setTags(data);
        } catch (error) {
            showNotification('Failed to fetch tags', 'error');
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => {
        fetchTags();
    }, [fetchTags]);

    const openModal = (tag: Tag | null = null) => {
        setEditingTag(tag);
        setTagName(tag ? tag.name : '');
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingTag(null);
        setTagName('');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const apiCall = editingTag
            ? api.put(`/api/tags/${editingTag._id}`, { name: tagName })
            : api.post('/api/tags', { name: tagName });
        try {
            await apiCall;
            showNotification(`Tag ${editingTag ? 'updated' : 'created'}.`, 'success');
            fetchTags();
            closeModal();
        } catch (error: any) {
            showNotification(error.response?.data?.message || 'Failed to save tag.', 'error');
        }
    };

    const handleDelete = (tagId: string) => {
        showConfirmation('Delete Tag?', 'Are you sure? This will remove the tag from all associated articles.', async () => {
            try {
                await api.delete(`/api/tags/${tagId}`);
                showNotification('Tag deleted successfully.', 'success');
                fetchTags();
            } catch (error) {
                showNotification('Failed to delete tag.', 'error');
            }
        });
    };

    if (isLoading) return <Spinner />;

    return (
        <div className="bg-white p-6 shadow-lg border">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Manage Tags</h3>
                <Button onClick={() => openModal()}>Add Tag</Button>
            </div>
            <ul className="space-y-2">
                {tags.map(tag => (
                    <li key={tag._id} className="flex justify-between items-center p-2 border">
                        <span>{tag.name}</span>
                        <div className="flex gap-2">
                            <button onClick={() => openModal(tag)} className="text-sm bg-yellow-500 text-white px-3 py-1 hover:bg-yellow-600">Edit</button>
                            <button onClick={() => handleDelete(tag._id)} className="text-sm bg-red-500 text-white px-3 py-1 hover:bg-red-600">Delete</button>
                        </div>
                    </li>
                ))}
            </ul>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 z-40 flex justify-center items-center p-4">
                    <div className="bg-white p-6 shadow-xl w-full max-w-md border">
                        <h4 className="text-lg font-bold mb-4">{editingTag ? 'Edit Tag' : 'Add New Tag'}</h4>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <Input value={tagName} onChange={e => setTagName(e.target.value)} placeholder="Tag name" required />
                            <div className="flex justify-end gap-2">
                                <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200">Cancel</button>
                                <Button type="submit">Save</Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

const AdminProfile: React.FC = () => {
    const { user, updateUser, logout } = useAppContext();
    const { showNotification } = useFeedback();
    const [username, setUsername] = useState(user?.username || '');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            const payload = { username, ...(password && { password }) };
            const { data } = await api.put('/api/account/profile', payload);
            updateUser(data);
            showNotification('Profile updated successfully!', 'success');
            if (password) {
                 showNotification('Password changed. Please log in again.', 'info');
                 setTimeout(() => logout(), 2000);
            }
        } catch (err: any) {
            showNotification(err.response?.data?.message || 'Update failed', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="bg-white p-6 shadow-lg border max-w-lg mx-auto">
            <h3 className="text-xl font-bold mb-4">My Admin Profile</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-bold text-gray-700">Email</label>
                    <Input type="email" value={user?.email} disabled />
                </div>
                <div>
                    <label className="block text-sm font-bold text-gray-700">Username</label>
                    <Input type="text" value={username} onChange={e => setUsername(e.target.value)} required />
                </div>
                <div>
                    <label className="block text-sm font-bold text-gray-700">New Password (optional)</label>
                    <Input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Leave blank to keep current" />
                </div>
                <Button type="submit" disabled={isLoading}>{isLoading ? 'Saving...' : 'Save Profile'}</Button>
            </form>
        </div>
    );
};

// --- Main Admin Page Layout ---

const AdminPage: React.FC = () => {
    const { user, logout } = useAppContext();
    const navigate = useNavigate();
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [isProfileOpen, setIsProfileOpen] = useState(false);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };
    
    const allTabs = [
        { id: 'dashboard', label: 'Dashboard', path: '/admin', roles: ['admin', 'editor', 'author'] },
        { id: 'articles', label: 'Article Management', path: '/admin/articles', roles: ['admin', 'editor', 'author'] },
        { id: 'categories', label: 'Category & Nav', path: '/admin/categories', roles: ['admin', 'editor'] },
        { id: 'tags', label: 'Tag Management', path: '/admin/tags', roles: ['admin', 'editor'] },
        { id: 'homepage', label: 'Homepage Sections', path: '/admin/homepage', roles: ['admin'] },
        { id: 'sidebar', label: 'Sidebar Layout', path: '/admin/sidebar', roles: ['admin'] },
        { id: 'footer', label: 'Footer Settings', path: '/admin/footer', roles: ['admin'] },
        { id: 'users', label: 'User Management', path: '/admin/users', roles: ['admin'] },
        { id: 'ads', label: 'Ad Management', path: '/admin/ads', roles: ['admin'] },
    ];

    const visibleTabs = useMemo(() => {
        if (!user?.role) return [];
        return allTabs.filter(tab => tab.roles.includes(user.role!));
    }, [user?.role]);
    
    return (
        <div className="flex h-screen bg-gray-100 font-sans">
            {/* Sidebar */}
            <aside className={`bg-gray-800 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition-transform duration-200 ease-in-out z-30 flex flex-col`}>
                <div>
                    <Link to="/admin" className="text-white flex items-center space-x-2 px-4">
                        <span className="text-2xl font-extrabold">Echhapa Panel</span>
                    </Link>
                    <nav className="mt-6">
                        {visibleTabs.map(tab => (
                            <NavLink key={tab.id} to={tab.path} end={tab.path === '/admin'} onClick={() => setIsSidebarOpen(false)} className={({ isActive }) => `block py-2.5 px-4 transition duration-200 ${isActive ? 'bg-gray-700' : 'hover:bg-gray-700'}`}>
                                {tab.label}
                            </NavLink>
                        ))}
                    </nav>
                </div>
                <div className="mt-auto p-4">
                     <Link to="/" className="w-full text-center block py-2.5 px-4 transition duration-200 bg-gray-700 hover:bg-gray-600">View Public Site</Link>
                </div>
            </aside>
            
            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-hidden">
                {/* Top Header */}
                <header className="bg-white shadow-sm z-10">
                    <div className="flex items-center justify-between h-16 px-6">
                        <button onClick={() => setIsSidebarOpen(true)} className="text-gray-500 focus:outline-none md:hidden">
                            <MenuIcon className="h-6 w-6" />
                        </button>
                        <div className="flex-1"></div> {/* Spacer */}
                        <div className="relative">
                            <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="flex items-center space-x-2">
                                <UserIcon className="h-6 w-6 text-gray-600"/>
                                <span className="hidden md:inline">{user?.username} ({user?.role})</span>
                            </button>
                            {isProfileOpen && (
                                <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg py-1 z-20 border">
                                    <Link to="/admin/profile" onClick={() => setIsProfileOpen(false)} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Profile</Link>
                                    <button onClick={handleLogout} className="w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</button>
                                </div>
                            )}
                        </div>
                    </div>
                </header>
                
                {/* Page Content */}
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
                    <Routes>
                        <Route path="/" element={<AdminDashboard />} />
                        <Route path="/articles" element={<ManageArticles />} />
                        <Route path="/create-article" element={<CreateArticlePage />} />
                        <Route path="/edit-article/:id" element={<EditArticlePage />} />
                        <Route path="/categories" element={user?.role !== 'author' ? <ManageCategories /> : <AccessDenied />} />
                        <Route path="/tags" element={user?.role !== 'author' ? <ManageTags /> : <AccessDenied />} />
                        <Route path="/homepage" element={user?.role === 'admin' ? <ManageHomepage /> : <AccessDenied />} />
                        <Route path="/sidebar" element={user?.role === 'admin' ? <ManageSidebar /> : <AccessDenied />} />
                        <Route path="/footer" element={user?.role === 'admin' ? <ManageFooter /> : <AccessDenied />} />
                        <Route path="/users" element={user?.role === 'admin' ? <ManageUsers /> : <AccessDenied />} />
                        <Route path="/ads" element={user?.role === 'admin' ? <ManageAds /> : <AccessDenied />} />
                        <Route path="/profile" element={<AdminProfile />} />
                    </Routes>
                </main>
            </div>
        </div>
    );
};

export default AdminPage;