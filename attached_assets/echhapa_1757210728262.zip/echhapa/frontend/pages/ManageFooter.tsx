

import React, { useState, useEffect, useCallback } from 'react';
import { FooterSettings, FooterLinkColumn, SocialLink } from '../types';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useFeedback } from '../components/feedback/FeedbackProvider';
import { XIcon, TrashIcon } from '../components/icons';

const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-100" />
);

const Textarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
    <textarea {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-100" />
);

const Button = ({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: React.ReactNode }) => (
    <button {...props} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors">
        {children}
    </button>
);


const ManageFooter: React.FC = () => {
    const { showNotification } = useFeedback();
    const [settings, setSettings] = useState<Partial<FooterSettings>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const fetchSettings = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/management-panel/footer');
            setSettings(data || {});
        } catch (error) {
            showNotification('Failed to load footer settings.', 'error');
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => {
        fetchSettings();
    }, [fetchSettings]);

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await api.put('/api/management-panel/footer', settings);
            showNotification('Footer settings saved!', 'success');
        } catch (error) {
            showNotification('Failed to save settings.', 'error');
        } finally {
            setIsSaving(false);
        }
    };
    
    // --- Handlers for nested state changes ---

    const handleSocialChange = (index: number, field: keyof SocialLink, value: string) => {
        const newSocials = [...(settings.socialLinks || [])];
        const updatedLink = { ...newSocials[index] };
        if (field === 'platform') {
            updatedLink.platform = value as SocialLink['platform'];
        } else if (field === 'url') {
            updatedLink.url = value;
        }
        newSocials[index] = updatedLink;
        setSettings(s => ({ ...s, socialLinks: newSocials }));
    };

    const handleAddSocial = () => {
        const newLink: SocialLink = { platform: 'x', url: '' };
        const newSocials = [...(settings.socialLinks || []), newLink];
        setSettings(s => ({ ...s, socialLinks: newSocials }));
    };

    const handleRemoveSocial = (index: number) => {
        const newSocials = (settings.socialLinks || []).filter((_, i) => i !== index);
        setSettings(s => ({ ...s, socialLinks: newSocials }));
    };

    const handleColumnTitleChange = (colIndex: number, title: string) => {
        const newColumns = [...(settings.linkColumns || [])];
        newColumns[colIndex].title = title;
        setSettings(s => ({ ...s, linkColumns: newColumns }));
    };

    const handleAddColumn = () => {
        const newColumns = [...(settings.linkColumns || []), { title: 'New Column', links: [] }];
        setSettings(s => ({ ...s, linkColumns: newColumns }));
    };
    
    const handleRemoveColumn = (colIndex: number) => {
        const newColumns = (settings.linkColumns || []).filter((_, i) => i !== colIndex);
        setSettings(s => ({...s, linkColumns: newColumns }));
    }

    const handleLinkChange = (colIndex: number, linkIndex: number, field: 'label' | 'url', value: string) => {
        const newColumns = [...(settings.linkColumns || [])];
        newColumns[colIndex].links[linkIndex] = { ...newColumns[colIndex].links[linkIndex], [field]: value };
        setSettings(s => ({...s, linkColumns: newColumns }));
    };
    
    const handleAddLink = (colIndex: number) => {
         const newColumns = [...(settings.linkColumns || [])];
         newColumns[colIndex].links.push({ label: 'New Link', url: '#' });
         setSettings(s => ({...s, linkColumns: newColumns }));
    };
    
    const handleRemoveLink = (colIndex: number, linkIndex: number) => {
         const newColumns = [...(settings.linkColumns || [])];
         newColumns[colIndex].links = newColumns[colIndex].links.filter((_, i) => i !== linkIndex);
         setSettings(s => ({...s, linkColumns: newColumns }));
    };

    if (isLoading) return <Spinner />;

    return (
        <div className="bg-white p-6 shadow-lg border">
            <div className="flex justify-between items-center mb-6 pb-4 border-b">
                <h3 className="text-xl font-bold">Footer Settings</h3>
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving ? <Spinner size="sm"/> : 'Save All Changes'}
                </Button>
            </div>
            
            <div className="space-y-8">
                {/* General Info */}
                <div className="space-y-4">
                    <h4 className="text-lg font-semibold">General</h4>
                    <div><label className="font-bold text-sm">Description</label><Textarea value={settings.description} onChange={e => setSettings(s => ({...s, description: e.target.value}))} rows={3}/></div>
                    <div><label className="font-bold text-sm">Copyright Text</label><Input value={settings.copyrightText} onChange={e => setSettings(s => ({...s, copyrightText: e.target.value}))}/></div>
                </div>

                {/* Social Links */}
                <div>
                    <div className="flex items-center justify-between mb-2"><h4 className="text-lg font-semibold">Social Media Links</h4><Button type="button" onClick={handleAddSocial}>Add Social</Button></div>
                    <div className="space-y-2 p-4 border bg-gray-50">{ (settings.socialLinks || []).map((link, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 border bg-white">
                            <select value={link.platform} onChange={e => handleSocialChange(i, 'platform', e.target.value)} className="px-3 py-2 border border-gray-300 bg-white">
                                <option value="x">X / Twitter</option>
                                <option value="facebook">Facebook</option>
                                <option value="instagram">Instagram</option>
                                <option value="linkedin">LinkedIn</option>
                                <option value="youtube">YouTube</option>
                                <option value="tiktok">TikTok</option>
                            </select>
                            <Input value={link.url} onChange={e => handleSocialChange(i, 'url', e.target.value)} placeholder="https://..." />
                            <button onClick={() => handleRemoveSocial(i)} className="p-2 text-red-500 hover:bg-red-50"><TrashIcon className="h-5 w-5"/></button>
                        </div>
                    ))}</div>
                </div>

                {/* Link Columns */}
                 <div>
                    <div className="flex items-center justify-between mb-2"><h4 className="text-lg font-semibold">Link Columns</h4><Button type="button" onClick={handleAddColumn}>Add Column</Button></div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {(settings.linkColumns || []).map((col, colIndex) => (
                            <div key={col._id || colIndex} className="p-4 border bg-gray-50 space-y-2">
                                <div className="flex items-center gap-2"><Input value={col.title} onChange={e => handleColumnTitleChange(colIndex, e.target.value)} className="font-bold" /><button onClick={() => handleRemoveColumn(colIndex)} className="p-2 text-red-500 hover:bg-red-50"><XIcon className="h-5 w-5"/></button></div>
                                <div className="space-y-1">{col.links.map((link, linkIndex) => (
                                    <div key={link._id || linkIndex} className="flex items-center gap-1 p-1 bg-white border">
                                        <Input value={link.label} onChange={e => handleLinkChange(colIndex, linkIndex, 'label', e.target.value)} placeholder="Label"/>
                                        <Input value={link.url} onChange={e => handleLinkChange(colIndex, linkIndex, 'url', e.target.value)} placeholder="URL"/>
                                        <button onClick={() => handleRemoveLink(colIndex, linkIndex)} className="p-1 text-red-500 hover:bg-red-50"><TrashIcon className="h-4 w-4"/></button>
                                    </div>
                                ))}</div>
                                <button type="button" onClick={() => handleAddLink(colIndex)} className="text-sm bg-gray-200 hover:bg-gray-300 w-full py-1">Add Link</button>
                            </div>
                        ))}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default ManageFooter;