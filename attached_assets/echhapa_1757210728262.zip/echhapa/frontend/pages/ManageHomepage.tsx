

import React, { useState, useEffect, useCallback } from 'react';
import { HomepageSection, Category, Article, AdPosition, Advertisement } from '../types';
import { useAppContext } from '../App';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useFeedback } from '../components/feedback/FeedbackProvider';
import { XIcon, NewspaperIcon, StarIcon, MegaphoneIcon, ArrowUpIcon, ArrowDownIcon } from '../components/icons';

type LayoutItem = (Category | HomepageSection | Advertisement) & { type: 'category' | 'special_section' | 'advertisement' };

// --- Reusable Components ---
const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...props} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 disabled:bg-gray-200" />
);

const Button = ({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: React.ReactNode }) => (
    <button {...props} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors">
        {children}
    </button>
);

const ToggleSwitch: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; disabled?: boolean }> = ({ checked, onChange, disabled }) => (
    <label className={`relative inline-flex items-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" disabled={disabled} />
        <div className={`w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all ${disabled ? 'opacity-50' : ''} peer-checked:bg-blue-600`}></div>
    </label>
);

// --- Modal for Managing Articles in a Special Section ---
interface ManageSectionArticlesModalProps {
    section: HomepageSection;
    onClose: () => void;
    onSave: () => Promise<void>;
}

const ManageSectionArticlesModal: React.FC<ManageSectionArticlesModalProps> = ({ section, onClose, onSave }) => {
    const { showNotification } = useFeedback();
    const [allArticles, setAllArticles] = useState<Article[]>([]);
    const [sectionArticles, setSectionArticles] = useState<Article[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        const fetchArticles = async () => {
            setIsLoading(true);
            try {
                const { data } = await api.get('/api/management-panel/admin-articles');
                setAllArticles(data.filter((a: Article) => a.status === 'published'));
                const populatedSectionArticles = section.articles
                    .map(item => item.article)
                    .filter(Boolean);
                setSectionArticles(populatedSectionArticles as Article[]);
            } catch (error) {
                showNotification('Failed to load articles.', 'error');
            } finally {
                setIsLoading(false);
            }
        };
        fetchArticles();
    }, [section, showNotification]);

    const availableArticles = React.useMemo(() => {
        const sectionArticleIds = new Set(sectionArticles.map(a => a._id));
        return allArticles
            .filter(a => !sectionArticleIds.has(a._id))
            .filter(a => a.title.toLowerCase().includes(searchQuery.toLowerCase()));
    }, [allArticles, sectionArticles, searchQuery]);

    const addArticle = (article: Article) => setSectionArticles(prev => [...prev, article]);
    const removeArticle = (articleId: string) => setSectionArticles(prev => prev.filter(a => a._id !== articleId));
    
    const moveArticle = (index: number, direction: 'up' | 'down') => {
        const newArticles = [...sectionArticles];
        const targetIndex = direction === 'up' ? index - 1 : index + 1;
        if (targetIndex < 0 || targetIndex >= newArticles.length) return;
        [newArticles[index], newArticles[targetIndex]] = [newArticles[targetIndex], newArticles[index]];
        setSectionArticles(newArticles);
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const payload = sectionArticles.map((article, index) => ({ article: article._id, order: index }));
            await api.put(`/api/management-panel/homepage-sections/${section._id}/articles`, { articles: payload });
            showNotification('Section articles updated successfully!', 'success');
            await onSave();
            onClose();
        } catch (error) {
            showNotification('Failed to save changes.', 'error');
        } finally {
            setIsSaving(false);
        }
    };

    return (
         <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white p-6 shadow-xl w-full max-w-4xl border relative flex flex-col max-h-[90vh]">
                <div className="flex justify-between items-center mb-4 border-b pb-4">
                    <h4 className="text-xl font-bold">Manage Articles for "{section.title}"</h4>
                    <button onClick={onClose} className="p-1 hover:bg-gray-200"><XIcon className="h-6 w-6" /></button>
                </div>
                {isLoading ? <Spinner /> : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-y-auto">
                        <div className="border p-4 flex flex-col"><h5 className="font-bold mb-2">Available Articles</h5><input type="text" placeholder="Search articles..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="mb-2 w-full px-3 py-2 border"/>
                            <ul className="overflow-y-auto flex-grow h-64">{availableArticles.map(article => (<li key={article._id} className="flex justify-between items-center p-2 border-b text-sm"><span className="truncate pr-2">{article.title}</span><button onClick={() => addArticle(article)} className="text-xs bg-green-500 text-white px-2 py-1 hover:bg-green-600 flex-shrink-0">Add</button></li>))}</ul>
                        </div>
                        <div className="border p-4 flex flex-col"><h5 className="font-bold mb-2">Articles in Section (Ordered)</h5>
                             <ul className="overflow-y-auto flex-grow h-64">{sectionArticles.map((article, index) => (<li key={article._id} className="flex justify-between items-center p-2 border-b text-sm"><span className="truncate pr-2">{article.title}</span><div className="flex items-center gap-1 flex-shrink-0"><button onClick={() => moveArticle(index, 'up')} disabled={index === 0} className="p-1 disabled:opacity-30">&#x25B2;</button><button onClick={() => moveArticle(index, 'down')} disabled={index === sectionArticles.length - 1} className="p-1 disabled:opacity-30">&#x25BC;</button><button onClick={() => removeArticle(article._id)} className="text-xs bg-red-500 text-white px-2 py-1 hover:bg-red-600">Remove</button></div></li>))}</ul>
                        </div>
                    </div>
                )}
                <div className="flex justify-end gap-2 mt-6 pt-4 border-t"><button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200">Cancel</button><Button onClick={handleSave} disabled={isSaving}>{isSaving ? <Spinner size="sm" /> : 'Save Changes'}</Button></div>
            </div>
        </div>
    );
};


// --- Main Homepage Management Component ---
const ManageHomepage: React.FC = () => {
    const { showNotification } = useFeedback();
    const { categories, setHomepageLayout } = useAppContext();
    const [layout, setLayout] = useState<LayoutItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [managingSection, setManagingSection] = useState<HomepageSection | null>(null);

    const fetchLayout = useCallback(async () => {
        setIsLoading(true);
        try {
            const { data } = await api.get('/api/management-panel/homepage-layout');
            setLayout(data);
        } catch (error) {
            showNotification('Failed to load homepage layout.', 'error');
        } finally {
            setIsLoading(false);
        }
    }, [showNotification]);

    useEffect(() => {
        fetchLayout();
    }, [fetchLayout]);

    const handleLayoutChange = (id: string, field: string, value: any) => {
        setLayout(prev => prev.map(item => {
            if (item._id === id) {
                const updatedItem = { ...item, [field]: value };
                // If toggling to dynamic, ensure sourceCategory and itemCount are set if not already
                if (item.type === 'special_section' && field === 'isDynamic' && value === true) {
                    const sectionItem = updatedItem as HomepageSection;
                    if (!sectionItem.sourceCategory) {
                        (updatedItem as HomepageSection).sourceCategory = categories[0]?._id || '';
                    }
                    if (!sectionItem.itemCount) {
                        (updatedItem as HomepageSection).itemCount = 5;
                    }
                }
                return updatedItem;
            }
            return item;
        }));
    };


    const handleMove = (index: number, direction: 'up' | 'down') => {
        const newLayout = [...layout];
        const swapIndex = direction === 'up' ? index - 1 : index + 1;
        if (swapIndex < 0 || swapIndex >= newLayout.length) return;
        [newLayout[index], newLayout[swapIndex]] = [newLayout[swapIndex], newLayout[index]];
        setLayout(newLayout);
    };

    const handleSaveLayout = async () => {
        setIsSaving(true);
        try {
            await api.put('/api/management-panel/homepage-layout', { layout });

            // Refetch public layout data and update context to reflect changes immediately
            const { data } = await api.get('/api/homepage');
            setHomepageLayout(data);

            showNotification('Homepage layout saved successfully!', 'success');
        } catch (error) {
            showNotification('Error saving homepage layout.', 'error');
        } finally {
            setIsSaving(false);
        }
    };
    
    const typeConfig = {
      category: { icon: NewspaperIcon, color: 'text-blue-500' },
      special_section: { icon: StarIcon, color: 'text-yellow-500' },
      advertisement: { icon: MegaphoneIcon, color: 'text-green-500' },
    };

    if (isLoading) {
        return <div className="flex justify-center p-8"><Spinner text="Loading homepage configuration..." /></div>;
    }

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 shadow-lg border">
                <div className="flex justify-between items-center mb-4 border-b pb-4">
                   <h3 className="text-xl font-bold">Homepage Layout Manager</h3>
                   <Button onClick={handleSaveLayout} disabled={isSaving}>
                    {isSaving ? <Spinner size="sm" /> : 'Save Layout'}
                   </Button>
                </div>
                <p className="text-gray-600 text-sm mb-4">
                    Arrange the sections below to structure your homepage. Use the toggles to control visibility.
                </p>
                <div className="space-y-3">
                    {layout.map((item, index) => {
                        const isEnabled = item.type === 'category' ? (item as Category).showOnHomepage : (item as Advertisement | HomepageSection).isEnabled;
                        const handleToggle = (checked: boolean) => {
                           const field = item.type === 'category' ? 'showOnHomepage' : 'isEnabled';
                           handleLayoutChange(item._id, field, checked);
                        };
                        const Icon = typeConfig[item.type].icon;

                        return (
                        <div key={item._id} className={`border transition-all ${isEnabled ? 'bg-white shadow-sm' : 'bg-gray-50'}`}>
                            <div className="p-4 flex flex-col md:flex-row items-start md:items-center gap-4">
                                {/* Type Icon & Title */}
                                <div className="flex-grow flex items-center gap-4">
                                    <Icon className={`h-8 w-8 flex-shrink-0 ${typeConfig[item.type].color}`} />
                                    <div>
                                        <h4 className="font-bold text-lg">
                                            {(item as any).name || (item as any).title || 'Top Banner Ad'}
                                        </h4>
                                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{item.type.replace(/_/g, ' ')}</span>
                                    </div>
                                </div>

                                {/* Controls */}
                                <div className="flex items-center gap-4 flex-wrap">
                                     {(item.type === 'category' || (item.type === 'special_section')) && (
                                        <Select 
                                            value={item.type === 'category' ? (item as Category).homepageLayout : (item as HomepageSection).layout} 
                                            onChange={(e) => handleLayoutChange(item._id, item.type === 'category' ? 'homepageLayout' : 'layout', e.target.value)}
                                            disabled={!isEnabled}
                                            className="w-full sm:w-48"
                                        >
                                            <option value="hero_1_4">Hero (1 main + 4 sub)</option>
                                            <option value="photo_feature">Photo Feature</option>
                                            <option value="main_and_sub_list">Main Card + Sub-list</option>
                                            <option value="split_70_30">Split View (70/30)</option>
                                            <option value="list_view">List View</option>
                                            <option value="list_with_thumbnails">List with Thumbnails</option>
                                            <option value="grid_3_col">3-Column Grid</option>
                                            <option value="grid_2_col">2-Column Grid</option>
                                            <option value="grid_4_col">4-Column Grid</option>
                                            <option value="video_gallery">Video Gallery (Grid)</option>
                                            <option value="carousel">Carousel</option>
                                            <option value="featured_post">Featured Post</option>
                                        </Select>
                                    )}
                                    {item.type === 'special_section' && (
                                        <button type="button" onClick={() => setManagingSection(item as HomepageSection)} disabled={!isEnabled || (item as HomepageSection).isDynamic} className="text-sm bg-green-100 text-green-800 font-semibold px-3 py-2 hover:bg-green-200 disabled:opacity-50 disabled:cursor-not-allowed">Manage Articles</button>
                                    )}
                                </div>
                                
                                {/* Reorder & Toggle */}
                                <div className="flex items-center gap-4 ml-auto flex-shrink-0">
                                    <div className="flex items-center gap-2">
                                        <span className="text-sm font-medium text-gray-700">Show</span>
                                        <ToggleSwitch checked={isEnabled} onChange={handleToggle} />
                                    </div>
                                    <div className="flex items-center">
                                        <button onClick={() => handleMove(index, 'up')} disabled={index === 0} className="p-2 text-gray-500 hover:text-gray-800 disabled:opacity-30" title="Move Up"><ArrowUpIcon className="h-5 w-5" /></button>
                                        <button onClick={() => handleMove(index, 'down')} disabled={index === layout.length - 1} className="p-2 text-gray-500 hover:text-gray-800 disabled:opacity-30" title="Move Down"><ArrowDownIcon className="h-5 w-5" /></button>
                                    </div>
                                </div>
                            </div>
                             {/* Dynamic Content Controls for Special Sections */}
                            {item.type === 'special_section' && isEnabled && (
                                <div className="border-t bg-gray-50 p-4 space-y-3">
                                    <div className="flex items-center gap-4">
                                        <label className="font-semibold text-sm">Dynamic Content:</label>
                                        <ToggleSwitch checked={(item as HomepageSection).isDynamic} onChange={(checked) => handleLayoutChange(item._id, 'isDynamic', checked)} />
                                        <p className="text-xs text-gray-500">Automatically pulls the latest articles from a category.</p>
                                    </div>
                                    {(item as HomepageSection).isDynamic && (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-8 pt-2 border-l-2 ml-4">
                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-1">Source Category</label>
                                                <Select
                                                    value={ (typeof (item as HomepageSection).sourceCategory === 'object' && (item as HomepageSection).sourceCategory ? ((item as HomepageSection).sourceCategory as Category)._id : (item as HomepageSection).sourceCategory as string) || ''}
                                                    onChange={(e) => handleLayoutChange(item._id, 'sourceCategory', e.target.value)}
                                                >
                                                    {categories.map(cat => <option key={cat._id} value={cat._id}>{cat.name}</option>)}
                                                </Select>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-bold text-gray-700 mb-1">Article Count</label>
                                                <input
                                                    type="number"
                                                    value={(item as HomepageSection).itemCount || 5}
                                                    onChange={(e) => handleLayoutChange(item._id, 'itemCount', parseInt(e.target.value, 10))}
                                                    className="w-full px-3 py-2 border border-gray-300"
                                                    min="1"
                                                    max="10"
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )})}
                </div>
            </div>

            {managingSection && <ManageSectionArticlesModal section={managingSection} onClose={() => setManagingSection(null)} onSave={fetchLayout} />}
        </div>
    );
};

export default ManageHomepage;