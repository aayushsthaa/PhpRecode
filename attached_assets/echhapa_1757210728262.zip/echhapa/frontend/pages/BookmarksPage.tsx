

import React, { useState, useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import { BookmarkIcon, XIcon, SearchIcon } from '../components/icons';

const { Link, useNavigate } = ReactRouterDOM;

const BookmarksPage: React.FC = () => {
    const { articles, user, isLoggedIn, toggleBookmark } = useAppContext();
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');

    const bookmarkedArticles = useMemo(() => {
        if (!user) return [];
        return articles.filter(article => user.bookmarks.includes(article._id));
    }, [articles, user]);

    const filteredBookmarks = useMemo(() => {
        if (!searchQuery.trim()) {
            return bookmarkedArticles;
        }
        const lowercasedQuery = searchQuery.toLowerCase();
        return bookmarkedArticles.filter(article =>
            article.title.toLowerCase().includes(lowercasedQuery) ||
            article.summary.toLowerCase().includes(lowercasedQuery)
        );
    }, [bookmarkedArticles, searchQuery]);

    const handleRemoveBookmark = (e: React.MouseEvent, articleId: string) => {
        e.preventDefault();
        e.stopPropagation();
        toggleBookmark(articleId);
    };

    if (!isLoggedIn) {
        return (
            <div className="text-center py-16 bg-white shadow-sm border">
                <h2 className="text-2xl font-bold text-gray-800">कृपया लगइन गर्नुहोस्</h2>
                <p className="text-gray-600 mt-2">आफ्नो बुकमार्क हेर्नको लागि तपाईंले लगइन गर्न आवश्यक छ।</p>
                <button
                    onClick={() => navigate('/login')}
                    className="mt-6 px-6 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors"
                >
                    लगइन
                </button>
            </div>
        );
    }
    
    return (
        <div>
            <div className="flex justify-between items-center mb-8 border-b pb-4 flex-wrap gap-4">
                <h1 className="text-3xl font-bold text-gray-800">मेरो बुकमार्कहरू</h1>
                <div className="relative w-full sm:w-auto sm:max-w-xs">
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="बुकमार्कमा खोज्नुहोस्..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                        <SearchIcon className="h-5 w-5" />
                    </div>
                </div>
            </div>

            {bookmarkedArticles.length === 0 ? (
                 <div className="text-center py-16 bg-white shadow-sm border">
                    <BookmarkIcon className="h-12 w-12 mx-auto text-gray-300" />
                    <h2 className="mt-4 text-2xl font-bold text-gray-800">अहिलेसम्म कुनै बुकमार्क छैन</h2>
                    <p className="text-gray-600 mt-2">तपाईंले कुनै पनि लेख बुकमार्क गर्नुभएको छैन। अन्वेषण सुरु गर्नुहोस्!</p>
                    <Link to="/" className="mt-6 inline-block px-6 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors">
                        गृहपृष्ठमा फर्कनुहोस्
                    </Link>
                </div>
            ) : filteredBookmarks.length === 0 ? (
                 <div className="text-center py-16 bg-white shadow-sm border">
                    <SearchIcon className="h-12 w-12 mx-auto text-gray-300" />
                    <h2 className="mt-4 text-2xl font-bold text-gray-800">कुनै परिणाम फेला परेन</h2>
                    <p className="text-gray-600 mt-2">"{searchQuery}" को लागि तपाईंको खोजसँग मिल्ने कुनै बुकमार्क छैन।</p>
                </div>
            ) : (
                <div className="space-y-6">
                    {filteredBookmarks.map(article => (
                        <div key={article._id} className="bg-white border flex items-start gap-4 p-4 transition-shadow hover:shadow-md relative group">
                            {article.imageUrl && (
                                <Link to={`/article/${article._id}`} className="block flex-shrink-0 w-32 h-20 sm:w-48 sm:h-32 bg-gray-200 overflow-hidden">
                                    <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover" loading="lazy" />
                                </Link>
                            )}
                            <div className="flex-grow">
                                <Link to={`/article/${article._id}`} className="block">
                                    <p className="text-xs font-semibold text-blue-600 uppercase mb-1 font-sans">{article.categories[0] || 'Uncategorized'}</p>
                                    <h3 className="font-bold text-lg text-gray-900 group-hover:text-blue-700 transition-colors leading-tight font-serif">
                                        {article.title}
                                    </h3>
                                    <p className="text-gray-600 text-sm mt-2 hidden sm:block font-sans">{article.summary}</p>
                                </Link>
                            </div>
                             <button
                                onClick={(e) => handleRemoveBookmark(e, article._id)}
                                className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 transition-colors flex-shrink-0"
                                aria-label="Remove bookmark"
                                title="Remove bookmark"
                            >
                                <XIcon className="h-6 w-6" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default BookmarksPage;