


import React, { useState, useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { ContentBlock, Category } from '../types';
import { XIcon } from '../components/icons';

const { useNavigate } = ReactRouterDOM;

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const buildCategoryTree = (categories: Category[]): Category[] => {
    const categoryMap = new Map<string, Category>();
    const roots: Category[] = [];

    categories.forEach(category => {
        categoryMap.set(category._id, { ...category, children: [] });
    });

    categories.forEach(category => {
        const parentId = typeof category.parent === 'object' && category.parent !== null ? category.parent._id : category.parent as string | undefined;
        const currentCatNode = categoryMap.get(category._id)!;

        if (parentId && categoryMap.has(parentId)) {
            const parentNode = categoryMap.get(parentId)!;
            if (!parentNode.children) parentNode.children = [];
            parentNode.children.push(currentCatNode);
        } else {
            roots.push(currentCatNode);
        }
    });

    return roots;
};

const CategoryChecklist: React.FC<{
    categories: Category[],
    selectedCategories: string[],
    onToggle: (categoryName: string) => void,
    level?: number
}> = ({ categories: cats, selectedCategories, onToggle, level = 0 }) => (
    <>
        {cats.map(cat => (
            <div key={cat._id} className="relative">
                {level > 0 && <div className="absolute left-2.5 top-0 bottom-0 w-px bg-gray-200"></div>}
                <div style={{ paddingLeft: `${level * 24}px` }} className="py-1">
                    <label className="flex items-center space-x-3 group cursor-pointer">
                        {level > 0 && <div className="absolute left-2.5 top-3.5 h-px w-3 bg-gray-200"></div>}
                        <input
                            type="checkbox"
                            checked={selectedCategories.includes(cat.name)}
                            onChange={() => onToggle(cat.name)}
                            className="h-4 w-4 accent-blue-600"
                        />
                        <span className={`text-sm ${level === 0 ? 'font-bold text-gray-800' : 'font-medium text-gray-700'} group-hover:text-blue-600`}>
                            {cat.name}
                        </span>
                    </label>
                </div>
                {cat.children && cat.children.length > 0 && (
                    <CategoryChecklist categories={cat.children} selectedCategories={selectedCategories} onToggle={onToggle} level={level + 1} />
                )}
            </div>
        ))}
    </>
);

const CreateArticlePage: React.FC = () => {
    const { categories, addArticle, user } = useAppContext();
    const navigate = useNavigate();
    
    const categoryTree = useMemo(() => buildCategoryTree(categories), [categories]);

    const getInitialDate = () => {
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    };

    // Form state
    const [title, setTitle] = useState('');
    const [summary, setSummary] = useState('');
    const [mainImage, setMainImage] = useState<string | null>(null);
    const [imageCredit, setImageCredit] = useState('');
    const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
    const [contentBlocks, setContentBlocks] = useState<ContentBlock[]>([{ type: 'paragraph', content: '' }]);
    const [tags, setTags] = useState('');
    const [publishedAt, setPublishedAt] = useState(getInitialDate());
    const [seoTitle, setSeoTitle] = useState('');
    const [metaDescription, setMetaDescription] = useState('');
    
    // UI/Helper state
    const [imageInputMode, setImageInputMode] = useState<'upload' | 'url'>('upload');
    const [imageUrlInput, setImageUrlInput] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleMainImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const base64 = await fileToBase64(e.target.files[0]);
            setMainImage(base64);
        }
    };
    
    const handleCategoryToggle = (categoryName: string) => {
        setSelectedCategories(prev =>
            prev.includes(categoryName)
                ? prev.filter(c => c !== categoryName)
                : [...prev, categoryName]
        );
    };

    const addContentBlock = (type: ContentBlock['type']) => {
        if (type === 'paragraph') {
            setContentBlocks([...contentBlocks, { type: 'paragraph', content: '' }]);
        } else if (type === 'video') {
            const url = prompt("Please enter the video embed URL (e.g., from YouTube's 'Embed' option):");
            if (url) {
                if (url.startsWith('https://www.youtube.com/embed/')) {
                    setContentBlocks([...contentBlocks, { type: 'video', content: url }]);
                } else {
                    alert("Invalid embed URL. Please use a valid embed URL from a service like YouTube or Vimeo.");
                }
            }
        } else { // image
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = async (e) => {
                const target = e.target as HTMLInputElement;
                if (target.files && target.files[0]) {
                    const base64 = await fileToBase64(target.files[0]);
                    setContentBlocks([...contentBlocks, { type: 'image', content: base64 }]);
                }
            };
            input.click();
        }
    };

    const updateContentBlock = (index: number, newContent: string) => {
        const newBlocks = [...contentBlocks];
        newBlocks[index].content = newContent;
        setContentBlocks(newBlocks);
    };

    const removeContentBlock = (index: number) => {
        setContentBlocks(contentBlocks.filter((_, i) => i !== index));
    };

    const moveContentBlock = (index: number, direction: 'up' | 'down') => {
        const newBlocks = [...contentBlocks];
        const targetIndex = direction === 'up' ? index - 1 : index + 1;

        if (targetIndex < 0 || targetIndex >= newBlocks.length) {
            return;
        }

        [newBlocks[index], newBlocks[targetIndex]] = [newBlocks[targetIndex], newBlocks[index]];
        
        setContentBlocks(newBlocks);
    };

    const handleSubmit = async (e: React.FormEvent, status: 'draft' | 'published' = 'published') => {
        e.preventDefault();
        if (!title || !summary || selectedCategories.length === 0 || contentBlocks.length === 0) {
            setError('Title, Summary, at least one Category, and one content block are required.');
            return;
        }

        setIsLoading(true);
        setError(null);

        const finalImageUrl = imageInputMode === 'url' ? imageUrlInput : mainImage;

        try {
            const articleData = {
                title,
                summary,
                imageUrl: finalImageUrl,
                imageCredit,
                categories: selectedCategories,
                content: contentBlocks,
                tags: tags.split(',').map(t => t.trim()).filter(Boolean),
                publishedAt,
                seoTitle,
                metaDescription,
                status: user?.role === 'author' ? 'draft' : status,
            };
            const response = await api.post('/api/articles', articleData);
            addArticle(response.data);
            navigate('/admin/articles');
        } catch (err: any) {
            const errorMessage = err.response?.data?.message || 'Failed to create article. Please try again.';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    const canPublish = user?.role === 'admin' || user?.role === 'editor';

    return (
        <div className="bg-white p-8 shadow-lg border">
            <h1 className="text-3xl font-bold text-gray-800 mb-6 border-b pb-4 font-sans">Create New Article</h1>
            
            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 mb-6" role="alert">
                    {error}
                </div>
            )}

            <form onSubmit={(e) => handleSubmit(e, 'published')} className="space-y-6 font-sans">
                {/* -- Main Info -- */}
                <div>
                    <label htmlFor="title" className="block text-sm font-bold text-gray-700 mb-1">Title</label>
                    <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" required />
                </div>
                <div>
                    <label htmlFor="summary" className="block text-sm font-bold text-gray-700 mb-1">Summary</label>
                    <textarea id="summary" value={summary} onChange={e => setSummary(e.target.value)} rows={3} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" required />
                </div>
                
                 <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Categories</label>
                    <div className="border p-3 bg-white max-h-60 overflow-y-auto">
                        <CategoryChecklist 
                            categories={categoryTree} 
                            selectedCategories={selectedCategories}
                            onToggle={handleCategoryToggle}
                        />
                    </div>
                </div>


                {/* -- Publishing & Tags -- */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 border bg-gray-50">
                     <div>
                        <label htmlFor="tags" className="block text-sm font-bold text-gray-700 mb-1">Tags</label>
                        <input type="text" id="tags" value={tags} onChange={e => setTags(e.target.value)} className="w-full px-3 py-2 border border-gray-300" placeholder="e.g. politics, sports, breaking" />
                        <p className="text-xs text-gray-500 mt-1">Comma-separated values.</p>
                    </div>
                    <div>
                        <label htmlFor="publishedAt" className="block text-sm font-bold text-gray-700 mb-1">Publish Date & Time</label>
                        <input type="datetime-local" id="publishedAt" value={publishedAt} onChange={e => setPublishedAt(e.target.value)} className="w-full px-3 py-2 border border-gray-300" required />
                        <p className="text-xs text-gray-500 mt-1">Set a future date and time to schedule this article for publication.</p>
                    </div>
                </div>

                 {/* -- Main Image -- */}
                 <div className="border p-4 bg-gray-50">
                    <label className="block text-sm font-bold text-gray-700 mb-2">Main Feature Image (optional)</label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                        <div>
                             <div className="flex items-center gap-4 mb-3">
                                <button type="button" onClick={() => setImageInputMode('upload')} className={`px-3 py-1 text-sm ${imageInputMode === 'upload' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>Upload File</button>
                                <button type="button" onClick={() => setImageInputMode('url')} className={`px-3 py-1 text-sm ${imageInputMode === 'url' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>Use URL</button>
                            </div>
                            {imageInputMode === 'upload' ? (
                                <input type="file" id="mainImage" onChange={handleMainImageChange} accept="image/*" className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
                            ) : (
                                <input type="url" value={imageUrlInput} onChange={e => setImageUrlInput(e.target.value)} placeholder="https://..." className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" />
                            )}
                             <div className="mt-4">
                                <label htmlFor="imageCredit" className="block text-sm font-bold text-gray-700 mb-1">Image Credit/Caption</label>
                                <input type="text" id="imageCredit" value={imageCredit} onChange={e => setImageCredit(e.target.value)} className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white" />
                            </div>
                        </div>
                        <div>
                            <p className="text-xs text-gray-500 mb-2">Image preview:</p>
                            <div className="w-full h-48 border bg-white flex items-center justify-center">
                                { (mainImage && imageInputMode === 'upload') || (imageUrlInput && imageInputMode === 'url') ?
                                    <img src={imageInputMode === 'upload' ? mainImage! : imageUrlInput} alt="Main preview" className="max-h-full max-w-full object-contain" />
                                    : <span className="text-gray-400">No image selected</span>
                                }
                            </div>
                        </div>
                    </div>
                </div>
                
                {/* -- Content Builder -- */}
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Content Builder</label>
                    <div className="space-y-4 p-4 border-2 border-dashed">
                        {contentBlocks.map((block, index) => (
                            <div key={index} className="flex items-start gap-2 p-2 bg-gray-50 relative border pt-8">
                                <div className="absolute top-0 right-0 flex items-center bg-white shadow-sm border text-xs">
                                     <button
                                        type="button"
                                        onClick={() => moveContentBlock(index, 'up')}
                                        disabled={index === 0}
                                        className="p-1.5 text-gray-600 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed"
                                        title="Move Up"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => moveContentBlock(index, 'down')}
                                        disabled={index === contentBlocks.length - 1}
                                        className="p-1.5 text-gray-600 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed border-l border-r"
                                        title="Move Down"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
                                    </button>
                                    <button type="button" onClick={() => removeContentBlock(index)} className="p-1.5 text-red-500 hover:bg-red-50" title="Remove block">
                                        <XIcon className="h-4 w-4" />
                                    </button>
                                </div>
                                <span className="text-xs font-mono text-gray-400 pt-2">{index + 1}</span>
                                <div className="flex-grow">
                                {block.type === 'paragraph' ? (
                                    <textarea
                                        value={block.content}
                                        onChange={(e) => updateContentBlock(index, e.target.value)}
                                        rows={8}
                                        className="w-full p-2 border border-gray-300 bg-white font-serif text-lg leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        placeholder="Write a paragraph..."
                                    />
                                ) : block.type === 'image' ? (
                                    <img src={block.content} alt={`Content ${index}`} className="max-h-64 border" />
                                ) : (
                                    <div className="aspect-video w-full">
                                      <iframe src={block.content} title={`Content ${index}`} className="w-full h-full" />
                                    </div>
                                )}
                                </div>
                            </div>
                        ))}
                            <div className="flex gap-2 pt-2">
                            <button type="button" onClick={() => addContentBlock('paragraph')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4">Add Paragraph</button>
                            <button type="button" onClick={() => addContentBlock('image')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4">Add Image</button>
                            <button type="button" onClick={() => addContentBlock('video')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4">Add Video</button>
                        </div>
                    </div>
                </div>

                {/* -- SEO Section -- */}
                <div className="border p-4 bg-gray-50">
                    <h3 className="text-lg font-bold text-gray-700 mb-2">SEO Settings</h3>
                    <div>
                        <label htmlFor="seoTitle" className="block text-sm font-bold text-gray-700 mb-1">SEO Title</label>
                        <input type="text" id="seoTitle" value={seoTitle} onChange={e => setSeoTitle(e.target.value)} className="w-full px-3 py-2 border border-gray-300" />
                        <p className="text-xs text-gray-500 mt-1">If blank, the article title will be used.</p>
                    </div>
                    <div className="mt-4">
                        <label htmlFor="metaDescription" className="block text-sm font-bold text-gray-700 mb-1">Meta Description</label>
                        <textarea id="metaDescription" value={metaDescription} onChange={e => setMetaDescription(e.target.value)} rows={2} className="w-full px-3 py-2 border border-gray-300" />
                        <p className="text-xs text-gray-500 mt-1">If blank, the article summary will be used.</p>
                    </div>
                </div>


                {/* -- Actions -- */}
                <div className="flex justify-end items-center gap-4 pt-4 border-t">
                     <button type="button" onClick={(e) => handleSubmit(e, 'draft')} disabled={isLoading} className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-6 focus:outline-none focus:shadow-outline disabled:bg-gray-400 flex justify-center items-center transition-colors">
                        {isLoading ? <Spinner size="sm" /> : 'Save as Draft'}
                    </button>
                    {canPublish && (
                        <button type="submit" disabled={isLoading} className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 focus:outline-none focus:shadow-outline disabled:bg-green-400 flex justify-center items-center transition-colors">
                            {isLoading ? <Spinner size="sm" /> : 'Publish Article'}
                        </button>
                    )}
                     {!canPublish && (
                        <button type="button" onClick={(e) => handleSubmit(e, 'draft')} disabled={isLoading} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors">
                            {isLoading ? <Spinner size="sm" /> : 'Submit for Review'}
                        </button>
                    )}
                </div>
            </form>
        </div>
    );
};

export default CreateArticlePage;