

import React, { useState, useEffect } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import api from '../services/api';
import Spinner from '../components/Spinner';
import { useAppContext } from '../App';
import { useFeedback } from '../components/feedback/FeedbackProvider';

const { useNavigate, Link } = ReactRouterDOM;

const RegisterPage: React.FC = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');
    const [verificationUrl, setVerificationUrl] = useState<string | null>(null);
    const navigate = useNavigate();
    const { isLoggedIn } = useAppContext();
    const { showNotification } = useFeedback();

    useEffect(() => {
        if (isLoggedIn) {
            navigate('/', { replace: true });
        }
    }, [isLoggedIn, navigate]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const response = await api.post('/api/auth/register', { username, email, password });
            setSuccessMessage(response.data.message);
            if (response.data.verificationUrl) {
                setVerificationUrl(response.data.verificationUrl);
            }
            setIsSuccess(true);
        } catch (err: any) {
            const errorMessage = err.response?.data?.message || 'Registration failed. Please try again.';
            showNotification(errorMessage, 'error');
        } finally {
            setIsLoading(false);
        }
    };
    
    if (isLoggedIn) {
        return null; // Render nothing while redirecting
    }

    return (
        <div className="max-w-md mx-auto mt-10">
            <div className="bg-white p-8 shadow-lg border">
                {isSuccess ? (
                    <div className="text-center">
                        <h2 className="text-2xl font-bold text-green-700 mb-4">Request Received!</h2>
                        <p className="text-gray-700 mb-4">
                            {successMessage}
                        </p>
                        {verificationUrl && (
                            <div className="bg-yellow-50 border border-yellow-200 p-4">
                                <p className="text-sm text-yellow-800 mb-3">In a real application, an email would be sent. For development purposes, please use the link below to verify your account:</p>
                                <a
                                    href={verificationUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-block bg-blue-600 text-white font-bold py-2 px-4 hover:bg-blue-700 break-all"
                                >
                                    Click Here to Verify Email
                                </a>
                            </div>
                        )}
                         <p className="mt-4 text-sm text-gray-500">
                            Once verified, you can proceed to the login page.
                        </p>
                    </div>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Create an Account</h2>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
                                    Username
                                </label>
                                <input
                                    type="text"
                                    id="username"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                                    Email
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                                    Password
                                </label>
                                <input
                                    type="password"
                                    id="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                                    required
                                />
                            </div>
                            <div>
                                <button
                                    type="submit"
                                    disabled={isLoading || isSuccess}
                                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 focus:outline-none focus:shadow-outline disabled:bg-blue-400 flex justify-center items-center transition-colors"
                                >
                                    {isLoading ? <Spinner size="sm" /> : 'Register'}
                                </button>
                            </div>
                            <p className="text-center text-gray-600 text-sm mt-6">
                                Already have an account?{' '}
                                <Link to="/login" className="font-bold text-blue-600 hover:text-blue-800">
                                    Login
                                </Link>
                            </p>
                        </form>
                    </>
                )}
            </div>
        </div>
    );
};

export default RegisterPage;