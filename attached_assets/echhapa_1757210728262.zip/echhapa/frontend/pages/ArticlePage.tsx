

import React, { useState, useEffect, useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import Spinner from '../components/Spinner';
import AdBanner from '../components/AdBanner';
import { Article, AdPosition, Advertisement } from '../types';
import api from '../services/api';
import { BookmarkIcon, FacebookIcon, XSocialIcon, WhatsAppIcon, CopyLinkIcon } from '../components/icons';
import { useFeedback } from '../components/feedback/FeedbackProvider';

const { useParams, Link } = ReactRouterDOM;

const ShareButtons: React.FC<{ url: string; title: string; className?: string }> = ({ url, title, className = '' }) => {
  const { showNotification } = useFeedback();

  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const shareOptions = [
    {
      name: 'Facebook',
      icon: FacebookIcon,
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      color: 'hover:text-blue-800'
    },
    {
      name: 'X',
      icon: XSocialIcon,
      url: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
      color: 'hover:text-black'
    },
    {
      name: 'WhatsApp',
      icon: WhatsAppIcon,
      url: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}`,
      color: 'hover:text-green-600'
    },
  ];

  const handleCopyLink = () => {
    navigator.clipboard.writeText(url).then(() => {
      showNotification('Link copied to clipboard!', 'success');
    }, (err) => {
      showNotification('Failed to copy link.', 'error');
      console.error('Could not copy text: ', err);
    });
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <span className="text-sm font-bold text-gray-700 mr-2">Share this article:</span>
      {shareOptions.map(option => {
        const Icon = option.icon;
        return (
          <a
            key={option.name}
            href={option.url}
            target="_blank"
            rel="noopener noreferrer"
            title={`Share on ${option.name}`}
            className={`text-gray-600 transition-colors ${option.color}`}
            onClick={(e) => {
              e.preventDefault();
              window.open(option.url, 'share-window', 'height=450,width=550,toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
            }}
          >
            <Icon className="h-6 w-6" />
          </a>
        );
      })}
      <button
        onClick={handleCopyLink}
        title="Copy link"
        className="text-gray-600 transition-colors hover:text-blue-600"
      >
        <CopyLinkIcon className="h-6 w-6" />
      </button>
    </div>
  );
};


const ArticleSidebar: React.FC<{ currentArticle: Article; sidebarAd?: Advertisement }> = ({ currentArticle, sidebarAd }) => {
    const { articles } = useAppContext();

    const relatedArticles = articles
        .filter(a => a._id !== currentArticle._id && a.categories.some(cat => currentArticle.categories.includes(cat)))
        .slice(0, 5);
        
    return (
        <aside className="space-y-8 sticky top-24 h-fit">
             {sidebarAd && <AdBanner ad={sidebarAd} />}
             {relatedArticles.length > 0 && (
                <div>
                    <h3 className="text-xl font-bold font-sans mb-4 border-b pb-2">{currentArticle.categories[0]} मा थप</h3>
                    <div className="space-y-4">
                        {relatedArticles.map(article => (
                            <Link key={article._id} to={`/article/${article._id}`} className="block group">
                                <h4 className="font-semibold leading-tight group-hover:text-blue-700 font-serif">{article.title}</h4>
                                <p className="text-xs text-gray-500 mt-1">{new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
                            </Link>
                        ))}
                    </div>
                </div>
             )}
        </aside>
    );
};


const BottomRelatedStories: React.FC<{ currentArticle: Article }> = ({ currentArticle }) => {
    const { articles } = useAppContext();
    const relatedArticles = articles
        .filter(a => a._id !== currentArticle._id && a.categories.some(cat => currentArticle.categories.includes(cat)))
        .slice(0, 3);

    if (relatedArticles.length === 0) return null;

    return (
        <section className="mt-16 pt-8 border-t">
            <h3 className="text-2xl font-bold font-sans mb-6">सम्बन्धित कथाहरू</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {relatedArticles.map(article => (
                     <Link key={article._id} to={`/article/${article._id}`} className="block group">
                        {article.imageUrl && (
                             <div className="w-full h-48 overflow-hidden border mb-4">
                                <img
                                    src={article.imageUrl}
                                    alt={article.title}
                                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                    loading="lazy"
                                />
                            </div>
                        )}
                        <h4 className="font-bold text-lg leading-tight group-hover:text-blue-700 transition-colors font-serif">
                           {article.title}
                        </h4>
                         <p className="text-sm text-gray-500 mt-2">{new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
                    </Link>
                ))}
            </div>
        </section>
    );
};


const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { advertisements, user, isLoggedIn, toggleBookmark } = useAppContext();
  const { showNotification } = useFeedback();
  const [article, setArticle] = useState<Article | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const isBookmarked = useMemo(() => user?.bookmarks.includes(article?._id || ''), [user, article]);

  const handleBookmarkClick = () => {
    if (!isLoggedIn) {
        showNotification("Please log in to bookmark articles.", "info");
        return;
    }
    if (article) {
        toggleBookmark(article._id);
    }
  };

  const getArticleAd = (position: AdPosition): Advertisement | undefined => {
    // Prioritize article-specific ad
    const specificAd = advertisements.find(ad => 
        ad.position === position && 
        ad.articleId && 
        typeof ad.articleId === 'object' && 
        ad.articleId._id === id
    );
    if (specificAd) return specificAd;

    // Fallback to a generic ad for this position (one with no articleId)
    const genericAd = advertisements.find(ad => 
        ad.position === position && 
        !ad.articleId
    );
    return genericAd;
  };

  const articleTopAd = getArticleAd(AdPosition.ARTICLE_TOP);
  const articleBottomAd = getArticleAd(AdPosition.ARTICLE_BOTTOM);
  const articleSidebarAd = getArticleAd(AdPosition.ARTICLE_SIDEBAR);
  
  const relevantInlineAds = useMemo(() => {
    if (!article) return [];
    
    return advertisements.filter(ad => {
        if (ad.position !== AdPosition.INLINE_ARTICLE) return false;

        const targeting = ad.categoryTargeting;
        if (!targeting || targeting.length === 0) {
            return true; // Ad is not targeted, so it's relevant.
        }

        // Ad is targeted, check for a match.
        // `targeting` is populated to [{_id, name}, ...]
        const targetedCategoryNames = (targeting as {name: string}[]).map(c => c.name);
        return article.categories.some(articleCatName => targetedCategoryNames.includes(articleCatName));
    });
  }, [advertisements, article]);


  useEffect(() => {
    // SEO Head Management
    if (article) {
        document.title = article.seoTitle || article.title;
        const metaDescription = document.querySelector('meta[name="description"]');
        if (metaDescription) {
            metaDescription.setAttribute('content', article.metaDescription || article.summary);
        } else {
            const newMeta = document.createElement('meta');
            newMeta.name = 'description';
            newMeta.content = article.metaDescription || article.summary;
            document.head.appendChild(newMeta);
        }
    }
  }, [article]);


  useEffect(() => {
    const fetchArticle = async () => {
      if (!id) return;
      setIsLoading(true);
      setError(null);
      try {
        const response = await api.get(`/api/articles/${id}`);
        const data = response.data;
        // Robustness check: Ensure data is a valid object and sanitize array properties.
        if (data && typeof data === 'object' && !Array.isArray(data)) {
            const sanitizedArticle = {
                ...data,
                categories: Array.isArray(data.categories) ? data.categories : [],
                tags: Array.isArray(data.tags) ? data.tags : [],
                content: Array.isArray(data.content) ? data.content : [],
            };
            setArticle(sanitizedArticle as Article);
        } else {
            throw new Error("Invalid article data received from server.");
        }
      } catch (err) {
        setError("लेख लोड गर्न असफल भयो। यो अवस्थित नहुन सक्छ वा सर्भर त्रुटि थियो।");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchArticle();
    window.scrollTo(0, 0);
  }, [id]);
  
  if (isLoading) {
    return (
        <div className="flex justify-center items-center min-h-[50vh]">
            <Spinner text="लेख लोड हुँदैछ..." />
        </div>
    );
  }

  if (error || !article) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center">
        <h2 className="text-2xl font-bold text-gray-700">{error || 'लेख फेला परेन'}</h2>
        <Link to="/" className="mt-4 text-blue-600 hover:underline">
          गृहपृष्ठमा फर्कनुहोस्
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {articleTopAd && (
            <div className="mb-8">
                <AdBanner ad={articleTopAd} />
            </div>
        )}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-x-12 items-start">
            <main className="lg:col-span-2">
                <header className="mb-8 border-b pb-6">
                    <div className="flex flex-wrap gap-x-4 gap-y-2">
                        {article.categories.map(cat => (
                             <Link key={cat} to={`/category/${cat}`} className="font-sans text-sm font-bold uppercase text-blue-600 hover:text-blue-800 transition-colors">
                                {cat}
                            </Link>
                        ))}
                    </div>
                    <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 mt-4 leading-tight font-serif">
                        {article.title}
                    </h1>
                    <p className="text-xl text-gray-600 mt-4 font-serif">{article.summary}</p>
                    <div className="font-sans text-sm text-gray-500 mt-6 flex items-center gap-4 flex-wrap">
                        <span>द्वारा <strong className="text-gray-800">{article.author.username}</strong></span>
                        <span className="hidden sm:inline">&bull;</span>
                        <span>
                            प्रकाशित: {new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </span>
                        {isLoggedIn && (
                          <div className="flex items-center gap-2">
                            <span className="hidden sm:inline">&bull;</span>
                            <button onClick={handleBookmarkClick} className="flex items-center gap-1.5 text-gray-600 hover:text-blue-600 transition-colors" title="Bookmark this article">
                                <BookmarkIcon className={`h-5 w-5 ${isBookmarked ? 'text-blue-600' : ''}`} isFilled={isBookmarked} />
                                <span className="font-semibold">{isBookmarked ? ' सुरक्षित' : ' सुरक्षित गर्नुहोस्'}</span>
                            </button>
                          </div>
                        )}
                    </div>
                </header>

                <div className="mb-8">
                    <ShareButtons url={window.location.href} title={article.title} />
                </div>
                
                {article.imageUrl && (
                    <figure className="mb-8">
                        <img
                            src={article.imageUrl}
                            alt={article.title}
                            className="w-full h-auto object-cover shadow-lg border"
                            loading="lazy"
                        />
                        {article.imageCredit && (
                            <figcaption className="text-xs text-gray-500 mt-2 text-right">
                                {article.imageCredit}
                            </figcaption>
                        )}
                    </figure>
                )}

                <article className="prose prose-lg max-w-none text-gray-800 leading-relaxed text-lg font-serif">
                   {(() => {
                      let adInsertionIndex = 0;
                      const PARAGRAPH_INSERT_INTERVAL = 3; // Insert an ad every 3 paragraphs
                      let paragraphCounter = 0;

                      return article.content.flatMap((block, index) => {
                          const blockKey = block._id || index;
                          let renderedBlock;
                          
                          if (block.type === 'paragraph') {
                              paragraphCounter++;
                              renderedBlock = <div key={blockKey} dangerouslySetInnerHTML={{ __html: block.content }} />;
                          } else if (block.type === 'image') {
                              renderedBlock = (
                                  <figure key={blockKey} className="my-8">
                                      <img src={block.content} alt={`Content image ${index + 1}`} className="w-full h-auto object-cover" loading="lazy" />
                                  </figure>
                              );
                          } else if (block.type === 'video') {
                              renderedBlock = (
                                  <div key={blockKey} className="my-8 aspect-video">
                                      <iframe 
                                          src={block.content} 
                                          title={`Embedded video ${index + 1}`} 
                                          frameBorder="0" 
                                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                          allowFullScreen
                                          className="w-full h-full"
                                      ></iframe>
                                  </div>
                              );
                          } else {
                              return [];
                          }
                          
                          // Check if it's time to insert an ad
                          if (
                            relevantInlineAds.length > 0 &&
                            block.type === 'paragraph' &&
                            paragraphCounter > 0 &&
                            paragraphCounter % PARAGRAPH_INSERT_INTERVAL === 0 &&
                            adInsertionIndex < relevantInlineAds.length
                          ) {
                              const adToRender = relevantInlineAds[adInsertionIndex];
                              adInsertionIndex++;
                              const adElement = (
                                  <div key={`inline-ad-${adToRender._id}`} className="my-8 not-prose">
                                      <AdBanner ad={adToRender} />
                                  </div>
                              );
                              return [renderedBlock, adElement];
                          }
                          
                          return [renderedBlock];
                      });
                  })()}
                </article>

                {article.tags && article.tags.length > 0 && (
                    <div className="mt-8 pt-6 border-t">
                        <h4 className="font-bold mb-2">Tags:</h4>
                        <div className="flex flex-wrap gap-2">
                            {article.tags.map(tag => (
                                <Link key={tag._id} to={`/tag/${tag.name}`} className="text-sm bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 transition-colors">
                                    # {tag.name}
                                </Link>
                            ))}
                        </div>
                    </div>
                )}
            </main>
            
            <div className="hidden lg:block">
                 <ArticleSidebar currentArticle={article} sidebarAd={articleSidebarAd} />
            </div>
        </div>

        <BottomRelatedStories currentArticle={article} />

        {articleBottomAd && (
          <div className="mt-12 border-t pt-8">
            <AdBanner ad={articleBottomAd} />
          </div>
        )}
    </div>
  );
};

export default ArticlePage;
