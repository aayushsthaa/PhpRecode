import React, { useState, useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import { Article, AdPosition, HomepageSection, Category, Advertisement } from '../types';
import NewsCard from '../components/NewsCard';
import Carousel from '../components/Carousel';
import AdBanner from '../components/AdBanner';
import VideoCard from '../components/VideoCard';

const { useParams, Link } = ReactRouterDOM;

// --- Reusable Cards ---
const HorizontalListItemCard: React.FC<{ article: Article }> = ({ article }) => (
    <Link to={`/article/${article._id}`} className="block group py-6 border-b last:border-b-0">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-2">
              <h3 className="text-2xl font-bold leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h3>
              <p className="text-md text-gray-600 mt-2">{article.summary}</p>
              <p className="text-sm text-gray-500 mt-2 font-sans">{article.author.username} &bull; {new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
          </div>
          {article.imageUrl && (
            <div className="md:col-span-1 h-48 overflow-hidden">
              <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
            </div>
          )}
        </div>
    </Link>
);

const ThumbnailListItem: React.FC<{ article: Article }> = ({ article }) => (
  <Link to={`/article/${article._id}`} className="flex items-center gap-4 group py-3 border-b last:border-b-0">
    {article.imageUrl && (
      <div className="flex-shrink-0 w-24 h-16 bg-gray-200 overflow-hidden">
        <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
      </div>
    )}
    <div className="flex-grow">
      <h4 className="font-bold text-md leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h4>
    </div>
  </Link>
);

// --- Section Components ---

const SectionWrapper: React.FC<{ title: string; children: React.ReactNode; categoryId?: string; }> = ({ title, children, categoryId }) => {
    const { advertisements } = useAppContext();

    const sectionAd = advertisements.find(ad =>
        ad.position === AdPosition.HOME_SECTION_AD &&
        categoryId &&
        ad.categoryId &&
        (typeof ad.categoryId === 'object' ? ad.categoryId._id === categoryId : ad.categoryId === categoryId)
    );
    
    return (
      <section className="my-12">
        {sectionAd && (
            <div className="mb-6">
                <AdBanner ad={sectionAd} />
            </div>
        )}
        <h2 className="text-2xl font-bold font-serif border-b-4 border-blue-600 pb-2 mb-6">{title}</h2>
        {children}
      </section>
    );
};

const CarouselSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
  if (articles.length === 0) return null;

  return (
    <SectionWrapper title={title} categoryId={categoryId}>
      <Carousel articles={articles.slice(0, 5)} />
    </SectionWrapper>
  );
};

const GridSection: React.FC<{ title: string; columns: 2 | 3 | 4; articles: Article[]; categoryId?: string; }> = ({ title, columns, articles, categoryId }) => {
  if (articles.length === 0) return null;
  
  const gridClasses = {
      2: 'grid-cols-1 md:grid-cols-2',
      3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
      4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
  }

  return (
    <SectionWrapper title={title} categoryId={categoryId}>
      <div className={`grid ${gridClasses[columns]} gap-8 items-stretch`}>
        {articles.slice(0, columns).map(article => <NewsCard key={article._id} article={article} />)}
      </div>
    </SectionWrapper>
  );
};

const VideoGallerySection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
  const videoArticles = useMemo(() => 
    articles.filter(article => article.content.some(block => block.type === 'video')), 
    [articles]
  );
  
  if (videoArticles.length === 0) return null;

  return (
    <SectionWrapper title={title} categoryId={categoryId}>
      <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch`}>
        {videoArticles.slice(0, 6).map(article => <VideoCard key={article._id} article={article} />)}
      </div>
    </SectionWrapper>
  );
};


const FeaturedPostSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
   const article = articles[0];
   if (!article) return null;

  return (
    <SectionWrapper title={title} categoryId={categoryId}>
      <Link to={`/article/${article._id}`} className="block group">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-gray-50 p-8 border">
            {article.imageUrl && 
                <div className="w-full h-96 overflow-hidden">
                    <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                </div>
            }
            <div className={!article.imageUrl ? 'md:col-span-2' : ''}>
                <h3 className="text-3xl lg:text-4xl font-bold leading-tight group-hover:text-blue-700 transition-colors font-serif">
                  {article.title}
                </h3>
                <p className="text-lg text-gray-700 mt-4">{article.summary}</p>
                <p className="text-sm text-gray-500 mt-4 font-sans">{article.author.username} &bull; {new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
            </div>
        </div>
      </Link>
    </SectionWrapper>
  );
};

const ListSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
    if (articles.length === 0) return null;

    return (
      <SectionWrapper title={title} categoryId={categoryId}>
        <div className="flex flex-col">
            {articles.slice(0, 4).map(article => <HorizontalListItemCard key={article._id} article={article}/>)}
        </div>
      </SectionWrapper>
    );
};

const ListWithThumbnailsSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
  if (articles.length === 0) return null;

  return (
    <SectionWrapper title={title} categoryId={categoryId}>
      <div className="flex flex-col">
        {articles.slice(0, 5).map(article => <ThumbnailListItem key={article._id} article={article} />)}
      </div>
    </SectionWrapper>
  );
};


const Split7030Section: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
    if (articles.length === 0) return null;

    const mainArticle = articles[0];
    const subArticles = articles.slice(1, 5);

    return (
        <SectionWrapper title={title} categoryId={categoryId}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Article */}
                <div className="lg:col-span-2">
                    <Link to={`/article/${mainArticle._id}`} className="block group">
                        {mainArticle.imageUrl && 
                          <div className="w-full h-96 mb-4 overflow-hidden border">
                            <img src={mainArticle.imageUrl} alt={mainArticle.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                          </div>
                        }
                        <h3 className="text-3xl font-bold leading-tight group-hover:text-blue-700 font-serif">{mainArticle.title}</h3>
                        <p className="text-md text-gray-600 mt-2">{mainArticle.summary}</p>
                    </Link>
                </div>
                {/* Sub Articles */}
                {subArticles.length > 0 && (
                    <div className="lg:col-span-1 space-y-4 border-l-0 lg:border-l lg:pl-6">
                        {subArticles.map(article => (
                            <Link key={article._id} to={`/article/${article._id}`} className="block group border-b pb-4 last:border-b-0">
                                <h4 className="font-bold text-lg group-hover:text-blue-700 font-serif">{article.title}</h4>
                                <p className="text-sm text-gray-500 mt-1 font-sans">{new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </SectionWrapper>
    );
};

const Hero1_4_Section: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
    if (articles.length < 1) return null;

    const mainArticle = articles[0];
    const sideArticles = articles.slice(1, 5);

    return (
        <SectionWrapper title={title} categoryId={categoryId}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Main Article */}
                <Link to={`/article/${mainArticle._id}`} className="block group">
                    {mainArticle.imageUrl &&
                        <div className="w-full h-[450px] mb-4 overflow-hidden border">
                            <img src={mainArticle.imageUrl} alt={mainArticle.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                        </div>
                    }
                    <h2 className="text-3xl font-extrabold leading-tight group-hover:text-blue-700 transition-colors font-serif">{mainArticle.title}</h2>
                    <p className="text-lg text-gray-700 mt-2">{mainArticle.summary}</p>
                </Link>
                {/* Side Articles */}
                {sideArticles.length > 0 && (
                    <div className="space-y-4">
                        {sideArticles.map(article => (
                            <Link key={article._id} to={`/article/${article._id}`} className="block group border-b pb-4 last:border-b-0">
                                <h3 className="font-bold text-xl group-hover:text-blue-700 transition-colors font-serif">{article.title}</h3>
                                <p className="text-sm text-gray-500 mt-1 font-sans">{new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</p>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </SectionWrapper>
    );
};

const PhotoFeatureSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
    if (articles.length < 5) return null;

    const mainArticle = articles[0];
    const subArticles = articles.slice(1, 5);

    return (
        <SectionWrapper title={title} categoryId={categoryId}>
            <div className="space-y-4">
                <Link to={`/article/${mainArticle._id}`} className="block group relative w-full h-96 bg-gray-900 overflow-hidden">
                    <img src={mainArticle.imageUrl} alt={mainArticle.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-70" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-6 text-white">
                        <h3 className="text-3xl font-bold leading-tight group-hover:underline font-serif">{mainArticle.title}</h3>
                    </div>
                </Link>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {subArticles.map(article => (
                        <Link key={article._id} to={`/article/${article._id}`} className="block group">
                            <div className="w-full h-32 overflow-hidden border">
                                <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                            </div>
                            <h4 className="font-semibold text-sm mt-2 leading-tight group-hover:text-blue-700 font-serif">{article.title}</h4>
                        </Link>
                    ))}
                </div>
            </div>
        </SectionWrapper>
    );
};

const MainAndSubListSection: React.FC<{ title: string; articles: Article[]; categoryId?: string; }> = ({ title, articles, categoryId }) => {
    if (articles.length < 2) return null;

    const mainArticle = articles[0];
    const subArticles = articles.slice(1, 5);

    return (
        <SectionWrapper title={title} categoryId={categoryId}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                    <NewsCard article={mainArticle} />
                </div>
                <div className="lg:col-span-1 space-y-2">
                    {subArticles.map(article => <ThumbnailListItem key={article._id} article={article} />)}
                </div>
            </div>
        </SectionWrapper>
    );
};


// --- Right Column (Sidebar) ---
const RightColumnItem: React.FC<{ article: Article }> = ({ article }) => (
  <Link to={`/article/${article._id}`} className="block group py-4 border-b last:border-b-0">
    <div className="grid grid-cols-3 gap-3 items-start">
      <div className="col-span-2">
        <h4 className="font-bold text-md leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h4>
      </div>
      {article.imageUrl && (
        <div className="col-span-1 h-16 overflow-hidden border">
          <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
        </div>
      )}
    </div>
  </Link>
);

const SimpleListItem: React.FC<{ article: Article }> = ({ article }) => (
  <Link to={`/article/${article._id}`} className="block group py-2 border-b last:border-b-0">
    <h4 className="font-semibold text-sm leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h4>
  </Link>
);

const FeaturedListItem: React.FC<{ article: Article; isFeatured: boolean }> = ({ article, isFeatured }) => {
    if (isFeatured) {
        return (
            <Link to={`/article/${article._id}`} className="block group pb-4 border-b mb-2">
                {article.imageUrl && (
                    <div className="w-full h-32 overflow-hidden border mb-2">
                      <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
                    </div>
                )}
                <h4 className="font-bold text-lg leading-tight group-hover:text-blue-700 transition-colors font-serif">{article.title}</h4>
            </Link>
        );
    }
    return <SimpleListItem article={article} />;
};


const RightColumn: React.FC = () => {
    const { articles, sidebarWidgets } = useAppContext();

    if (!sidebarWidgets || sidebarWidgets.length === 0) {
        return <aside className="lg:col-span-3 space-y-8 sticky top-24 h-fit"></aside>;
    }
    
    return (
        <aside className="lg:col-span-3 space-y-8 sticky top-24 h-fit">
            {sidebarWidgets.map(widget => {
                const key = widget._id;
                
                if (widget.type === 'advertisement') {
                    const ad = widget.advertisementId as Advertisement;
                    if (ad && ad._id) { // Check if ad is populated and valid
                        return <AdBanner key={key} ad={ad} />;
                    }
                     return null;
                }

                let widgetArticles: Article[] = [];
                if (widget.type === 'latest_articles') {
                    widgetArticles = articles.slice(0, widget.itemCount);
                } else if (widget.type === 'category_articles' && widget.categoryId) {
                    const categoryName = (widget.categoryId as { name: string }).name;
                    widgetArticles = articles.filter(a => a.categories.includes(categoryName)).slice(0, widget.itemCount);
                } else if (widget.type === 'featured_articles') {
                    // This is now legacy, special sections are better. But we can keep it.
                    // Let's filter by a keyword or something, for now, just latest.
                    widgetArticles = articles.slice(0, widget.itemCount);
                }


                if (widgetArticles.length === 0) return null;

                return (
                    <div key={key}>
                        <h2 className="text-xl font-bold font-serif border-b-4 border-gray-800 pb-2 mb-4">{widget.title}</h2>
                        <div className="flex flex-col">
                           {(() => {
                                switch (widget.layout) {
                                    case 'simple_list':
                                        return widgetArticles.map(article => <SimpleListItem key={article._id} article={article} />);
                                    case 'featured_list':
                                        return widgetArticles.map((article, index) => <FeaturedListItem key={article._id} article={article} isFeatured={index === 0} />);
                                    case 'list_with_thumbnails':
                                    default:
                                        return widgetArticles.map(article => <RightColumnItem key={article._id} article={article} />);
                                }
                            })()}
                        </div>
                    </div>
                );
            })}
        </aside>
    );
};


const HomePage: React.FC = () => {
  const { articles, categories, homepageLayout } = useAppContext();
  const { categoryName } = useParams<{ categoryName?: string }>();

  // Filter states for category view
  const [dateFilter, setDateFilter] = useState('any');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [activeSubCategoryName, setActiveSubCategoryName] = useState<string | null>(null);

  // CATEGORY VIEW
  const targetCategory = useMemo(() => {
      if (!categoryName) return null;
      return categories.find(c => c.name === categoryName);
  }, [categories, categoryName]);

  const subCategories = useMemo(() => {
      if (!targetCategory) return [];
      return categories.filter(c => {
          const parent = c.parent as { _id: string };
          return parent?._id === targetCategory._id;
      }).sort((a, b) => a.order - b.order);
  }, [categories, targetCategory]);
  
  const filteredArticles = useMemo(() => {
    if (!categoryName || !targetCategory) return [];
    
    const getDescendantIds = (parentId: string, allCategories: Category[]): string[] => {
        const children = allCategories.filter(c => (c.parent as { _id: string })?._id === parentId);
        let descendantIds = children.map(c => c._id);
        children.forEach(child => {
            descendantIds = [...descendantIds, ...getDescendantIds(child._id, allCategories)];
        });
        return descendantIds;
    };
    
    // Determine the pool of articles: either from the selected sub-category or the main category and all its descendants.
    let articlesToFilter: Article[];
    if (activeSubCategoryName) {
        articlesToFilter = articles.filter(article => article.categories.includes(activeSubCategoryName));
    } else {
        const relevantCategoryIds = [targetCategory._id, ...getDescendantIds(targetCategory._id, categories)];
        const relevantCategoryNames = categories
            .filter(c => relevantCategoryIds.includes(c._id))
            .map(c => c.name);
        articlesToFilter = articles.filter(article => 
            article.categories.some(catName => relevantCategoryNames.includes(catName))
        );
    }
    
    // Apply date filtering on the determined pool of articles
    if (dateFilter === 'any') {
      return articlesToFilter;
    }
  
    const now = new Date();
    let startDate = new Date();
  
    if (dateFilter === 'today') {
      startDate.setHours(0, 0, 0, 0);
      return articlesToFilter.filter(article => new Date(article.publishedAt) >= startDate);
    } 
    if (dateFilter === 'week') {
      startDate.setDate(now.getDate() - 7);
      return articlesToFilter.filter(article => new Date(article.publishedAt) >= startDate);
    } 
    if (dateFilter === 'month') {
      startDate.setMonth(now.getMonth() - 1);
      return articlesToFilter.filter(article => new Date(article.publishedAt) >= startDate);
    } 
    if (dateFilter === 'custom' && customStartDate && customEndDate) {
      startDate = new Date(customStartDate);
      startDate.setHours(0, 0, 0, 0);
      const endDate = new Date(customEndDate);
      endDate.setHours(23, 59, 59, 999);
      return articlesToFilter.filter(article => {
        const articleDate = new Date(article.publishedAt);
        return articleDate >= startDate && articleDate <= endDate;
      });
    }
    
    return articlesToFilter;

  }, [articles, categories, categoryName, targetCategory, activeSubCategoryName, dateFilter, customStartDate, customEndDate]);


  if (categoryName) {
    return (
      <div className="max-w-5xl mx-auto py-8">
        <h1 className="text-4xl font-bold font-serif border-b pb-4 mb-4">
          {categoryName}
        </h1>
        {subCategories.length > 0 && (
            <div className="flex flex-wrap items-center gap-x-2 gap-y-2 mb-8 border-b pb-4 no-scrollbar overflow-x-auto">
                <button 
                    onClick={() => setActiveSubCategoryName(null)}
                    className={`px-4 py-2 transition-colors text-sm font-medium whitespace-nowrap ${!activeSubCategoryName ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                    सबै
                </button>
                {subCategories.map(subCat => (
                    <button 
                        key={subCat._id} 
                        onClick={() => setActiveSubCategoryName(subCat.name)}
                        className={`px-4 py-2 transition-colors text-sm font-medium whitespace-nowrap ${activeSubCategoryName === subCat.name ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                        {subCat.name}
                    </button>
                ))}
            </div>
        )}
        {/* Date Filter UI */}
        <div className="bg-gray-50 p-4 mb-8 border flex flex-col sm:flex-row gap-4 items-center">
            <label htmlFor="date-filter" className="font-semibold text-sm">मिति अनुसार फिल्टर गर्नुहोस्:</label>
            <select 
                id="date-filter" 
                value={dateFilter} 
                onChange={e => setDateFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
                <option value="any">सबै समय</option>
                <option value="today">आज</option>
                <option value="week">यो हप्ता</option>
                <option value="month">यो महिना</option>
                <option value="custom">अनुकूल दायरा</option>
            </select>
            {dateFilter === 'custom' && (
                <div className="flex gap-2 items-center">
                    <input type="date" value={customStartDate} onChange={e => setCustomStartDate(e.target.value)} className="px-3 py-1.5 border" />
                    <span>देखि</span>
                    <input type="date" value={customEndDate} onChange={e => setCustomEndDate(e.target.value)} className="px-3 py-1.5 border"/>
                </div>
            )}
        </div>
        
        {filteredArticles.length > 0 ? (
          <div className="flex flex-col">
            {filteredArticles.map(article => <HorizontalListItemCard key={article._id} article={article} />)}
          </div>
        ) : (
          <p className="text-center py-16 text-gray-500">चयन गरिएको फिल्टरको लागि यस श्रेणीमा कुनै लेख फेला परेन।</p>
        )}
      </div>
    );
  }

  // --- DYNAMIC HOMEPAGE LAYOUT ---
    const allSpecialArticleIds = useMemo(() => {
        const specialSections = homepageLayout.filter(item => item.type === 'special_section');
        return new Set(specialSections.flatMap(s => s.articles.map((a: any) => a.article._id)));
    }, [homepageLayout]);

  return (
    <div className="bg-white">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <main className="lg:col-span-9">
            {homepageLayout.map((item) => {
                const key = `${item.type}-${item._id}`;

                if (item.type === 'advertisement') {
                    // Type assertion to Advertisement
                    const ad = item as Advertisement;
                    return (
                        <div key={key} className="my-6">
                            <AdBanner ad={ad} />
                        </div>
                    );
                }

                let section;
                let sectionArticles: Article[] = [];
                let title = '';
                let layout = '';
                let categoryId;

                if (item.type === 'special_section') {
                    section = item as HomepageSection;
                    sectionArticles = section.articles.map((a: any) => a.article).filter(Boolean);
                    title = section.title;
                    layout = section.layout;
                } else if (item.type === 'category') {
                    section = item as Category;
                    sectionArticles = articles.filter(a => a.categories.includes(section.name) && !allSpecialArticleIds.has(a._id));
                    title = section.name;
                    layout = section.homepageLayout;
                    categoryId = section._id;
                }

                if (!section || sectionArticles.length === 0) return null;

                switch (layout) {
                    case 'carousel':
                        return <CarouselSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'grid_2_col':
                        return <GridSection key={key} title={title} columns={2} articles={sectionArticles} categoryId={categoryId} />;
                    case 'grid_3_col':
                        return <GridSection key={key} title={title} columns={3} articles={sectionArticles} categoryId={categoryId} />;
                    case 'grid_4_col':
                        return <GridSection key={key} title={title} columns={4} articles={sectionArticles} categoryId={categoryId} />;
                    case 'video_gallery':
                        return <VideoGallerySection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'featured_post':
                        return <FeaturedPostSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'list_view':
                        return <ListSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'list_with_thumbnails':
                        return <ListWithThumbnailsSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'split_70_30':
                        return <Split7030Section key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'hero_1_4':
                        return <Hero1_4_Section key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'photo_feature':
                        return <PhotoFeatureSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    case 'main_and_sub_list':
                        return <MainAndSubListSection key={key} title={title} articles={sectionArticles} categoryId={categoryId} />;
                    default:
                        return null;
                }
            })}
            {homepageLayout.length === 0 && (
              <div className="text-center py-24">
                <h2 className="text-2xl font-bold text-gray-700 font-serif">इच्छापामा स्वागत छ!</h2>
                <p className="text-gray-500 mt-2">गृहपृष्ठ प्रशासकद्वारा कन्फिगर गर्न तयार छ।</p>
              </div>
            )}
        </main>
        <RightColumn />
      </div>
    </div>
  );
};

export default HomePage;