

import React, { useState, useEffect, useMemo } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import * as Icons from './icons';
import { Category } from '../types';

const { Link, useNavigate, useLocation } = ReactRouterDOM;

type NavItem = Category & { children: NavItem[] };

const Header: React.FC = () => {
  const { isLoggedIn, logout, user, categories } = useAppContext();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  const isPageWithNoNav = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/profile';

  const navItems = useMemo(() => {
    const navCategories = categories
      .filter(cat => cat.showInNav)
      .sort((a, b) => a.order - b.order);

    const itemMap = new Map<string, NavItem>();
    const roots: NavItem[] = [];

    navCategories.forEach(cat => {
      itemMap.set(cat._id, { ...cat, children: [] });
    });

    navCategories.forEach(cat => {
      const parentId = typeof cat.parent === 'object' ? cat.parent?._id : cat.parent;
      if (parentId && itemMap.has(parentId)) {
        itemMap.get(parentId)?.children.push(itemMap.get(cat._id)!);
      } else {
        roots.push(itemMap.get(cat._id)!);
      }
    });

    return roots;
  }, [categories]);

  const formattedDate = new Date().toLocaleDateString('ne-NP-u-nu-deva', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);
  
  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? 'hidden' : 'auto';
  }, [isMenuOpen]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  const AuthButtons: React.FC<{isMobile?: boolean}> = ({ isMobile }) => (
    <div className={`flex items-center gap-2 ${isMobile ? 'flex-col w-full' : ''}`}>
      {isLoggedIn && user ? (
        <div className="relative group">
          <button className="p-2 hover:bg-gray-200 transition-colors flex items-center gap-2" title="Profile">
            <Icons.UserIcon className="h-6 w-6 text-gray-600" />
          </button>
          <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg py-1 z-50 invisible group-hover:visible transition-all duration-200 border">
            <div className="px-4 py-2 text-sm text-gray-700 border-b">Signed in as<br /><strong className="truncate">{user.username}</strong></div>
            {['admin', 'editor', 'author'].includes(user.role || '') && <Link to="/admin" className="block px-4 py-2 text-sm font-bold text-blue-600 hover:bg-gray-100">Admin Panel</Link>}
            <Link to="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Profile</Link>
            <Link to="/bookmarks" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Bookmarks</Link>
            <button onClick={handleLogout} className="w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</button>
          </div>
        </div>
      ) : (
        <>
          <Link to="/login" className={`px-4 py-2 text-sm font-semibold transition-colors ${isMobile ? 'w-full text-center bg-gray-100' : 'hover:bg-gray-100'}`}>
            Login
          </Link>
          <Link to="/register" className={`px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors ${isMobile ? 'w-full text-center' : ''}`}>
            Register
          </Link>
        </>
      )}
    </div>
  );
  
  const renderNavItem = (item: NavItem) => {
    const linkTo = `/category/${item.name}`;
    const hasChildren = item.children && item.children.length > 0;

    if (hasChildren) {
      return (
        <li key={item._id} className="relative group">
          <Link to={linkTo} className="font-semibold text-gray-600 hover:text-blue-600 transition-colors uppercase tracking-wider text-sm flex items-center gap-1 h-12">
            <span>{item.name}</span>
            <Icons.ChevronDownIcon className="h-4 w-4" />
          </Link>
          <ul className="absolute left-0 mt-0 w-48 bg-white shadow-lg py-1 z-50 invisible group-hover:visible transition-all duration-200 border">
            {item.children?.map(child => (
              <li key={child._id}>
                <Link to={`/category/${child.name}`} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">{child.name}</Link>
              </li>
            ))}
          </ul>
        </li>
      );
    }

    return (
       <li key={item._id}>
          <Link 
            to={linkTo}
            className="font-semibold text-gray-600 hover:text-blue-600 transition-colors uppercase tracking-wider text-sm flex items-center h-12"
          >
            {item.name}
          </Link>
        </li>
    );
  };
  
  const renderMobileNavItem = (item: Category, level = 0) => {
      const linkTo = `/category/${item.name}`;
      return (
          <React.Fragment key={item._id}>
              <li>
                  <Link to={linkTo} className="block py-2 text-base font-medium text-gray-500 hover:bg-gray-50" style={{ paddingLeft: `${12 + level * 16}px` }}>
                      {item.name}
                  </Link>
              </li>
              {item.children && item.children.length > 0 && (
                  <>
                      {item.children.map(child => renderMobileNavItem(child, level + 1))}
                  </>
              )}
          </React.Fragment>
      );
  };

  return (
    <>
      <header className="bg-white sticky top-0 z-40 font-sans border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-20">
                {/* Left side: Logo and Date */}
                <div className="flex items-center gap-4">
                     <Link to="/" className="flex items-center" aria-label="Echhapa Homepage">
                        <img src="../src/images/logo.png" alt="Echhapa Logo" className="h-12 w-auto" />
                    </Link>
                    <div className="hidden lg:flex flex-col items-start border-l pl-4">
                        <span className="text-xs text-gray-500 font-semibold uppercase tracking-wider">आज</span>
                        <span className="text-sm text-gray-800">{formattedDate}</span>
                    </div>
                </div>

                {/* Right side: Search, Actions, Menu */}
                <div className="flex items-center gap-4">
                    <form onSubmit={handleSearchSubmit} className="relative hidden md:block">
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="लेख खोज्नुहोस्..."
                            className="w-full px-4 py-2 border focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-white"
                        />
                        <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <Icons.SearchIcon className="h-5 w-5" />
                        </button>
                    </form>
                    
                    <div className="hidden md:flex items-center gap-2">
                        <AuthButtons />
                    </div>
                    
                    {/* Mobile Right Side */}
                    <div className="md:hidden flex items-center gap-2">
                        {isLoggedIn && user && (
                            <div className="relative group">
                                <button className="p-2 hover:bg-gray-200 transition-colors flex items-center" title="Profile">
                                    <Icons.UserIcon className="h-6 w-6 text-gray-600" />
                                </button>
                                <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg py-1 z-50 invisible group-hover:visible transition-all duration-200 border">
                                    <div className="px-4 py-2 text-sm text-gray-700 border-b">Signed in as<br /><strong className="truncate">{user.username}</strong></div>
                                    {['admin', 'editor', 'author'].includes(user.role || '') && <Link to="/admin" className="block px-4 py-2 text-sm font-bold text-blue-600 hover:bg-gray-100">Admin Panel</Link>}
                                    <Link to="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Profile</Link>
                                    <Link to="/bookmarks" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Bookmarks</Link>
                                    <button onClick={handleLogout} className="w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</button>
                                </div>
                            </div>
                        )}
                        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-500 hover:text-gray-600 focus:outline-none p-2">
                            <Icons.MenuIcon className="h-6 w-6" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
         {/* Navigation Bar */}
        {!isPageWithNoNav && (
          <nav className="border-t hidden md:block">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
              <ul className="flex items-center justify-center h-12 space-x-8">
                  <li>
                    <Link to="/" className="font-semibold text-gray-600 hover:text-blue-600 transition-colors uppercase tracking-wider text-sm flex items-center h-12">
                      गृहपृष्ठ
                    </Link>
                  </li>
                 {navItems.map(renderNavItem)}
              </ul>
            </div>
          </nav>
        )}
      </header>
      
      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 z-50 bg-white/80 backdrop-blur-sm transition-opacity duration-300 ${isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMenuOpen(false)}></div>
      <div className={`fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="flex items-center justify-between p-4 border-b">
              <h2 className="font-bold text-lg">मेनु</h2>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 text-gray-500 hover:text-gray-600">
                  <Icons.XIcon className="h-6 w-6" />
              </button>
          </div>
          <div className="p-4 space-y-4">
             <form onSubmit={handleSearchSubmit} className="relative">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="लेख खोज्नुहोस्..."
                    className="w-full px-4 py-2 border focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm bg-white"
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    <Icons.SearchIcon className="h-5 w-5" />
                </button>
            </form>
            
            {!isPageWithNoNav && (
                <div className="border-t pt-4">
                    <h3 className="px-3 text-sm font-semibold text-gray-500 uppercase">मेनु</h3>
                    <ul className="mt-2 space-y-1">
                       <li>
                          <Link to="/" className="block py-2 text-base font-medium text-gray-500 hover:bg-gray-50" style={{ paddingLeft: `12px` }}>
                              गृहपृष्ठ
                          </Link>
                       </li>
                       {navItems.map(item => renderMobileNavItem(item))}
                    </ul>
                </div>
             )}

            <div className="border-t pt-4">
              {isLoggedIn && user ? (
                 <div className="space-y-2">
                    <div className="px-3 py-2 text-sm text-gray-700 border-b">Signed in as<br /><strong className="truncate">{user.username}</strong></div>
                    {['admin', 'editor', 'author'].includes(user.role || '') && <Link to="/admin" className="block py-2 px-3 text-base font-medium text-blue-600 hover:bg-gray-50">Admin Panel</Link>}
                    <Link to="/profile" className="block py-2 px-3 text-base font-medium text-gray-500 hover:bg-gray-50">My Profile</Link>
                    <Link to="/bookmarks" className="block py-2 px-3 text-base font-medium text-gray-500 hover:bg-gray-50">My Bookmarks</Link>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-3 py-2 text-base font-medium transition-colors text-red-600 hover:bg-red-50"
                    >
                      Logout
                    </button>
                </div>
              ) : (
                <AuthButtons isMobile={true} />
              )}
            </div>
          </div>
      </div>
    </>
  );
};

export default Header;