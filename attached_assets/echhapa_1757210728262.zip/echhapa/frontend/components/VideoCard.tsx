

import React from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { Article } from '../types';
import { PlayIcon } from './icons';

const { Link } = ReactRouterDOM;

interface VideoCardProps {
  article: Article;
}

const VideoCard: React.FC<VideoCardProps> = ({ article }) => {
  return (
    <Link to={`/article/${article._id}`} className="block group relative aspect-video overflow-hidden border bg-gray-900">
      {article.imageUrl && (
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
          loading="lazy"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex flex-col justify-between p-4">
        {/* Play Icon in the middle */}
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-black/40 backdrop-blur-sm p-4 rounded-full transition-transform duration-300 group-hover:scale-110">
                <PlayIcon className="h-10 w-10 text-white" />
            </div>
        </div>
        
        {/* Title at the bottom */}
        <div>
          <h3 className="font-bold text-lg text-white group-hover:text-blue-300 transition-colors leading-tight font-serif drop-shadow-md">
            {article.title}
          </h3>
        </div>
      </div>
    </Link>
  );
};

export default VideoCard;