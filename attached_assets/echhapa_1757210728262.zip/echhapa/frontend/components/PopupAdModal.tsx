
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../App';
import { AdPosition } from '../types';
import { XIcon } from './icons';

const POPUP_MAX_VIEWS = 3;
const POPUP_TOTAL_VIEWS_KEY = 'popupAdTotalViews';
const POPUP_SESSION_KEY = 'popupAdShownThisSession';

const PopupAdModal: React.FC = () => {
    const { advertisements } = useAppContext();
    const [isOpen, setIsOpen] = useState(false);

    const popupAd = advertisements.find(ad => ad.position === AdPosition.POPUP_MODAL);

    useEffect(() => {
        if (popupAd) {
            const totalViews = parseInt(localStorage.getItem(POPUP_TOTAL_VIEWS_KEY) || '0', 10);
            const shownThisSession = sessionStorage.getItem(POPUP_SESSION_KEY);

            if (totalViews < POPUP_MAX_VIEWS && !shownThisSession) {
                const timer = setTimeout(() => {
                    setIsOpen(true);
                    sessionStorage.setItem(POPUP_SESSION_KEY, 'true');
                    localStorage.setItem(POPUP_TOTAL_VIEWS_KEY, String(totalViews + 1));
                }, 2000); // Show after 2 seconds
                return () => clearTimeout(timer);
            }
        }
    }, [popupAd]);

    if (!isOpen || !popupAd) {
        return null;
    }

    const handleClose = () => {
        setIsOpen(false);
    };
    
    const AdContent = () => (
        <img src={popupAd.imageUrl} alt="Advertisement" className="w-full h-auto object-contain max-h-[80vh]" />
    );

    return (
        <div className="fixed inset-0 z-[9998] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" role="dialog" aria-modal="true">
            <div className="relative bg-white shadow-xl w-full max-w-md transform transition-all border">
                <button
                    onClick={handleClose}
                    className="absolute -top-3 -right-3 p-1.5 bg-gray-800 text-white hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black z-10"
                    aria-label="Close advertisement"
                >
                    <XIcon className="h-5 w-5" />
                </button>
                {popupAd.redirectUrl ? (
                    <a href={popupAd.redirectUrl} target="_blank" rel="noopener noreferrer sponsored" onClick={handleClose}>
                        <AdContent />
                    </a>
                ) : (
                    <AdContent />
                )}
            </div>
        </div>
    );
};

export default PopupAdModal;