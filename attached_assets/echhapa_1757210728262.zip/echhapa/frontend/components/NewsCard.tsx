import React, { useState, useRef, useEffect } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { Article } from '../types';
import { useAppContext } from '../App';
import { BookmarkIcon, ShareIcon, FacebookIcon, XSocialIcon, WhatsAppIcon, CopyLinkIcon } from './icons';
import { useFeedback } from './feedback/FeedbackProvider';

const { Link } = ReactRouterDOM;

interface NewsCardProps {
  article: Article;
}

const SharePopoverContent: React.FC<{ url: string, title: string, onClose: () => void }> = ({ url, title, onClose }) => {
    const { showNotification } = useFeedback();
    const encodedUrl = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);

    const shareOptions = [
        { name: 'Facebook', icon: FacebookIcon, url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`, color: 'hover:text-blue-800' },
        { name: 'X', icon: XSocialIcon, url: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`, color: 'hover:text-black' },
        { name: 'WhatsApp', icon: WhatsAppIcon, url: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}`, color: 'hover:text-green-600' }
    ];

    const handleCopyLink = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Link copied!', 'success');
            onClose();
        });
    };
    
    return (
        <div className="space-y-2">
            <div className="flex justify-around">
            {shareOptions.map(option => {
                const Icon = option.icon;
                return (
                <a key={option.name} href={option.url} target="_blank" rel="noopener noreferrer" title={`Share on ${option.name}`} className={`p-2 ${option.color} transition-colors`} onClick={(e) => { e.stopPropagation(); window.open(option.url, 'share-window', 'height=450,width=550,toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes'); }}>
                    <Icon className="h-5 w-5" />
                </a>
                );
            })}
            </div>
            <button onClick={handleCopyLink} className="w-full flex items-center gap-2 text-sm text-gray-700 hover:bg-gray-100 p-2 text-left">
                <CopyLinkIcon className="h-4 w-4" />
                <span>Copy Link</span>
            </button>
        </div>
    );
};


const NewsCard: React.FC<NewsCardProps> = ({ article }) => {
  const { user, toggleBookmark, isLoggedIn } = useAppContext();
  const { showNotification } = useFeedback();
  const isBookmarked = user?.bookmarks.includes(article._id);

  const [isShareOpen, setIsShareOpen] = useState(false);
  const shareRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (shareRef.current && !shareRef.current.contains(event.target as Node)) {
        setIsShareOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [shareRef]);

  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isLoggedIn) {
      toggleBookmark(article._id);
    } else {
      showNotification("Please log in to bookmark articles.", "info");
    }
  };
  
  const handleShareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsShareOpen(prev => !prev);
  };

  return (
    <Link to={`/article/${article._id}`} className="block group">
      <div className="bg-white border flex flex-col transition-shadow duration-300 hover:shadow-md h-full">
        {article.imageUrl && (
            <div className="relative h-48 overflow-hidden">
              <img 
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" 
                src={article.imageUrl} 
                alt={article.title} 
                loading="lazy"
              />
              <div className="absolute top-2 right-2 flex flex-col items-end gap-2">
                {isLoggedIn && (
                  <button 
                    onClick={handleBookmarkClick}
                    className="p-2 transition-colors bg-white/70 hover:bg-white border"
                    aria-label="Bookmark article"
                    title="Bookmark"
                  >
                    <BookmarkIcon 
                      className={`h-5 w-5 ${isBookmarked ? 'text-blue-600' : 'text-gray-600'}`} 
                      isFilled={isBookmarked}
                    />
                  </button>
                )}
                <div className="relative" ref={shareRef}>
                   <button
                        onClick={handleShareClick}
                        className="p-2 transition-colors bg-white/70 hover:bg-white border"
                        aria-label="Share article"
                        title="Share"
                    >
                        <ShareIcon className="h-5 w-5 text-gray-600" />
                    </button>
                    {isShareOpen && (
                        <div 
                           className="absolute top-full right-0 mt-2 w-48 bg-white shadow-lg p-3 z-10 border text-sm"
                           onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                        >
                            <p className="font-bold mb-2 text-gray-800">Share this story</p>
                            <SharePopoverContent 
                                url={`${window.location.origin}/article/${article._id}`} 
                                title={article.title} 
                                onClose={() => setIsShareOpen(false)}
                            />
                        </div>
                    )}
                </div>
              </div>
            </div>
        )}
        <div className="p-4 flex flex-col flex-grow">
          <p className="text-xs font-semibold text-blue-600 uppercase mb-1 font-sans">{article.categories[0] || 'Uncategorized'}</p>
          <h3 className="font-bold text-lg text-gray-900 group-hover:text-blue-700 transition-colors leading-tight font-serif">
            {article.title}
          </h3>
          <p className="text-gray-600 text-sm mt-2 font-sans line-clamp-3">{article.summary}</p>
          <div className="flex items-center justify-between text-xs text-gray-500 mt-auto pt-4 font-sans">
            <span className="font-medium">{article.author.username}</span>
            <span>{new Date(article.publishedAt).toLocaleDateString('ne-NP-u-nu-deva')}</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default NewsCard;
