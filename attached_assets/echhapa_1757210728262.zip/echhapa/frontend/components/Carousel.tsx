

import React, { useState, useEffect, useCallback } from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { Article } from '../types';
import { ChevronLeftIcon, ChevronRightIcon } from './icons';

const { Link } = ReactRouterDOM;

interface CarouselProps {
  articles: Article[];
}

const Carousel: React.FC<CarouselProps> = ({ articles }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToNext = useCallback(() => {
    setCurrentIndex(prevIndex => (prevIndex === articles.length - 1 ? 0 : prevIndex + 1));
  }, [articles.length]);

  const goToPrevious = () => {
    setCurrentIndex(prevIndex => (prevIndex === 0 ? articles.length - 1 : prevIndex - 1));
  };

  useEffect(() => {
    if (articles.length > 1) {
      const timer = setInterval(goToNext, 5000);
      return () => clearInterval(timer);
    }
  }, [articles.length, goToNext]);

  if (articles.length === 0) {
    return null;
  }

  const currentArticle = articles[currentIndex];

  return (
    <div className="relative w-full h-96 bg-gray-900 overflow-hidden shadow-lg mb-8 border">
      <Link to={`/article/${currentArticle._id}`} className="block w-full h-full">
        <img
          src={currentArticle.imageUrl}
          alt={currentArticle.title}
          className="w-full h-full object-cover transition-transform duration-500 ease-in-out transform scale-100"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-8 text-white">
          {currentArticle.categories && currentArticle.categories.length > 0 && <span className="text-sm font-semibold bg-blue-600 px-2 py-1">{currentArticle.categories[0]}</span>}
          <h2 className="text-3xl font-bold mt-2 leading-tight font-serif">{currentArticle.title}</h2>
          <p className="mt-2 text-gray-200 hidden md:block font-sans">{currentArticle.summary}</p>
        </div>
      </Link>
      
      {articles.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/50 hover:bg-white text-gray-800 p-2 transition-colors focus:outline-none"
            aria-label="Previous slide"
          >
            <ChevronLeftIcon className="h-6 w-6" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/50 hover:bg-white text-gray-800 p-2 transition-colors focus:outline-none"
            aria-label="Next slide"
          >
            <ChevronRightIcon className="h-6 w-6" />
          </button>
        </>
      )}

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
        {articles.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 transition-colors ${
              currentIndex === index ? 'bg-white' : 'bg-white/50 hover:bg-white'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default Carousel;