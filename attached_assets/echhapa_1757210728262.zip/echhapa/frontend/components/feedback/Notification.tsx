
import React, { useEffect, useState, useMemo } from 'react';
import { NotificationMessage } from '../../types';
import { useFeedback } from './FeedbackProvider';
import { XIcon, CheckCircleIcon, XCircleIcon, InformationCircleIcon } from '../icons';

interface NotificationProps {
  notification: NotificationMessage;
}

const NOTIFICATION_TIMEOUT = 5000; // 5 seconds

const Notification: React.FC<NotificationProps> = ({ notification }) => {
  const { hideNotification } = useFeedback();
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setExiting(true);
      setTimeout(() => hideNotification(notification.id), 300); // Wait for exit animation
    }, NOTIFICATION_TIMEOUT);

    return () => clearTimeout(timer);
  }, [notification.id, hideNotification]);

  const handleClose = () => {
    setExiting(true);
    setTimeout(() => hideNotification(notification.id), 300);
  };

  const notificationConfig = useMemo(() => {
    switch (notification.type) {
      case 'success':
        return {
          icon: <CheckCircleIcon className="h-6 w-6 text-green-500" />,
          barColor: 'bg-green-500',
          bgColor: 'bg-white',
        };
      case 'error':
        return {
          icon: <XCircleIcon className="h-6 w-6 text-red-500" />,
          barColor: 'bg-red-500',
          bgColor: 'bg-white',
        };
      case 'info':
        return {
          icon: <InformationCircleIcon className="h-6 w-6 text-blue-500" />,
          barColor: 'bg-blue-500',
          bgColor: 'bg-white',
        };
      default:
        return {
          icon: <InformationCircleIcon className="h-6 w-6 text-gray-500" />,
          barColor: 'bg-gray-500',
          bgColor: 'bg-white',
        };
    }
  }, [notification.type]);

  return (
    <div
      className={`
        relative w-full max-w-sm shadow-2xl overflow-hidden border
        transition-all duration-300 ease-in-out
        ${notificationConfig.bgColor}
        ${exiting ? 'opacity-0 translate-x-full' : 'opacity-100 translate-x-0'}
      `}
      role="alert"
      aria-live="assertive"
    >
      <div className="p-4 flex items-start space-x-3">
        <div className="flex-shrink-0">{notificationConfig.icon}</div>
        <div className="flex-1 pt-0.5">
          <p className="text-sm font-medium text-gray-900">{notification.message}</p>
        </div>
        <div className="flex-shrink-0">
          <button
            onClick={handleClose}
            className="p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-400"
            aria-label="Close notification"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
      <div className="h-1 bg-gray-200">
        <div
          className={`h-full ${notificationConfig.barColor}`}
          style={{ animation: `shrink ${NOTIFICATION_TIMEOUT}ms linear forwards` }}
        ></div>
      </div>
      <style>{`
        @keyframes shrink {
          from { width: 100%; }
          to { width: 0%; }
        }
      `}</style>
    </div>
  );
};

export default Notification;
