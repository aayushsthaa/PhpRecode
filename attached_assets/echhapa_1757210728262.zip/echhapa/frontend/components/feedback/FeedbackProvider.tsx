import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { NotificationMessage, NotificationType, ConfirmationState } from '../../types';

interface FeedbackContextType {
    notifications: NotificationMessage[];
    showNotification: (message: string, type: NotificationType) => void;
    hideNotification: (id: number) => void;
    confirmation: ConfirmationState;
    showConfirmation: (title: string, message: string, onConfirm: () => void) => void;
    hideConfirmation: () => void;
}

const FeedbackContext = createContext<FeedbackContextType | null>(null);

export const useFeedback = () => {
    const context = useContext(FeedbackContext);
    if (!context) {
        throw new Error('useFeedback must be used within a FeedbackProvider');
    }
    return context;
};

export const FeedbackProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [notifications, setNotifications] = useState<NotificationMessage[]>([]);
    const [confirmation, setConfirmation] = useState<ConfirmationState>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {},
    });

    const showNotification = useCallback((message: string, type: NotificationType) => {
        const id = Date.now();
        setNotifications(prev => [...prev, { id, message, type }]);
    }, []);

    const hideNotification = useCallback((id: number) => {
        setNotifications(prev => prev.filter(n => n.id !== id));
    }, []);
    
    const showConfirmation = useCallback((title: string, message: string, onConfirm: () => void) => {
        setConfirmation({
            isOpen: true,
            title,
            message,
            onConfirm: () => {
                onConfirm();
                hideConfirmation();
            },
        });
    }, []);

    const hideConfirmation = useCallback(() => {
        setConfirmation({
            isOpen: false,
            title: '',
            message: '',
            onConfirm: () => {},
        });
    }, []);

    const value = {
        notifications,
        showNotification,
        hideNotification,
        confirmation,
        showConfirmation,
        hideConfirmation,
    };

    return (
        <FeedbackContext.Provider value={value}>
            {children}
        </FeedbackContext.Provider>
    );
};
