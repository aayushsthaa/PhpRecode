
import React from 'react';
import { Advertisement } from '../types';

interface AdBannerProps {
  ad: Advertisement;
  className?: string;
}

const AdBanner: React.FC<AdBannerProps> = ({ ad, className = '' }) => {
  const now = new Date();
  if (ad.startDate && new Date(ad.startDate) > now) {
    return null; // Ad campaign hasn't started
  }
  if (ad.endDate && new Date(ad.endDate) < now) {
    return null; // Ad campaign has ended
  }

  const AdImage = () => (
    <img src={ad.imageUrl} alt="Advertisement" className="w-full h-auto object-contain max-h-80 mx-auto" loading="lazy" />
  );

  return (
    <div className={`bg-gray-50 p-2 text-center border ${className}`}>
      {ad.redirectUrl ? (
        <a href={ad.redirectUrl} target="_blank" rel="noopener noreferrer sponsored" title="Advertisement">
          <AdImage />
        </a>
      ) : (
        <div>
          <AdImage />
        </div>
      )}
      <p className="text-xs text-gray-400 mt-1">विज्ञापन</p>
    </div>
  );
};

export default AdBanner;