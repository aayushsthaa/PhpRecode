
import React from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { useAppContext } from '../App';
import { ArrowUpIcon, XSocialIcon, LinkedInIcon, InstagramIcon, FacebookIcon, YouTubeIcon, TikTokIcon } from './icons';

const { Link } = ReactRouterDOM;

const SocialIcon: React.FC<{ platform: string, className?: string }> = ({ platform, className }) => {
    switch (platform) {
        case 'x': return <XSocialIcon className={className} />;
        case 'linkedin': return <LinkedInIcon className={className} />;
        case 'instagram': return <InstagramIcon className={className} />;
        case 'facebook': return <FacebookIcon className={className} />;
        case 'youtube': return <YouTubeIcon className={className} />;
        case 'tiktok': return <TikTokIcon className={className} />;
        default: return null;
    }
}

const Footer: React.FC = () => {
  const { footerSettings } = useAppContext();

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };
  
  if (!footerSettings) {
      return (
        <footer className="bg-white border-t mt-12 font-sans">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-gray-500">
                Loading footer...
            </div>
        </footer>
      );
  }

  return (
    <footer className="bg-white border-t mt-12 font-sans">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          {/* Column 1: Logo, Description, Socials */}
          <div className="md:col-span-5 lg:col-span-4 space-y-6">
            <Link to="/" className="inline-block">
               <img src="../src/images/logo.png" alt="Echhapa Logo" className="h-10 w-auto" />
            </Link>
            <p className="text-gray-600 text-sm leading-relaxed pr-4">
              {footerSettings.description}
            </p>
            <div className="flex items-center space-x-4">
                {footerSettings.socialLinks.map((link) => (
                    <a key={link.platform} href={link.url} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-gray-800 transition-colors" aria-label={`Follow us on ${link.platform}`}>
                        <SocialIcon platform={link.platform} className="h-6 w-6" />
                    </a>
                ))}
            </div>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-2 border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100 transition-colors"
            >
              <ArrowUpIcon className="h-4 w-4" />
              <span>माथि जानुहोस्</span>
            </button>
          </div>

          {/* Spacer on medium screens */}
          <div className="hidden md:block md:col-span-1 lg:col-span-2"></div>

          {/* Dynamic Link Columns */}
          {footerSettings.linkColumns.map((column) => (
              <div key={column._id} className="md:col-span-3 lg:col-span-3">
                <h3 className="font-semibold text-gray-900 mb-4 uppercase tracking-wider">{column.title}</h3>
                <ul className="space-y-2 text-sm">
                    {column.links.map(link => (
                        <li key={link._id}>
                            <a href={link.url} className="text-gray-500 hover:text-blue-600 hover:underline">{link.label}</a>
                        </li>
                    ))}
                </ul>
              </div>
          ))}
        </div>
      </div>
      
      {/* Bottom Copyright Bar */}
      <div className="bg-gray-100 text-gray-600 py-4 border-t">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm">
           <p>{footerSettings.copyrightText}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;