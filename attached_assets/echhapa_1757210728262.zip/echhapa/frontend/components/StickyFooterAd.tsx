
import React, { useState } from 'react';
import { useAppContext } from '../App';
import { AdPosition } from '../types';
import { XIcon } from './icons';

const StickyFooterAd: React.FC = () => {
    const { advertisements } = useAppContext();
    const [isVisible, setIsVisible] = useState(true);

    const stickyAd = advertisements.find(ad => ad.position === AdPosition.STICKY_FOOTER_BANNER);

    if (!stickyAd || !isVisible) {
        return null;
    }

    const AdImage = () => (
         <img src={stickyAd.imageUrl} alt="Advertisement" className="max-h-16 w-auto mx-auto md:mx-0 object-contain" />
    );

    return (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-sm border-t p-2 shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
            <div className="container mx-auto flex justify-between items-center max-w-4xl gap-4">
                <div className="flex-grow">
                    {stickyAd.redirectUrl ? (
                        <a href={stickyAd.redirectUrl} target="_blank" rel="noopener noreferrer sponsored">
                            <AdImage />
                        </a>
                    ) : (
                        <AdImage />
                    )}
                </div>
                <p className="hidden md:block text-xs text-gray-400">Advertisement</p>
                <button
                    onClick={() => setIsVisible(false)}
                    className="p-1.5 text-gray-500 hover:bg-gray-200 focus:outline-none"
                    aria-label="Close advertisement"
                >
                    <XIcon className="h-5 w-5" />
                </button>
            </div>
        </div>
    );
};

export default StickyFooterAd;
