export enum AdPosition {
  HOME_TOP_BANNER = 'home_top_banner',
  HOME_SIDEBAR = 'home_sidebar',
  HOME_SECTION_AD = 'home_section_ad',
  ARTICLE_TOP = 'article_top',
  ARTICLE_BOTTOM = 'article_bottom',
  ARTICLE_SIDEBAR = 'article_sidebar',
  POPUP_MODAL = 'popup_modal',
  STICKY_FOOTER_BANNER = 'sticky_footer_banner',
  INLINE_ARTICLE = 'inline_article',
}

export type ContentBlock = {
  _id?: string;
  type: 'paragraph' | 'image' | 'video';
  content: string; // Text for paragraph, Base64 for image, Embed URL for video
};

export interface Tag {
  _id: string;
  name: string;
}

export interface Article {
  _id: string;
  title: string;
  summary: string;
  content: ContentBlock[];
  imageUrl?: string;
  imageCredit?: string;
  categories: string[];
  tags: Tag[];
  author: {
    _id: string;
    username: string;
  };
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
  status: 'published' | 'draft' | 'scheduled';
  seoTitle?: string;
  metaDescription?: string;
}

export interface Category {
  _id:string;
  name: string;
  parent?: string | { _id: string, name: string };
  children?: Category[];
  showOnHomepage: boolean;
  homepageLayout: 'carousel' | 'grid_2_col' | 'grid_3_col' | 'grid_4_col' | 'featured_post' | 'list_view' | 'split_70_30' | 'hero_1_4' | 'list_with_thumbnails' | 'photo_feature' | 'main_and_sub_list' | 'video_gallery';
  homepageOrder: number;
  order: number; // For general ordering, used in navbar
  showInNav: boolean; // To control visibility in navbar
  seoTitle?: string;
  metaDescription?: string;
}

export interface HomepageSection {
  _id: string;
  title: string;
  key: string;
  layout: Category['homepageLayout'];
  order: number;
  isEnabled: boolean;
  articles: {
    _id?: string;
    article: Article;
    order: number;
  }[];
  isDynamic: boolean;
  sourceCategory?: string | Category;
  itemCount?: number;
}

export interface Advertisement {
  _id: string;
  name: string;
  imageUrl: string;
  redirectUrl?: string;
  position: AdPosition;
  startDate?: string;
  endDate?: string;
  articleId?: string | { _id: string, title: string };
  categoryId?: string | { _id: string, name: string };
  categoryTargeting?: (string | { _id: string, name: string })[];
  order: number;
  isEnabled: boolean;
}

export interface User {
  _id: string;
  username: string;
  email: string;
  bookmarks: string[];
  role?: 'user' | 'author' | 'editor' | 'admin';
}

export type NotificationType = 'success' | 'error' | 'info';

export interface NotificationMessage {
  id: number;
  message: string;
  type: NotificationType;
}

export interface ConfirmationState {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
}

export interface SidebarWidget {
  _id: string;
  type: 'latest_articles' | 'category_articles' | 'advertisement' | 'featured_articles';
  title: string;
  categoryId?: string | {
      _id: string;
      name: string;
  };
  advertisementId?: string | Advertisement;
  itemCount: number;
  order: number;
  layout?: 'list_with_thumbnails' | 'simple_list' | 'featured_list';
}

export interface SocialLink {
  _id?: string;
  platform: 'x' | 'facebook' | 'instagram' | 'linkedin' | 'youtube' | 'tiktok';
  url: string;
}

export interface FooterLink {
    _id?: string;
    label: string;
    url: string;
}

export interface FooterLinkColumn {
    _id?: string;
    title: string;
    links: FooterLink[];
}

export interface FooterSettings {
    _id: string;
    description: string;
    socialLinks: SocialLink[];
    linkColumns: FooterLinkColumn[];
    copyrightText: string;
}